Schematic layout check only. Not rendered by native Max; illustrative bars do not represent saved spectral values.
