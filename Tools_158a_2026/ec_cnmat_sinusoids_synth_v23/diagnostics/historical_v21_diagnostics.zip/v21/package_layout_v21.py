"""Test-only file map for the v21 startup repair. No native Max execution.
The original main name maps to the full synth in patchers/, not the new starter.
No in-memory rewriting of dependency references is performed.
"""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parent.parent
MANIFEST=json.loads((ROOT/'diagnostics/reorganization_manifest_v21.json').read_text())
MOVED={x['original']:x['packaged'] for x in MANIFEST['files']}
def locate(name):
    name=str(name)
    if name in MOVED:return ROOT/MOVED[name]
    if "/" not in name:
        for folder in ("javascript","patchers"):
            candidate=ROOT/folder/name
            if candidate.is_file():return candidate
    return ROOT/name
def original_paths(doc,physical_file):
    return doc
