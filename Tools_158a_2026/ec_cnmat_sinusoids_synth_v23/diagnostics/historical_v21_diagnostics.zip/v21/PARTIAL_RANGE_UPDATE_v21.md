# v21 — constrained partial-display controls

## Basis and scope

The full instrument was edited from the current uploaded
`_ec_sinusoids_synth_v21(1).maxpat`, SHA-256:
`e62b99e9acee1319bc1018b41c7cedbafa377bcf9f49c04336703e42c447fd11`.
The latest compact tutorial package supplies the unchanged dependencies. The uploaded
master's saved settings, custom layouts, nested patches, collections and all existing
577 top-level patch cords are preserved. Only three existing top-level objects change;
five objects and eight cords are added. No original top-level object is removed.

Runtime files to replace together:

- `patchers/_ec_sinusoids_synth_v21_main.maxpat` — the actual full instrument.
- `javascript/partial_amplitude_display_v21.js` — existing display helper, now with
  six outlets (the original four are unchanged; two send silent number-box updates).

The top-level `_ec_sinusoids_synth_v21.maxpat` starter is unchanged. Do not replace
that starter with the full instrument. If your own full instrument uses a different
filename, keep its local filename and replace its contents with this updated full patch.
Close all v21 instrument windows before replacing the helper, then reopen via the normal
starter. Replace BOTH files: the new patch requires the helper's two additional outlets.

## Behavior

`display partials` is followed by first/last integer boxes. Editing either immediately
changes the visible amplitude range. The first box has minimum 1 and maximum equal
to the last; the last has minimum equal to the first and maximum equal to selected
Partial Count. Inputs are clamped, not exchanged, when edited individually.

With 16 partials, first 4 / last 32 becomes 4–16. First cannot exceed last.
`display all` sets first to 1 and last to Partial Count with `set`, without output.
In All mode, count changes keep the view and boxes at 1..N. Count decreases clamp
limits before the interpolation engine's existing fade starts. Departing/fading
slots stay in the engine but cannot be selected past the newly chosen count.

Both number boxes also use native `min`/`max` constraints. Readbacks are guarded
against feedback and are sent only when their bounds change or a command requires
resynchronization, not on every spectral-morph frame. The stored full list, synthesis
count, audio model, hidden memories and preset data are not altered by display changes.
The older explicit `display partials FIRST LAST` message is still supported. Cropped
range restoration on later count growth retains the earlier helper behavior.

## Validation

The current runner is `python3 -B diagnostics/run_diagnostics_v21.py`.

- 23 actual-JavaScript regression suites passed (22 pre-existing plus the new range suite).
- All 22 runtime JavaScript syntax checks passed.
- The original display-helper suite passed 5,383 assertions.
- The new range suite passed 8,867 assertions, including all active counts 2..256,
  constrained endpoint edits, silent readbacks, repeated morph frames, count reduction,
  count growth, malformed requests, and integration with the unchanged interpolation engine.
- Uploaded-master preservation is verified by reversing ONLY the declared changes and
  comparing the complete canonical JSON hash to the uploaded source.
- All original 35 embedded collection datasets are preserved by that full-document
  comparison and by unchanged supporting files.
- All 17 tutorial patches, the starter, all other supporting patches and the 21 other
  runtime JavaScript files are byte-for-byte unchanged. Three reading-guide documents
  and the README were updated to describe the new controls.
- Saved graph endpoints, recorded ports, helper port declarations, new-control overlap
  and all 33 named bundled dependencies passed the automated checks.

Earlier snapshot reports are historical and are not a certificate for the new input.
See `PARTIAL_RANGE_DIAGNOSTICS_v21.json` and `partial_range_regression_logs/` for this run.

## Native Max checks still required

1. Open through the normal starter. Confirm no missing-JS or deleted-cord messages.
2. Set Partial Count to 16; click display all. The boxes should show 1 / 16.
3. Enter first 4, then try last 32. Last must stay 16; slots 4–16 should be visible.
4. Set last 8, then try first 12. First must stop at 8. Try first 0; it must stop at 1.
5. Show 4–12, reduce Partial Count to 6, and confirm 4–6 with a last-box maximum of 6.
6. Click display all, then raise the count to 32. Confirm 1 / 32 and all active bars.
7. With gain low, crop the view and edit a bar. Return to all and verify its original
   slot changed while hidden amplitudes were preserved.

**Native Max execution, the real UI/loader/scheduler and audio auditioning were not
performed here. Passing results cover saved structures, source and emulated messages.**

Implementation reference: Cycling '74 number documentation confirms min/max limits
and silent set messages: https://docs.cycling74.com/reference/number/
