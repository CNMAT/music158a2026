#!/usr/bin/env python3
"""Saved graph/source verification and actual-JS regressions; never native Max."""
from pathlib import Path
import copy,hashlib,json,re,subprocess,sys,concurrent.futures
R=Path(__file__).resolve().parent.parent;D=R/'diagnostics';M=json.loads((D/'AUDIO_ZOOM_MANIFEST_v21.json').read_text())
errors=[];checks=0
stats={'max_documents':0,'patcher_graphs':0,'objects':0,'patch_cords':0,'collections':0,'collection_records':0,'unchanged_runtime_files':0}
def ck(v,m):
 global checks
 checks+=1
 if not v:errors.append(m)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def canon(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
def walk(p):
 yield p
 for e in p.get('boxes',[]):
  if 'patcher' in e['box']:yield from walk(e['box']['patcher'])
main=json.loads((R/M['main_path']).read_text());restored=copy.deepcopy(main);p=restored['patcher']
p['boxes']=[e for e in p['boxes'] if e['box']['id'] not in M['added_root_box_ids']]
for e in p['boxes']:
 if e['box']['id'] in M['original_changed_boxes']:e['box']=M['original_changed_boxes'][e['box']['id']]
p['lines']=M['original_root_lines']
ck(canon(restored)==M['original_master_canonical_sha256'],'Unrelated change to the original master')
rootlines=main['patcher']['lines']
for l in M['original_root_lines']:
 z=l['patchline'];ck(any(e['patchline']['source']==z['source'] and e['patchline']['destination']==z['destination'] for e in rootlines),'Original root edge deleted '+str(z))
for f in M['original_files']:
 target=R/f['path'];ck(target.is_file(),'Missing original runtime file '+f['path'])
 if f['path'] not in M['runtime_changed']:
  ck(target.is_file() and sha(target)==f['sha256'],'Unrelated runtime file changed '+f['path']);stats['unchanged_runtime_files']+=1
files=[R/'_ec_sinusoids_synth_v21.maxpat']+sorted((R/'patchers').glob('*.maxpat'))+sorted((R/'patchers').glob('*.maxhelp'))+sorted((R/'sinusoids_synth_TUTORIAL').glob('*.maxpat'))
deps=set()
for f in files:
 stats['max_documents']+=1
 for p in walk(json.loads(f.read_text())['patcher']):
  stats['patcher_graphs']+=1;b={e['box']['id']:e['box'] for e in p.get('boxes',[])}
  stats['objects']+=len(b);stats['patch_cords']+=len(p.get('lines',[]));ck(len(b)==len(p.get('boxes',[])),str(f)+' duplicate object ID')
  for e in p.get('lines',[]):
   for key,attr in [('source','numoutlets'),('destination','numinlets')]:
    id,n=e['patchline'][key];ck(id in b,str(f)+' missing '+id)
    if id in b:ck(0<=n<b[id].get(attr,0),str(f)+' port range '+id)
  for o in b.values():
   text=o.get('text','')
   if text.startswith(('js ','jsui ')):deps.add(text.split()[1])
   if o.get('maxclass')=='jsui' and o.get('filename'):deps.add(o['filename'])
   if o.get('saved_object_attributes',{}).get('filename'):deps.add(o['saved_object_attributes']['filename'])
   if o.get('maxclass')=='bpatcher' and o.get('name'):deps.add(o['name'])
   if text and (R/'patchers'/(text.split()[0]+'.maxpat')).exists():deps.add(text.split()[0]+'.maxpat')
   if 'coll_data' in o:
    stats['collections']+=1;stats['collection_records']+=len(o['coll_data'].get('data',[]))
for dep in deps:ck(any((p/dep).is_file() for p in [R,R/'javascript',R/'patchers']), 'Missing dependency '+dep)
stats['bundled_dependency_files']=len(deps)
B={e['box']['id']:e['box'] for e in main['patcher']['boxes']};RP=B['sinusoids-audio-rendering-v21']['patcher'];RB={e['box']['id']:e['box'] for e in RP['boxes']}
def edge(p,s,so,t,ti=0):return any(l['patchline']['source']==[s,so] and l['patchline']['destination']==[t,ti] for l in p['lines'])
for id in ['amp-viewport-js','detune-viewport-js','anchor-viewport-js']:ck(B[id]['numinlets']==3 and B[id]['numoutlets']==9,'Viewport ports '+id)
ck(B['rt14-transform']['numoutlets']==7,'Transform saved ports')
ck(RB['offset-crossfade-js-v21-6']['numinlets']==3,'Offset saved ports')
for s,so,t,ti in [('rt14-transform',5,'v21-tagged-send',0),('rt14-transform',6,'partial-contributions-send',0),('amp-viewport-js',6,'detune-viewport-js',0),('amp-viewport-js',6,'anchor-viewport-js',0),('amp-viewport-js',7,'partial-audition-send',0),('amp-viewport-js',8,'partial-hear-toggle',0),('partial-hear-toggle',0,'partial-hear-prepend',0),('partial-hear-prepend',0,'amp-viewport-js',0),('anchor-mirror-lock-v21-6',0,'anchor-viewport-slider',0)]:ck(edge(main['patcher'],s,so,t,ti),'Missing new control edge '+s+' -> '+t)
for id in ['partial-audition-receive','partial-contributions-receive']:ck(edge(RP,id,0,'offset-crossfade-js-v21-6',2),'Missing rendering control input '+id)
ck(sum(o['box'].get('text')=='sinusoids~' for o in RP['boxes'])==12,'Changed renderer bank count')
ck(B['detune-viewport-slider']['setminmax']==[-1.0,1.0],'Detune range lost sign')
for id in ['syn-freq-slider','syn-amp-slider','syn-harmonic-amp-slider']:ck(B[id].get('hidden')==1 and not B[id].get('presentation'),'Canonical slider visible '+id)
for id in ['partial-hear-toggle','partial-hear-label']:
 x,y,w,h=B[id]['presentation_rect']
 for o in B.values():
  if o['id']==id or not o.get('presentation') or o.get('hidden') or o.get('background') or 'presentation_rect' not in o:continue
  a,c,d,e=o['presentation_rect'];ck(not (min(x+w,a+d)>max(x,a)+.1 and min(y+h,c+e)>max(y,c)+.1),'New toggle/label overlap '+id+' '+o['id'])
# Preserve complete collection contents against the restored original doc; supporting
# documents were already checked byte-for-byte above.
def colls(doc):return [(o['box']['id'],o['box']['coll_data']) for p in walk(doc['patcher']) for o in p.get('boxes',[]) if 'coll_data' in o['box']]
ck(colls(main)==colls(restored),'Embedded collection content changed')
syntax=[]
for f in sorted((R/'javascript').glob('*.js')):
 q=subprocess.run(['node','--check',str(f)],capture_output=True,text=True);syntax.append({'file':f.name,'passed':q.returncode==0});ck(q.returncode==0,'JS syntax '+f.name)
L=D/'audio_zoom_regression_logs';L.mkdir(exist_ok=True)
def test(f):
 try:q=subprocess.run(['node',str(f)],cwd=R,capture_output=True,text=True,timeout=180);code=q.returncode;log=q.stdout+q.stderr
 except Exception as e:code=-1;log=str(e)
 (L/(f.stem+'.log')).write_text(log);print(('PASS ' if code==0 else 'FAIL ')+f.name,flush=True);return {'suite':f.name,'passed':code==0,'exit_code':code}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:suites=list(ex.map(test,sorted(D.glob('test*.cjs'))))
for t in suites:ck(t['passed'],'Regression failed '+t['suite'])
report={'status':'PASS' if not errors else 'FAIL','checks':checks,'baseline_archive':M['baseline_archive'],'baseline_sha256':M['baseline_archive_sha256'],'statistics':stats,'runtime_files_changed':M['runtime_changed'],'syntax':syntax,'regression_suites':suites,'errors':errors,'limitations':['Native Max, real UI and scheduler, CPU profiling and audio auditioning were not executed.','Before/after and integration tests exercise actual scripts inside emulated Max message environments.']}
(D/'AUDIO_ZOOM_DIAGNOSTICS_v21.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['syntax','regression_suites']},indent=2))
sys.exit(bool(errors))
