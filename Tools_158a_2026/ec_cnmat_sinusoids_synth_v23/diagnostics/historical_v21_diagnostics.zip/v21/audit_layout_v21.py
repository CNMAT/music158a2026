#!/usr/bin/env python3
"""Current on-disk dependency/relocation audit, not native Max loading."""
from pathlib import Path
import json,hashlib,tempfile,shutil,sys
ROOT=Path(__file__).resolve().parent.parent

def audit(root):
 errors=[];m=json.loads((root/'diagnostics/COMPACT_SOURCE_MANIFEST_v21.json').read_text());dependencies=set()
 for record in m['runtime_files']:
  f=root/record['path']
  if not f.is_file():errors.append('Missing original runtime '+record['path']);continue
  if record['path']!=m['main_path'] and hashlib.sha256(f.read_bytes()).hexdigest()!=record['sha256']:errors.append('Unexpected preserved-file edit '+record['path'])
 def walk(p):
  for bb in p.get('boxes',[]):
   b=bb['box'];t=b.get('text','')
   if t.startswith('js '):dependencies.add(t.split()[1])
   if b.get('maxclass')=='jsui' and b.get('filename'):dependencies.add(b['filename'])
   if b.get('maxclass')=='bpatcher' and b.get('name'):dependencies.add(b['name'])
   if b.get('maxclass')=='newobj' and t and not t.startswith(('p ','patcher ')):
    candidate=t.split()[0]+'.maxpat'
    if (root/'patchers'/candidate).is_file():dependencies.add(candidate)
   if 'patcher' in b:walk(b['patcher'])
 for f in (root/'patchers').glob('*.maxpat'):walk(json.loads(f.read_text())['patcher'])
 for name in dependencies:
  if not any((root/d/name).is_file() for d in ['javascript','patchers']):errors.append('Missing dependency '+name)
 for f in (root/'sinusoids_synth_TUTORIAL').glob('*.maxpat'):
  def nav(p):
   for bb in p.get('boxes',[]):
    b=bb['box'];t=b.get('text','')
    if t.startswith('sprintf symout %s'):
     target=t[len('sprintf symout %s'):]
     if not (f.parent/target).is_file():errors.append('Missing navigation target '+target)
    if 'patcher' in b:nav(b['patcher'])
  nav(json.loads(f.read_text())['patcher'])
 return {'status':'PASS' if not errors else 'FAIL','named_dependencies':len(dependencies),'errors':errors}
report={'on_disk':audit(ROOT),'native_Max_executed':False}
if '--relocation' in sys.argv:
 with tempfile.TemporaryDirectory(prefix='CNMAT relocation Ω ') as temp:
  dest=Path(temp)/'Moved synth with spaces';dest.mkdir()
  for folder in ['patchers','javascript','sinusoids_synth_TUTORIAL']:shutil.copytree(ROOT/folder,dest/folder)
  (dest/'diagnostics').mkdir();shutil.copy2(ROOT/'diagnostics/COMPACT_SOURCE_MANIFEST_v21.json',dest/'diagnostics/COMPACT_SOURCE_MANIFEST_v21.json');shutil.copy2(ROOT/'_ec_sinusoids_synth_v21.maxpat',dest/'_ec_sinusoids_synth_v21.maxpat')
  report['relocated_copy']=audit(dest)
  (dest/'javascript/partial_amplitude_display_v21.js').unlink()
  broken=audit(dest);report['missing_new_helper_detected']=any('partial_amplitude_display_v21.js' in e for e in broken['errors'])
report['status']='PASS' if report['on_disk']['status']=='PASS' and report.get('relocated_copy',{'status':'PASS'})['status']=='PASS' and report.get('missing_new_helper_detected',True) else 'FAIL'
(ROOT/'diagnostics/COMPACT_RELOCATION_RESULTS_v21.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False,indent=2));sys.exit(0 if report['status']=='PASS' else 1)
