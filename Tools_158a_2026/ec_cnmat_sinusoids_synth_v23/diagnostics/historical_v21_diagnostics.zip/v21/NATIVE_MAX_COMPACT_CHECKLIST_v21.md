# Native Max verification — compact tutorial and display controls

These are remaining checks, not tests already performed here.

1. Close old copies; restart Max. Extract the whole folder and open the usual root starter. Confirm it still opens the synth and closes itself, with no missing files or deleted cords.
2. Open sinusoids_synth_TUTORIAL/00_START_TUTORIAL.maxpat. Check the description and two-column lesson list at 560 × 443. Open several lessons, including 09 and 15; check 560 × 402 content is legible and not clipped by local font/rendering or toolbar settings.
3. Check every Listen button is green with black text. Confirm each visible action box fits its label.
4. In a lesson, click → and then ←. Confirm the correct file comes forward and the old lesson window closes. Test from an embedded overview lesson and a standalone lesson. Confirm no change of sound settings.
5. Release left/right keyboard arrows with a lesson frontmost. Repeat with the synth frontmost; background tutorials must not navigate. Check lesson 01 previous and lesson 16 next return to the overview.
6. With audio muted, prepare a 16-partial spectrum. In the synth, change the range message to display partials 5 12, then lock and click. Confirm eight bars show with the correct multiplier labels. Click display all and confirm all 16 return with unchanged values.
7. Edit a cropped bar, restore display all, and confirm only its corresponding original slot changed. Try a one-slot range (5 5), out-of-range bounds, and a count change while cropped. Compare with partial count, which is intentionally a different control.
8. Check slow amplitude morphing while cropped; hidden values must remain intact. Check even/odd/prime and offset multiplier labels. Capture/recall a full-synth preset while cropped and confirm the complete spectrum is captured, not just the view.
9. Enable DSP manually at low hardware volume. Compare sound before/after view-only messages; it should not change. Test the tutorial Listen and Silence commands; navigation must neither start DSP nor stop a held sound.
10. Keep the new JavaScript helper with the complete package. It is found by the unchanged folder-registering starter. Do not open multiple v21 synth versions together.
