#!/usr/bin/env python3
"""Validate the compact tutorial / amplitude viewport build.
Source, JSON graph and modeled-message checks only. No native Max or audio.
Python 3 + Node.js required; Pillow adds text-metric checks when available.
"""
from pathlib import Path
import json,hashlib,copy,re,collections,subprocess,sys,shutil
R=Path(__file__).resolve().parent.parent;D=R/'diagnostics';T=R/'sinusoids_synth_TUTORIAL'
M=json.loads((D/'COMPACT_SOURCE_MANIFEST_v21.json').read_text())
A=json.loads((D/'tutorial_actions_v21.json').read_text());errors=[];checks=0;stats=collections.Counter()
def check(v,msg):
 global checks
 checks+=1
 if not v:errors.append(msg)
def sha(b):return hashlib.sha256(b).hexdigest()
def canon(x):return sha(json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode())
def walk(p,path=()):
 yield path,p
 for q in p.get('boxes',[]):
  if 'patcher' in q['box']:yield from walk(q['box']['patcher'],path+(q['box']['id'],))
def by(p):return {q['box']['id']:q['box'] for q in p['boxes']}
def edge(p,a,oa,b,ib):return any(l['patchline']['source']==[a,oa] and l['patchline']['destination']==[b,ib] for l in p.get('lines',[]))
# Preserve every original runtime file except the explicitly modified top-level UI.
for record in M['runtime_files']:
 f=R/record['path'];check(f.is_file(),'Missing '+record['path'])
 if record['path']==M['main_path']:continue
 check(sha(f.read_bytes())==record['sha256'],'Changed preserved runtime file '+record['path'])
 stats['byte_identical_original_runtime_files']+=1
 if f.suffix=='.js':stats['byte_identical_original_js']+=1
main=json.loads((R/M['main_path']).read_text());restored=copy.deepcopy(main);p=restored['patcher']
newids=set(M['new_box_ids']);p['boxes']=[q for q in p['boxes'] if q['box']['id'] not in newids]
for rec in M['changed_original_boxes']:
 for q in p['boxes']:
  if q['box']['id']==rec['id']:q['box']=rec['before']
p['lines']=p['lines'][:M['main_original_lines']]
for rec in M['changed_original_lines']:p['lines'][rec['index']]=rec['before']
check(canon(restored)==M['main_canonical_hash'],'Unexpected change to original synth beyond declared amplitude-view additions')
# Native multislider and all original audio/control paths remain present.
p=main['patcher'];b=by(p)
check(b['syn-amp-slider']['varname']=='ec_syn_amp_slider','Canonical preset scripting name changed')
check(not b['syn-amp-slider'].get('presentation'),'Canonical multislider must not overlay the viewport')
for a,oa,z,iz in [('syn-amp-slider',0,'syn-interpolation-js',4),('syn-interpolation-js',1,'syn-amp-slider',0),('syn-interpolation-js',1,'amp-viewport-js',0),('amp-viewport-js',0,'amp-viewport-slider',0),('amp-viewport-slider',0,'amp-viewport-js',1),('amp-viewport-js',1,'syn-amp-slider',0),('syn-js',7,'amp-viewport-js',2)]:check(edge(p,a,oa,z,iz),'Viewport path missing '+a+' -> '+z)
check(b['amp-display-range']['text']=='display partials 1 16','Range example changed')
check(b['amp-display-all']['text']=='display all','Display all example changed')
# Structural, dependency, collection and presentation checks.
dep=set();documents=[R/'_ec_sinusoids_synth_v21.maxpat']+sorted((R/'patchers').glob('*.maxpat'))+sorted((R/'patchers').glob('*.maxhelp'))+sorted(T.glob('*.maxpat'))
try:
 from PIL import ImageFont
 font=ImageFont.truetype('LiberationSans-Regular.ttf',48).path
 bold=ImageFont.truetype('LiberationSans-Bold.ttf',48).path
 metrics=Path(font).is_file()
except (ImportError,OSError):metrics=False
for f in documents:
 doc=json.loads(f.read_text());tutorial=f.parent==T;stats['max_documents']+=1
 for path,p in walk(doc['patcher']):
  b=by(p);label=str(f.relative_to(R))+'/'+ '/'.join(path);stats['patcher_graphs']+=1;stats['objects']+=len(b);stats['patch_cords']+=len(p.get('lines',[]))
  check(len(b)==len(p['boxes']),label+' duplicate IDs')
  for ll in p.get('lines',[]):
   l=ll['patchline']
   for key,portkey in [('source','numoutlets'),('destination','numinlets')]:
    ident,port=l[key];check(ident in b,label+' missing '+ident)
    if ident in b:check(isinstance(port,int) and 0<=port<b[ident].get(portkey,0),label+' bad port '+str(l[key]))
  for obj in b.values():
   text=obj.get('text','');mc=obj['maxclass']
   if text.startswith('js '):dep.add(text.split()[1])
   if mc=='jsui' and obj.get('filename'):dep.add(obj['filename'])
   if mc=='bpatcher' and obj.get('name'):dep.add(obj['name'])
   if 'coll_data' in obj and not tutorial:
    cd=obj['coll_data'];stats['collections']+=1;stats['collection_records']+=len(cd.get('data',[]));check(cd.get('count')==len(cd.get('data',[])),label+' coll count')
   if tutorial:
    check(not re.match(r'^(loadbang|loadmess|closebang|js|jsui|metro|qmetro|dac~|ezdac~|send~|receive~|s~|r~)\b',text),label+' active/unsupported tutorial object '+text)
    if text.startswith(('send ','s ')):check(text=='send Synth_Control_v21',label+' unsupported synth destination '+text)
    if mc=='message' and re.search(r'\blisten\b',text,re.I) and obj.get('presentation'):
     stats['green_listen_buttons_including_embedded']+=1;check(obj.get('textcolor')==[0.,0.,0.,1.],label+' Listen text must be black');g=obj.get('bgcolor',[]);check(len(g)==4 and g[1]>.65 and g[0]<.4 and g[2]<.4,label+' Listen background must be green')
  if tutorial:
   vis=[o for o in b.values() if o.get('presentation')]
   for i,a in enumerate(vis):
    x,y,w,h=a['presentation_rect'];check(x>=0 and y>=0 and w>0 and h>0,label+' invalid rectangle '+a['id'])
    check(x+w<=p['rect'][2]+1 and y+h<=p['rect'][3]+1,label+' content outside window '+a['id'])
    for z in vis[i+1:]:
     xx,yy,ww,hh=z['presentation_rect'];overlap=min(x+w,xx+ww)-max(x,xx)>.1 and min(y+h,yy+hh)-max(y,yy)>.1
     check(not overlap,label+' overlap '+a['id']+'/'+z['id'])
    if metrics and a.get('text'):
     fs=a.get('fontsize',12);ff=ImageFont.truetype(bold if a.get('fontface')==1 else font,round(fs*4));maxwidth=max(ff.getlength(s)/4 for s in a['text'].splitlines())
     check(maxwidth<=w-(3 if a['maxclass']=='comment' else 10)+.5,label+' measured text overflow '+a['id'])
for name in dep:check(any((folder/name).is_file() for folder in [R,R/'javascript',R/'patchers']), 'Missing dependency '+name)
stats['resolved_named_dependencies']=len(dep)
check(all(f.suffix=='.js' for f in (R/'javascript').iterdir() if f.is_file()),'javascript folder contains a non-JS file')
# Original lesson commands and wiring, with implementation encapsulated.
index=json.loads((T/'00_START_TUTORIAL.maxpat').read_text())['patcher'];ib=by(index)
for stage in A:
 n=stage['stage'];p=json.loads((T/stage['file']).read_text())['patcher'];b=by(p);stats['standalone_lessons']+=1
 check(p['rect'][2:]==[560.,402.],'Unexpected lesson size '+stage['file'])
 check(ib['overview-lesson-'+str(n)]['patcher']==p,'Embedded lesson differs '+stage['file'])
 impl=b['lesson-actions']['patcher'];bb=by(impl)
 for i,act in enumerate(stage['actions']):
  stats['original_action_buttons']+=1
  check(b[act['button']]['text']==act['label'],'Action label changed '+act['label'])
  check(edge(p,act['button'],0,'lesson-actions',i),'Action inlet changed '+act['label'])
  cmd=bb[act['command_box']]
  if 'patcher' in cmd:
   rp=cmd['patcher'];actual=by(rp)['recipe-command']['text'];check(edge(rp,'recipe-in',0,'recipe-command',0) and edge(rp,'recipe-command',0,'recipe-out',0),'Recipe wiring '+act['label'])
  else:actual=cmd['text']
  check(actual==', '.join(act['commands']),'Original command order changed '+act['label'])
  inlet='action-in-'+str(i);line=[l['patchline'] for l in impl['lines'] if l['patchline']['source']==[inlet,0]]
  check(len(line)==1,'Action has missing/ambiguous trigger '+act['label'])
  if line:
   trig=line[0]['destination'][0];check(bb[trig]['text']=='t b','Action requires bang converter');check(edge(impl,trig,0,act['command_box'],0),'Action trigger route '+act['label'])
  check(edge(impl,act['command_box'],0,act['send'],0),'Action send path '+act['label']);check(bb[act['send']]['text']=='send Synth_Control_v21','Wrong action destination')
 nav=b['lesson-navigation']['patcher'];nb=by(nav)
 prev='00_START_TUTORIAL.maxpat' if n==1 else A[n-2]['file'];next_file='00_START_TUTORIAL.maxpat' if n==16 else A[n]['file']
 check(nb['nav-prev-path']['text']=='sprintf symout %s'+prev,'Previous target '+stage['file']);check(nb['nav-next-path']['text']=='sprintf symout %s'+next_file,'Next target '+stage['file'])
 for a,oa,z,iz in [('nav-left',0,'lesson-navigation',0),('nav-right',0,'lesson-navigation',1),('lesson-active',0,'lesson-navigation',2),('lesson-window',1,'lesson-navigation',3),('lesson-navigation',0,'lesson-window',0)]:check(edge(p,a,oa,z,iz),'Navigation parent path '+stage['file']+' '+a)
 check(b['lesson-active']['text']=='active','Focus detector must live in the lesson window')
 # Model the ACTUAL saved navigator graph. Windows/file-loader behavior remains native-only.
 def simulate(which,folder,active=1,key=None):
  gates={'nav-key-gate':0,'nav-path-gate':0};events=[];pending=[];ticks=0
  def emit(node,port,value):
   edges=[ll['patchline'] for ll in nav['lines'] if ll['patchline']['source']==[node,port]]
   for l in sorted(edges,key=lambda l:l.get('order',0)):send(l['destination'][0],l['destination'][1],value)
  def send(node,inlet,value):
   obj=nb[node];text=obj.get('text','');mc=obj['maxclass']
   if mc=='inlet':emit(node,0,value)
   elif mc=='message':emit(node,0,[int(text)] if text.isdigit() else [text])
   elif mc=='outlet':
    if value==['path']:send('nav-in-folder',0,[folder])
    elif value==['wclose']:events.append(('close',None))
    else:raise AssertionError('Unsupported window command '+str(value))
   elif text.startswith('gate '):
    if inlet==0:gates[node]=int(value[0])
    elif gates[node]>0:emit(node,gates[node]-1,value)
   elif text.startswith('sel '):
    choices=[int(v) for v in text.split()[1:]]
    if value[0] in choices:emit(node,choices.index(value[0]),['bang'])
   elif text=='t b i':emit(node,1,[int(value[0])]);emit(node,0,['bang'])
   elif text=='t b s':emit(node,1,value);emit(node,0,['bang'])
   elif text.startswith('sprintf symout %s'):emit(node,0,[value[0]+text[len('sprintf symout %s'):]])
   elif text=='prepend loadunique':emit(node,0,['loadunique']+value)
   elif text=='pcontrol':
    check(value[0]=='loadunique' and len(value)==2,'Malformed navigation file message');events.append(('open',value[1]))
   elif text.startswith('delay ') or text=='deferlow':pending.append((node,value))
   else:raise AssertionError('Unmodeled navigator node '+text)
  send('nav-in-active',0,[active])
  if key is not None:emit('nav-key',0,[key])
  else:send('nav-in-'+which,0,['bang'])
  while pending:
   node,value=pending.pop(0);emit(node,0,['bang'])
  return events
 for folder in ['/Users/Name With Spaces/Synth Ω/sinusoids_synth_TUTORIAL/','Macintosh HD:/Users/Ed/Synth/sinusoids_synth_TUTORIAL/','C:/Users/Name/Synth/sinusoids_synth_TUTORIAL/']:
  for which,target in [('previous',prev),('next',next_file)]:check(simulate(which,folder)==[('open',folder+target),('close',None)],'Navigation order/space handling '+stage['file'])
 for k,target in [(28,prev),(29,next_file),(63234,prev),(63235,next_file)]:
  check(simulate(None,'/test/',1,k)==[('open','/test/'+target),('close',None)],'Arrow key routing '+stage['file'])
  check(simulate(None,'/test/',0,k)==[],'Inactive lesson reacted to key '+stage['file'])
 check(simulate(None,'/test/',1,65)==[],'Non-arrow key should be ignored')
 stats['navigation_models']+=15
# Syntax and existing behavior tests. The new test uses the actual view-adapter source.
node=shutil.which('node');check(node is not None,'Node.js is required')
syntax=[];suites=[];logs=D/'compact_regression_logs';logs.mkdir(exist_ok=True)
if node:
 for f in sorted((R/'javascript').glob('*.js')):
  q=subprocess.run([node,'--check',str(f)],capture_output=True,text=True);check(q.returncode==0,'JS syntax '+f.name);syntax.append({'file':f.name,'passed':q.returncode==0})
 for f in sorted(D.glob('test*.cjs')):
  try:q=subprocess.run([node,str(f)],cwd=R,capture_output=True,text=True,timeout=180);code=q.returncode;log=q.stdout+q.stderr
  except subprocess.TimeoutExpired:code=-1;log='Timed out after 180 seconds.'
  (logs/(f.stem+'.log')).write_text(log);suites.append({'test':f.name,'passed':code==0,'exit_code':code});check(code==0,'Regression suite '+f.name)
  print(('PASS ' if code==0 else 'FAIL ')+f.name,flush=True)
report={'status':'PASS' if not errors else 'FAIL','checks':checks,'statistics':dict(stats),'text_metrics_checked':metrics,'source':M['source_archive'],'source_sha256':M['source_sha256'],'syntax':syntax,'regression_suites':suites,'errors':errors,'limitations':['No native Max execution, GUI rendering, window loading, key events, scheduler timing or audio auditioning.','Text metrics use Liberation Sans as an Arial substitute; included previews are schematic, not screenshots of Max.','Navigation model checks saved graph ordering and file-name construction; native pcontrol/thispatcher behavior still requires Max verification.']}
(D/'COMPACT_TUTORIAL_RESULTS_v21.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('syntax','regression_suites')},ensure_ascii=False,indent=2),flush=True)
sys.exit(1 if errors else 0)
