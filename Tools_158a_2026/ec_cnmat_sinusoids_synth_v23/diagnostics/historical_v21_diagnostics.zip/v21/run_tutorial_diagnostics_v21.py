#!/usr/bin/env python3
"""Current diagnostics entry. Earlier hover-only runner is archived."""
from pathlib import Path
import runpy
runpy.run_path(str(Path(__file__).with_name('run_compact_diagnostics_v21.py')),run_name='__main__')
