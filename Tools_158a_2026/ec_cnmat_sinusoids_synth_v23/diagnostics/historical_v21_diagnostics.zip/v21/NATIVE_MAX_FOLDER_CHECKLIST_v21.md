# Native Max verification — folder-loading repair

These checks remain to be performed in Max; they were not executed by the automated runner.

1. Close old v21 windows without saving a version that reported deleting cords.
   Restart Max. Do not leave earlier v21 folders registered persistently in File
   Preferences while testing this copy.
2. Extract the entire repaired ZIP into a fresh folder outside old bundles.
   Open its ROOT `_ec_sinusoids_synth_v21.maxpat`.
3. Confirm the starter window appears and the full synth opens automatically.
   The full file is `patchers/_ec_sinusoids_synth_v21_main.maxpat`.
4. Inspect the Max Console before enabling audio. There should be no `can't find
   file`, `No such object`, out-of-range/deleting-cord, or missing-function messages.
   The CNMAT/sinusoids~ identification text is expected and is not an error.
5. Confirm all twelve envelope lanes appear. Their `shape-smoothing-engine`
   objects should load `multislider_interpolation_engine_v21.js` with the full
   inlet/outlet set (11 inlets, 5 outlets). Try a shape/point-count change and morph.
6. Open the organ-stop workspace and its research patch. Confirm `tail` and
   `beathz` produce no missing-function errors. Confirm JSUI rulers and other
   main-page controls load.
7. With safe receiving gains, audition the normal synth, automixer modes, lane
   delays, smoothing and preset recall. The starter does not change startup gains
   or DSP state; usual precautions for pre-DAC-fader named outputs still apply.
8. Click the starter button again: the same full-synth window should activate,
   not start another sounding copy. Close the starter and verify the independent
   synth is still open; close the full-synth window to end that instance.
9. Close the synth, move the COMPLETE folder to a new path containing spaces,
   restart Max and open the root starter again. Do not move just the master file.
10. Only after successful loading, save edits in the FULL synth window. The root
    starter is not the instrument editing surface. Keep its `_main` filename and
    location unless the starter's target is also updated.

If errors persist, retain the first missing-file or missing-object error and the
startup path, rather than saving the failed loaded graph. The exact original
runtime files in this ZIP remain available for another repair.
