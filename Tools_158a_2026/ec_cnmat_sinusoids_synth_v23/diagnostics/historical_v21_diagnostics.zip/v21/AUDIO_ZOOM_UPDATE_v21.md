# v21 — linked spectral views and non-destructive audio zoom

## Baseline

Built from `ec_cnmat_sinusoids_v21_display_controls.zip`, the last complete
package in this conversation. The latest user-edited full master already carried
in that package is preserved except for the declared changes below.

Baseline archive SHA-256:
`05f9b037864fa6df8c18f42ccae31dc424ad172eb1dc359354181988d2f018cd`

## User controls

`display partials [first] [last]` now selects the same inclusive slot range in
**Amplitudes, Detune and Anchors**. Both endpoints retain the existing limits:
`1 <= first <= last <= Partial Count`. The numbers identify slots, not frequency
multipliers. Rulers follow the selected sequence and offset.

**Hear displayed only** defaults to OFF.

- OFF: the three views may be cropped, but the full synth model is audible.
- ON: only the selected slots and their harmonic-anchor partners are auditioned.
- Turning the toggle OFF restores the full sound without changing the crop.
- `display all` restores all three views, turns audition OFF, and silently sets
  the boxes to `1 / Partial Count`.

Manual edits in each cropped view are merged into that layer's complete list.
Hidden values are retained. No snapshot is restored on leaving audition, so
new edits remain in the full model. Selection changes fade over 100 ms.

Turn Anchor Mirror OFF to edit anchors independently. Anchor Scale still applies.
Global shapes, randomize, copy, removal/restoration and Mirror keep their original
full-model scope; they are not limited by the editing crop. Envelopes, drift,
retuning, automixing and routing continue normally. Audition does not trigger
ADSRs or enable DSP.

## How audition avoids overwriting the full model

The three original full-sized sliders retain their scripting names and remain
in the preset manifest. Detune and Anchor each gain a visible viewport, matching
the existing amplitude editor. The shared adapter supports signed -1..1 detune
and 0..1 amplitude layers. Only an actual visible-bar edit produces a complete
replacement list for its canonical layer.

The model transform still emits its ORIGINAL unmasked outputs 0..5. Its added
outlet 6 describes each original primary/anchor contribution to duplicate and
cluster groups. It sends that information before the corresponding full tagged
model. Auto Level remains connected to the full tagged model, not the audition
output, so enabling solo does not recalculate compensation from a quiet subset.

The existing offset-bank engine stores those contributions alongside its two
full, unmasked banks. At output it applies the temporary slot mask to source
contributions BEFORE their duplicate sum / cluster-energy calculation. This is
important when a merged tone's retained ID belongs to an excluded slot: selected
contributions remain audible and excluded contributions do not leak through.
Both outgoing and incoming banks follow range changes, including queued offsets.

Existing merged/clustered frequencies and lane ownership remain fixed. Audition
is not an unmerge or retuning operation. At unity the original model output is
preserved. No additional sine-wave banks, CPU optimization, gain normalization,
ADSR reset or oscillator reset was introduced.

Preset captures retain the entire unmasked model. Crop and audition are temporary
editing state, not additional preset fields. Full-state recall exits audition
and restores full views while the existing controller performs its muted recall.

## Runtime files changed — replace all four together

```text
patchers/_ec_sinusoids_synth_v21_main.maxpat
javascript/partial_amplitude_display_v21.js
javascript/sinusoid_model_transform_v21.js
javascript/partial_offset_crossfade_v21_6.js
```

The display helper now declares 3 inlets / 9 outlets. The model transform has
7 outlets. The offset-bank script has 3 inlets. The full master contains the
matching saved ports and connections. Do not update only one file while Max is
open: an older script can expose the wrong topology.

**The top-level `_ec_sinusoids_synth_v21.maxpat` is the unchanged starter.** Do not
replace it with the full instrument. Close the synth, restart Max when switching
folders, replace the four files together or use the complete new package, then
open the usual starter. Keep only one v21 instrument open.

All 19 other runtime JavaScript files, all supporting Max patches/help, all 17
tutorial patches, and the starter are byte-for-byte unchanged (56 runtime files).
All 35 embedded collection datasets, containing 24,806 records, are preserved.
Every original root patch-cord endpoint remains connected; added fan-outs have
explicit order. The twelve `sinusoids~` banks and original audio-signal wiring
remain. Documentation and diagnostics are updated separately.

## Messages

The direct receive bus `Partial_View_v21` accepts:

```max
display partials 4 16
first 4
last 16
hear 1
hear 0
display all
```

These use the same UI limits and silent readbacks. This is not a new command in
the `Synth_Control_v21` preset manifest. Internal contribution and audition buses
are implementation details, not a second public control surface.

## Verification performed

- 26 JavaScript regression suites passed: the 23 existing suites plus three
  new linked-view, audio-audition and before/after parity suites.
- 22 / 22 runtime JavaScript files pass syntax checks.
- 48,924 structural, preservation and control-contract checks passed.
- 38 Max documents parsed; 459 saved patcher graphs checked.
- All 33 named bundled dependency files resolve within the unchanged layout.
- Full master preservation is checked by reversing ONLY declared new objects,
  changed original objects and ordering fields, then comparing its canonical
  JSON hash with the input master.
- Linked-view tests exercise the actual saved graph and actual interpolation
  script for all counts 2..256, signed detune, independent edits, hidden memory,
  live morph updates, resize/limit echoes and Anchor Mirror protection.
- Audition tests cover primary/anchor pairs, 100 ms transitions, rapid reversals,
  duplicates, clipping, cluster power, both offset banks, queued offsets, edited
  source retention, preset restoration, and unchanged Auto Level state.
- Before/after tests compare original transform outputs over 300 varied model /
  control cases and original offset behavior over 500 changing frames.

Current machine-readable results: `AUDIO_ZOOM_DIAGNOSTICS_v21.json`.
Run the current checks with:

```sh
python3 -B diagnostics/run_diagnostics_v21.py
```

Older reports and historical runners describe earlier snapshots. Their old
source hashes are not the current preservation test.

## Native checks still required

1. Close other v21 copies and open through the usual starter. Confirm no
   missing scripts, out-of-range cords or missing functions in the Max Console.
2. With output low, start a held/looping spectrum. Set count 32 and choose 4 / 16.
   Amplitudes, Detune and Anchors must all show thirteen slots.
3. Enable Hear displayed only. Only that selected section and its anchors should
   remain after the 100 ms fade. Move either endpoint and listen for continuity.
4. Edit one amplitude and one signed detune. Turn Mirror OFF and edit one anchor.
   Turn audition OFF: full sound returns, crop stays. Click display all: all
   three full views return, showing those edits in their original slots.
5. Try first 0 or last above Partial Count; limits must clamp. Lower Partial Count
   below the displayed range and verify all three views stay synchronized.
6. Change partial sequence/offset while soloed; verify the section remains
   selected across the crossfade. Restore all; no partial should remain muted.
7. Capture/recall a full preset while cropped: complete model is retained and
   recall exits solo. Check normal ADSRs, automixer and independent anchor edits.

**Native Max execution, real audio auditioning and CPU profiling were NOT
performed here.** Passing tests cover sources, saved graphs and emulated
message/scheduler behavior, not native certification. The layout preview is a
schematic rendering, not a Max screenshot.

## Max API references used

The implementation keeps the established classic-Max `Task` scheduling pattern
and uses multislider `setlist` and toggle `set` for silent UI updates:

- https://docs.cycling74.com/apiref/js/task/
- https://docs.cycling74.com/reference/multislider/
- https://docs.cycling74.com/reference/toggle/
