/* Test-only file locator for the reorganized v21 bundle. Not loaded by Max.
 * Behavior tests operate on the same logical graph as the uploaded v21 patch.
 * Only the 95 recorded dependency-path fields are reversed for those models.
 * Every field must still match the delivered relative path exactly; the separate
 * audit_layout_v21.py validates the RAW references and file existence/relocation.
 * This module does not modify Node's fs object or any files on disk.
 */
'use strict';
const fs=require('fs'),path=require('path');
const root=path.resolve(__dirname,'..');
const manifest=JSON.parse(fs.readFileSync(path.join(__dirname,'reorganization_manifest_v21.json'),'utf8'));
const moved=new Map(manifest.files.map(f=>[f.original,f.packaged]));
const logicalCache=new Map();
function resolve(file){
  if(typeof file!=='string')return file;
  const absolute=path.isAbsolute(file)?path.normalize(file):path.resolve(root,file);
  if(fs.existsSync(absolute))return absolute;
  const rel=path.relative(root,absolute).split(path.sep).join('/');
  if(moved.has(rel))return path.join(root,moved.get(rel));
  return absolute;
}
function originalPaths(doc,physicalFile){
  const rel=path.relative(root,physicalFile).split(path.sep).join('/');
  for(const edit of manifest.path_edits[rel]||[]){
    let target=doc;
    for(const key of edit.pointer.slice(0,-1))target=target[key];
    const key=edit.pointer.at(-1);
    if(target[key]!==edit.after)throw Error('Unexpected dependency reference: '+rel+' / '+edit.pointer.join('/')+' = '+target[key]);
    target[key]=edit.before;
  }
  return doc;
}
function readFileSync(file,options){
  const real=resolve(file),extension=path.extname(String(real));
  if(extension!=='.maxpat'&&extension!=='.maxhelp')return fs.readFileSync(real,options);
  if(!logicalCache.has(real))logicalCache.set(real,JSON.stringify(originalPaths(JSON.parse(fs.readFileSync(real,'utf8')),real)));
  const text=logicalCache.get(real);
  const encoding=typeof options==='string'?options:options&&options.encoding;
  return encoding?text:Buffer.from(text,'utf8');
}
function existsSync(file){return fs.existsSync(resolve(file));}
function listPatches(){return manifest.files.filter(f=>f.packaged.endsWith('.maxpat')).map(f=>path.basename(f.packaged)).sort();}
module.exports={root,resolve,readFileSync,existsSync,listPatches,originalPaths};
