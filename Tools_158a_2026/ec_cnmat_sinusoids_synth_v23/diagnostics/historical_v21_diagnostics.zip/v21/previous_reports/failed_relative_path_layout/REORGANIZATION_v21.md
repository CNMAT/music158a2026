# v21 folder reorganization — diagnostic report

## Result

**PASS for the automated source, graph, runtime-file preservation, dependency-path and relocation checks.** Native Max execution and audio auditioning have not been performed.

Source: `ec_cnmat_sinusoids_synth_v21(1).zip` (the exact attachment supplied for this task).

Source ZIP SHA-256: `6ce627a8d62831ec6dfeb7a148000cc63f16430e641b80c462198f87b7151062`

Open **`_ec_sinusoids_synth_v21.maxpat`** at the top of the extracted `ec_cnmat_sinusoids_synth_v21_organized` folder. This remains v21; no synthesis feature, optimization, audio wiring, bus name, scripting name, saved control value, or timing algorithm was changed.

## Folder structure

| Location | Contents |
|---|---|
| Top level | Main patch and concise `README.md` only |
| `patchers/` | All 18 supporting `.maxpat` files, plus the original `.maxhelp` |
| `javascript/` | All 21 original runtime `.js` files, and no other files |
| `diagnostics/` | All test code, diagnostic results, logs, checksums, manifests and documentation |

The test location helpers use `.cjs` and `.py` and stay in `diagnostics/`; they are not loaded by Max. Full functional documentation is retained in `diagnostics/documentation/`. Previous diagnostic snapshots are separated into `diagnostics/previous_reports/`.

## How dependency loading is arranged

Every bundled runtime dependency is explicitly addressed with Max's **`Patcher:/`** relative prefix. The paths are stored in the actual object definitions, not added later by a loadbang:

```max
js Patcher:/javascript/cnmat_sinusoid_model_generator_v21.js
js Patcher:/javascript/automatic_lines_v5_ed.js 12 2000 10000 5000
Patcher:/patchers/ec_sinusoid_synth_stops_v21.maxpat
```

The twelve bpatcher names in the embedded lane panel point to `Patcher:/patchers/ADSR_Lane_01_v21.maxpat`, etc. Each external lane file in `patchers/` uses:

```max
js Patcher:/../javascript/multislider_interpolation_engine_v21.js
```

A standalone panel in `patchers/` references its neighboring lane files as `Patcher:/ADSR_Lane_01_v21.maxpat`, etc. Embedded patchers inherit the owning physical document's directory; external patch documents use their own directory.

Both visible `js` arguments and `saved_object_attributes.filename` were updated. JSUI filenames and external abstraction paths were updated as well. No absolute machine paths, root-folder-name assumptions, symlinks, duplicate script copies, project prerequisite, or persistent File Preferences changes were introduced.

This layout targets **Max 9**. The `Patcher:/` prefix is available from Max 8.6 onward. Keep the three internal folder names and locations unchanged; move or rename the entire enclosing folder instead of moving the master alone.

## Exact preservation

| Check | Result |
|---|---:|
| Original runtime JavaScript files byte-identical | **21 / 21** |
| Original Max documents preserved except dependency paths | **20 / 20** |
| Max documents requiring path edits | **16** |
| Max documents moved without content edits | **4** |
| Individual path fields changed | **95** |
| Original object and cord counts retained | **12,289 / 9,751** |
| Embedded collection datasets retained | **35 / 35** |
| Embedded collection records retained | **24,806 / 24,806** |

For every changed document, the audit reverses only the 95 exact old/new field edits recorded in `reorganization_manifest_v21.json`, then compares a canonical hash of the **entire document** to its uploaded original. This checks that no other property, object, cord, subpatch, UI location or stored value changed. Every original JavaScript is checked by SHA-256 without normalization.

## Automated verification

| Check | Result |
|---|---:|
| Structural and control-contract assertions | **46,061 passed** |
| Behavioral regression suites | **21 / 21 passed** |
| JavaScript syntax checks | **21 / 21 passed** |
| Raw path and preservation audit checks | **692 passed** |
| Raw reference fields inspected | **95** |
| Unique referenced bundled dependency files | **31 / 31 found** |
| Complete main dependency closure, including main | **32 / 32 found** |
| Renamed/copied folder path audit | **PASS** |

The relocation audit copies the complete folder to a fresh directory containing spaces, a Unicode character, and `#`, changes the process working directory to an unrelated location, and repeats the raw dependency and preservation audit. All references resolve to the same relative files; no access to the original package location is required by those path checks.

The full regression runner was invoked from `/tmp`, not from the bundle folder. This validates the relocated test runner's independence from the caller's working directory; it does not stand in for a native Max launch.

### Current-upload baseline versus older snapshots

Before repackaging, the supplied archive was tested in its original flat layout. **20 of 21 behavioral suites passed.** The old report's complete-object hashes and two embedded/standalone equality assumptions no longer matched the supplied file. In particular, the current embedded message gallery includes the user's `p some-of-the-features-in-the-synth` note subpatch, which is absent from the standalone gallery; Max save-version and other saved metadata also differ.

Those uploaded differences were **not overwritten or synchronized**. The old snapshots and original run are retained. The current exact-preservation baseline uses this upload, and the automixer test checks both galleries' command examples instead of incorrectly requiring their entire surrounding contents to be identical.

Behavioral models use a test-only file locator and in-memory reversal of the recorded path fields, so their existing selector/object tests remain meaningful. Raw path validity is independently checked against the actual, unnormalized package. This distinction is documented rather than representing a Node model as Max's native loader.

## Native Max boundary and external prerequisite

Native Max loading, GUI rendering, Max scheduler timing, actual CNMAT DSP, listening and CPU profiling have **not** been performed here. The included `NATIVE_MAX_FOLDER_CHECKLIST_v21.md` specifies those remaining checks.

The installed compatible **CNMAT `sinusoids~` external remains required**. It was not in the supplied archive; no third-party binary was fabricated or relocated. Open only one v21 master/editor at a time because the existing named v21 buses remain shared.

## Re-run

```sh
python3 -B diagnostics/run_diagnostics_v21.py
python3 -B diagnostics/audit_layout_v21.py --relocation
```

Python 3 and Node.js are for diagnostics only; the instrument itself still runs in Max with its original dependencies.

## Implementation references

The following official Max documentation was consulted specifically for the folder-loading mechanism, not as a replacement for examining the supplied synth:

- Cycling '74, **Search Path**, section **Path Prefixes**: `Patcher:/` resolves files relative to the current patcher even outside the global search path, for objects that load files. https://docs.cycling74.com/userguide/search_path/
- Cycling '74, **absolutepath** reference: `Patcher:` is relative to the containing patcher. https://docs.cycling74.com/reference/absolutepath/
- Joshua Kit Clayton (Cycling '74), **Specify js file via relative path**, developer clarification of the prefix and Max 8.6 availability. https://cycling74.com/forums/specify-js-file-via-relative-path

All source comparisons, runtime dependency references and test results in this report come from the supplied archive and the generated package itself.
