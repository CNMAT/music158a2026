"""Test-only locations and logical path normalization. No native Max execution."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parent.parent
MANIFEST=json.loads((ROOT/'diagnostics/reorganization_manifest_v21.json').read_text())
MOVED={x['original']:x['packaged'] for x in MANIFEST['files']}
def locate(name):
    p=ROOT/name
    return p if p.exists() else ROOT/MOVED.get(str(name),str(name))
def original_paths(doc,physical_file):
    rel=Path(physical_file).relative_to(ROOT).as_posix()
    for edit in MANIFEST['path_edits'].get(rel,[]):
        target=doc
        for key in edit['pointer'][:-1]:target=target[key]
        key=edit['pointer'][-1]
        if target[key]!=edit['after']:
            raise AssertionError('Unexpected dependency reference: '+rel+' / '+str(edit['pointer']))
        target[key]=edit['before']
    return doc
