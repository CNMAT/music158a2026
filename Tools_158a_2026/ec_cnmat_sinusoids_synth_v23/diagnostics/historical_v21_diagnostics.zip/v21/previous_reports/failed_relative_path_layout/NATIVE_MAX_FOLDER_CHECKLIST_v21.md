# Native Max check — organized v21

These checks must be performed in Max; they have not been represented as completed by the automated reports.

1. Extract the entire ZIP to an ordinary location outside any manually configured Max search path. Close other v21 synth/editor patches. Use Max 9 and the same compatible installed CNMAT `sinusoids~` external as before.
2. Double-click `_ec_sinusoids_synth_v21.maxpat` in the top-level folder. No project file or separate loader should be necessary. Inspect the Max Console for missing JavaScript, missing patchers, or missing external messages. Do not add the parent folder recursively to File Preferences as a substitute for this check.
3. Confirm that all twelve ADSR lane panels appear, the three component-index rulers display, and the organ-stop workspace opens. Open the embedded message spaces and verify that the added feature-note subpatch from the supplied upload is still there.
4. At a safe monitoring level, create a sounding model, trigger the envelopes, test a per-lane delay, partial-sequence changes, global gain, and automixer Bypass/Auto/Stop. Existing output buses and gain behavior are unchanged by this reorganization.
5. Test preset sweep/dump/recall. The controller must still reach the twelve external lane patches and the organ-stop abstraction. Reorganization does not change the control scripting names.
6. Close the synth, rename or move the **whole** enclosing folder (a name containing spaces is a useful check), reopen the top-level master, and repeat the Console/dependency checks.
7. Separately, with the main synth closed, open a supporting patch or the automixer help file directly from `patchers/`. Its own JavaScript path should resolve through the adjacent `javascript/` directory. Do not run several v21 control panels at once because they retain the same named buses.

`Patcher:/` references resolve relative to their owning file. Renaming the enclosing folder is supported; moving the master alone or renaming `patchers/`/`javascript/` is not.

If the installed Max version is older than 8.6, this relative-prefix layout is not supported. This bundle is intended for Max 9, consistent with the uploaded master.
