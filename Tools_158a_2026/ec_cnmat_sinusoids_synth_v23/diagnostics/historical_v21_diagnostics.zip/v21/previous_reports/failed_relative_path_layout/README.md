Historical evidence from the previous relative-path layout.

The user reported that native Max could not resolve the Patcher:/../javascript references. Its PASS reports only checked a filesystem model; they did not certify native loading. These old scripts/results must not be used as current diagnostics.
