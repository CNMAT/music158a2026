#!/usr/bin/env python3
"""Audit RAW saved Max references, preservation, and relocation.

This program is NOT a Max host. It interprets the documented Patcher:/ prefix
relative to the physical patch document, walks saved dependencies, and confirms
that they exist. It does not claim native Max loading, scheduling or DSP tests.

Run from any directory:
  python3 /path/to/bundle/diagnostics/audit_layout_v21.py --relocation
"""
from pathlib import Path
import argparse, collections, copy, hashlib, json, os, re, shutil, tempfile

MAIN='_ec_sinusoids_synth_v21.maxpat'
def digest(data):return hashlib.sha256(data).hexdigest()
def canonical(obj):return digest(json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=True).encode())

def audit(root):
    root=Path(root).resolve()
    manifest=json.loads((root/'diagnostics/reorganization_manifest_v21.json').read_text())
    errors=[];checks=0;refs=[];datasets=0;records=0
    patches=[];scripts=[];other_assets=[]
    def check(value,message):
        nonlocal checks
        checks+=1
        if not value:errors.append(message)
    check({p.name for p in root.iterdir() if p.is_dir() and p.name!='__pycache__'}=={'patchers','javascript','diagnostics'},'exactly three top-level dependency folders')
    check([p.name for p in root.glob('*.maxpat')]==[MAIN],'only the main patch is at top level')
    check(not list(root.glob('*.js')),'no loose root-level JavaScript files')
    jsdir=root/'javascript'
    check(all(p.is_file() and p.suffix=='.js' for p in jsdir.iterdir()),'javascript contains only .js files')
    check(len(list(jsdir.glob('*.js')))==21,'all 21 original scripts present')
    check(len(list((root/'patchers').glob('*.maxpat')))==18,'all 18 supporting patches present')
    check(len(list((root/'patchers').glob('*.maxhelp')))==1,'original help file present')
    source_docs={}
    for item in manifest['files']:
        target=root/item['packaged'];suffix=target.suffix
        if suffix not in ('.maxpat','.maxhelp','.js'):continue
        check(target.is_file(),'runtime file exists: '+item['packaged'])
        if not target.is_file():continue
        if suffix=='.js':
            check(digest(target.read_bytes())==item['original_sha256'],'unchanged JavaScript: '+item['packaged'])
            scripts.append(item['packaged']);continue
        try:doc=json.loads(target.read_text())
        except Exception as e:check(False,'JSON parse '+item['packaged']+': '+str(e));continue
        patches.append(item['packaged']);source_docs[item['packaged']]=doc
        original=copy.deepcopy(doc)
        for edit in manifest['path_edits'].get(item['packaged'],[]):
            try:
                obj=original
                for key in edit['pointer'][:-1]:obj=obj[key]
                key=edit['pointer'][-1]
                check(obj[key]==edit['after'],'exact new reference: '+item['packaged']+' '+str(edit['pointer']))
                obj[key]=edit['before']
            except (KeyError,IndexError,TypeError) as e:check(False,'reference pointer '+str(edit['pointer'])+': '+str(e))
        check(canonical(original)==item['original_document_sha256'],'path-only patch changes: '+item['packaged'])
    def reference(owner,loc,kind,value,extension):
        check(isinstance(value,str) and value.startswith('Patcher:/'),owner+loc+' explicit Patcher:/ reference '+str(value))
        if not isinstance(value,str) or not value.startswith('Patcher:/'):return
        tail=value[len('Patcher:/'):]
        check(not re.search(r'^[A-Za-z]:|^/|\\',tail),owner+loc+' portable relative syntax')
        target=((root/owner).parent/tail).resolve()
        try:rel=target.relative_to(root).as_posix()
        except ValueError:check(False,owner+loc+' escapes package: '+value);return
        check(target.is_file(),owner+loc+' dependency exists: '+value)
        check(target.suffix==extension,owner+loc+' dependency type '+value)
        if target.exists():check(target.name in os.listdir(target.parent),owner+loc+' exact filename case')
        refs.append({'owner':owner,'object_path':loc,'kind':kind,'reference':value,'resolved':rel})
    def walk(p,owner,loc=''):
        nonlocal datasets,records
        for entry in p.get('boxes',[]):
            b=entry['box'];pos=loc+'/'+b['id'];typ=b.get('maxclass');text=b.get('text','')
            if typ=='newobj':
                m=re.match(r'^(js|jsui|v8|v8ui|node\.script)\s+(\S+)',text)
                if m:reference(owner,pos,'script_object',m.group(2),'.js')
                elif text.split(' ')[0].endswith('.maxpat'):reference(owner,pos,'abstraction',text.split(' ')[0],'.maxpat')
                elif text.split(' ')[0]+'.maxpat' in {Path(f).name for f in source_docs}:
                    check(False,owner+pos+' unqualified abstraction: '+text)
            if typ=='bpatcher' and not b.get('embed'):
                reference(owner,pos,'bpatcher',b.get('name'),'.maxpat')
            for key in ['filename','jsfilename','jspainterfile']:
                value=b.get(key)
                if isinstance(value,str) and value.endswith('.js'):reference(owner,pos,key,value,'.js')
                value=b.get('saved_object_attributes',{}).get(key)
                if isinstance(value,str) and value.endswith('.js'):
                    reference(owner,pos,'saved_'+key,value,'.js')
                    m=re.match(r'^(?:js|jsui|v8|v8ui)\s+(\S+)',text)
                    if typ=='newobj' and m and key=='filename':check(value==m.group(1),owner+pos+' visible/saved script paths agree')
            if 'coll_data' in b:
                datasets+=1;records+=len(b['coll_data'].get('data',[]))
            if 'patcher' in b:walk(b['patcher'],owner,pos)
    for owner,doc in source_docs.items():walk(doc['patcher'],owner)
    graph=collections.defaultdict(set)
    for entry in refs:graph[entry['owner']].add(entry['resolved'])
    reached=set();todo=[MAIN]
    while todo:
        value=todo.pop()
        if value in reached:continue
        reached.add(value);todo.extend(graph[value]-reached)
    check(all((root/f).is_file() for f in reached),'complete main-patch dependency closure exists')
    # Documentation/comments with bare filenames are not executable dependencies.
    # Unchanged JS has no file-based include/require or additional runtime asset reads.
    internal_io=[]
    for f in scripts:
        if re.search(r'\b(?:include|require)\s*\(|\bnew\s+(?:File|Folder)\s*\(', (root/f).read_text()):internal_io.append(f)
    check(not internal_io,'no unhandled JS include/require/File/Folder runtime references')
    return {'status':'PASS' if not errors else 'FAIL','checks':checks,'main':MAIN,
      'max_documents_preserved_except_paths':len(patches),'javascript_files_byte_identical':len(scripts),
      'supporting_maxpat_files':18,'maxhelp_files':1,'path_fields_changed':sum(len(v) for v in manifest['path_edits'].values()),
      'max_documents_with_path_edits':len(manifest['path_edits']),
      'raw_reference_fields_checked':len(refs),'unique_runtime_dependency_files':len({x['resolved'] for x in refs}),
      'main_dependency_closure_files_including_main':len(reached),'main_dependency_closure':sorted(reached),
      'embedded_collection_datasets_preserved':datasets,'embedded_collection_records_preserved':records,
      'references':refs,'errors':errors,
      'limits':['Filesystem/path-prefix model, not a native Max launch.','External CNMAT sinusoids~ binary remains an installed prerequisite; it was not in the supplied ZIP.']}

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--root',type=Path,default=Path(__file__).resolve().parent.parent)
    ap.add_argument('--relocation',action='store_true')
    args=ap.parse_args();root=args.root.resolve();report=audit(root)
    if args.relocation:
        with tempfile.TemporaryDirectory(prefix='v21 relocation with spaces ') as tmp:
            moved=Path(tmp)/'Renamed synth Ω #1';shutil.copytree(root,moved,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
            unrelated=Path(tmp)/'Unrelated working directory';unrelated.mkdir()
            old=os.getcwd()
            try:
                os.chdir(unrelated);relocated=audit(moved)
            finally:os.chdir(old)
            same=(report['references']==relocated['references'])
            report['relocation']={'status':'PASS' if relocated['status']=='PASS' and same else 'FAIL','checks':relocated['checks'],'tested':'Fresh copy in a renamed directory containing spaces, Unicode and #; unrelated process working directory.','references_identical':same,'errors':relocated['errors']}
            if report['relocation']['status']!='PASS':report['status']='FAIL';report['errors'].append('relocation failed')
    (root/'diagnostics/layout_audit_results_v21.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in ['references','main_dependency_closure']},indent=2,ensure_ascii=False))
    return 0 if report['status']=='PASS' else 1
if __name__=='__main__':raise SystemExit(main())
