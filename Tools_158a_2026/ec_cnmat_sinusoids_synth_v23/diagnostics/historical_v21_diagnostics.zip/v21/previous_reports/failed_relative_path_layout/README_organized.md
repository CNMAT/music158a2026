# CNMAT sinusoids — v21, organized folders

## Open the synth

Unzip the complete folder, then double-click **`_ec_sinusoids_synth_v21.maxpat`** at its top level.

```text
ec_cnmat_sinusoids_synth_v21_organized/
├── _ec_sinusoids_synth_v21.maxpat    ← OPEN THIS FILE
├── README.md
├── patchers/                        18 supporting .maxpat files + 1 .maxhelp
├── javascript/                      All 21 runtime .js files; nothing else
└── diagnostics/                     Tests, results, manifests and documentation
    ├── run_diagnostics_v21.py
    ├── audit_layout_v21.py
    ├── REORGANIZATION_v21.md
    ├── NATIVE_MAX_FOLDER_CHECKLIST_v21.md
    ├── documentation/               Original v21 feature/control documentation
    ├── logs/                        Current automated test logs
    └── previous_reports/            Earlier snapshots, clearly separated
```

The main patch is the only `.maxpat` kept at the top level. All other `.maxpat` files are in `patchers/`. The help file is there too. `javascript/` contains only `.js` files. No runtime files are hidden in the diagnostics folder.

## Loading and portability

This layout targets **Max 9**. It uses Max's `Patcher:/` relative-path prefix, which is available starting in Max 8.6. No project file, launcher patch, manual File Preferences changes, or installation in the Max Packages directory is required for the bundled dependencies.

The master directly references its adjacent folders. A patch inside `patchers/` references JavaScript through `Patcher:/../javascript/`. Embedded subpatches use the path context of their owning document. Visible object arguments, saved JavaScript filenames, JSUI filenames, bpatcher names, and external-abstraction references have all been updated.

**Move or rename the whole enclosing folder freely, but keep the internal folder names and relative positions intact. Do not copy just the master patch to a different directory.** Extract the ZIP before opening it.

Keep your existing compatible **CNMAT `sinusoids~` external** installed, along with any existing required Max externals. Third-party binaries were not in the supplied ZIP and are not included here. Close other v21 synth/editor instances before opening this one: the v21 message buses intentionally remain unchanged.

## What changed

This is a folder reorganization of the exact uploaded **`ec_cnmat_sinusoids_synth_v21(1).zip`**, not a new synthesis version or CPU optimization.

- All **21 runtime JavaScript files are byte-for-byte identical** to the upload.
- **95 saved dependency-path fields** were updated in 16 Max documents. The other four Max documents were moved without changes.
- Every original Max document, including the main patch, is otherwise unchanged: audio patch cords, control graphs, UI positions, scripting names, sends/receives, defaults, envelope functions, and embedded collections are preserved.
- The current embedded and standalone galleries/panels retain their separate uploaded contents. No older standalone copy was used to overwrite a more recent embedded edit.
- Tests were adapted to the folder locations. Old full-object snapshots that no longer matched the uploaded Max save were retained as historical evidence; current preservation checks use this exact upload.

See [the reorganization report](diagnostics/REORGANIZATION_v21.md) for verification details and [the native-Max checklist](diagnostics/NATIVE_MAX_FOLDER_CHECKLIST_v21.md) for the remaining interactive checks.

## Optional diagnostics

The synth does **not** need Python or Node.js to operate. Those are only needed to run the included tests.

From the enclosing folder:

```sh
python3 -B diagnostics/run_diagnostics_v21.py
```

The runner can also be invoked by its complete path from another working directory. It runs the raw dependency and relocation audit, checks all JavaScript syntax, and executes the 21 regression suites. Reports and logs stay in `diagnostics/`.

To run just the raw folder/dependency audit:

```sh
python3 -B diagnostics/audit_layout_v21.py --relocation
```

**Verification boundary:** these are source, saved-graph, filesystem, and emulated-message tests. Native Max loading, scheduler behavior, and audio auditioning were not performed in the build environment.

## Full v21 feature documentation

The earlier feature and control documents are retained in `diagnostics/documentation/`. Start with [README_v21.md](diagnostics/documentation/README_v21.md) or [CONTROL_REFERENCE_v21.md](diagnostics/documentation/CONTROL_REFERENCE_v21.md). References in those historical documents to a flat folder or the old location of the diagnostic runner are superseded by this README.
