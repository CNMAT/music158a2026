# CNMAT Sinusoids Synth v21 — hover help and tutorial report

## Source and scope

Source: **ec_cnmat_sinusoids_synth_v21(2).zip**, the current full package supplied for this task.

Source archive SHA-256:
`a079e9b7b6b29b047beb6ad661508ce8704597eb652bf20c66fe1f22b429bce0`

This is a teaching/help update to that package, not a new synthesis engine or a CPU-optimized version. The v21 bus and file names remain. The existing startup and automatic starter-closing behavior remain unchanged.

## Hover help

Added or refined **2,836 object descriptions** across the original 21 Max documents. Each uses both native `hint` and `annotation` fields. These totals count saved objects, including embedded/standalone mirrors; they are not a count of distinct musical parameters.

Coverage includes all **2,360 detected user-interface objects and message boxes**, including the main controls, each of twelve ADSR lanes, global envelope controls, the retained Master editor, function libraries, stores, distribution/routing, automixer, gain controls, organ stops, message spaces and examples. Internal helpers receive explanatory hints where applicable.

Keep the patch locked to see popup hints. The matching annotation is shown in Max’s Clue tab. Official Max reference: https://docs.cycling74.com/userguide/objects/ .

The wording distinguishes controls from displays, global settings from lane settings, and playback duration from smoothing and delay. It explains destructive actions such as All Off and Store where relevant. The existing Flat-envelopes helper is described according to its saved shape-0 wiring, not as a unity hold.

### Saved objects with hints, by document

| Document | Hinted objects |
|---|---:|
| `_ec_sinusoids_synth_v21.maxpat` | 3 |
| `patchers/ADSR_LANE_PANEL_v21.maxpat` | 29 |
| `patchers/ADSR_Lane_01_v21.maxpat` | 37 |
| `patchers/ADSR_Lane_02_v21.maxpat` | 37 |
| `patchers/ADSR_Lane_03_v21.maxpat` | 37 |
| `patchers/ADSR_Lane_04_v21.maxpat` | 37 |
| `patchers/ADSR_Lane_05_v21.maxpat` | 37 |
| `patchers/ADSR_Lane_06_v21.maxpat` | 37 |
| `patchers/ADSR_Lane_07_v21.maxpat` | 37 |
| `patchers/ADSR_Lane_08_v21.maxpat` | 37 |
| `patchers/ADSR_Lane_09_v21.maxpat` | 37 |
| `patchers/ADSR_Lane_10_v21.maxpat` | 37 |
| `patchers/ADSR_Lane_11_v21.maxpat` | 37 |
| `patchers/ADSR_Lane_12_v21.maxpat` | 37 |
| `patchers/Envelope-Shaper_01_v21.maxpat` | 26 |
| `patchers/Example_Timed_Score_v21.maxpat` | 52 |
| `patchers/Send_Message_Space_v21.maxpat` | 825 |
| `patchers/_ec_sinusoids_synth_v21_main.maxpat` | 1,390 |
| `patchers/automatic_lines_v5_ed.maxhelp` | 16 |
| `patchers/ec_sinusoid_synth_stops_research_v21.maxpat` | 20 |
| `patchers/ec_sinusoid_synth_stops_v21.maxpat` | 31 |

## Tutorial

New root folder: **CNMAT_Sinusoids_Synth_TUTORIAL**.

Open **00_START_TUTORIAL.maxpat** after opening the synth through its normal starter. The overview contains sixteen embedded lessons. Identical standalone lesson files are supplied for direct opening. A local HTML reading guide, a Markdown guide and a hover-reference file are also included.

| Stage | Focus |
|---|---|
| 01 | One sine wave, output setup and pitch |
| 02 | Partials and amplitudes |
| 03 | Shapes, morphing and hidden-slot memory |
| 04 | Detune, anchors and beating |
| 05 | Micro-drift and its return to zero |
| 06 | Retuning modes and glide |
| 07 | Partial sequences and offset |
| 08 | Global breakpoint envelopes |
| 09 | Individual lane timing, delay and point stores |
| 10 | Lane distribution versus physical outputs |
| 11 | Removal, restoration and octave families |
| 12 | Organ-inspired registrations |
| 13 | Automatic mixing |
| 14 | Gain, model-power compensation and frequency limits |
| 15 | Direct messages and CUE modules |
| 16 | Full-state capture, recall and a short study |

There are **121 lesson action buttons**, plus the overview’s Silence control. Actions use the existing Synth_Control_v21 interface. The diagnostic manifest records every ordered command and the actual button-to-message-to-send connection. There is no new runtime JavaScript or audio signal path.

### Behavior and safeguards

Opening, navigating or closing tutorials sends no synth messages. There are no loadbangs, timers, DSP-enabling commands or automatically triggered notes in the tutorials.

**Prepare intentionally replaces the live sound.** It clears the three full spectral memories, sets the lesson controls, selects two output groups and −24 dB DAC faders, and leaves global gain at zero. Save a sound first using dump and a separately saved preset-message patch. Prepare does not overwrite user-function store slots.

**Listen** is explicit and separate. DSP must be enabled manually. Begin at a low hardware level. **Silence All Feeds** sets global gain to zero and stops envelopes without erasing the spectrum. Closing a lesson does not stop audio. Stage 16 deliberately has no Prepare action so the current sound can be captured.

The tutorial describes the supplied script’s automixer cycle as zero → peak → zero → wait. It does not imply that automixer start triggers the ADSRs or enables DSP. Fixed peaks still use continuous ramps.

## Preservation

All **21 runtime JavaScript files are byte-for-byte unchanged**.

For all **21 original Max documents**, removing only `hint` and `annotation` from both the input and output yields identical complete JSON structures. No objects, patch cords, UI coordinates, values, scripting names, dependency references, startup actions, collection contents or audio algorithms were changed. This is stronger than checking only object counts.

All **35 embedded collection datasets and 24,806 records** remain intact. No function store was normalized, replaced or emptied. Existing embedded panels were not replaced with standalone copies.

Hover additions are spread across the original support patches, including all twelve lane files, so use the complete updated folder rather than replacing only the main patch.

## Automated verification

| Check | Result |
|---|---:|
| Saved-graph, help-coverage and tutorial-contract checks | 63,990 passed |
| Original behavioral regression suites | 21 / 21 passed |
| Runtime JavaScript syntax checks | 21 / 21 passed |
| Original Max documents preserved except help metadata | 21 / 21 |
| Bundled referenced dependency names found | 31 / 31 |
| Tutorial documents | 17 valid |
| Tutorial action buttons traced and checked | 121 |
| Embedded lesson / standalone lesson matches | 16 / 16 |
| Folder relocation with spaces, Unicode and # | Passed on-disk audit |
| Deliberately removed interpolation script | Correctly detected |

Presentation rectangles were checked for overlap. Approximate local layout previews were reviewed for readable text; these are not screenshots of native Max. All sixteen lessons and the overview passed the approximate text-fit check.

Current machine-readable results are **HOVER_TUTORIAL_RESULTS_v21.json** and **layout_audit_results_v21.json**. **hover_tutorial_source_manifest_v21.json** records the exact current upload. Prior reports are retained as historical records; their previous byte-level expectations are not used to certify this update.

## Limits

**Native Max execution, native popup behavior, scheduler behavior, tutorial playback and audio auditioning were not performed here.** The new tutorial commands were checked against the current controller and saved connections, not executed through Max’s native host. The tests do not certify the external binary or the user’s audio hardware.

Use **NATIVE_MAX_HOVER_TUTORIAL_CHECKLIST_v21.md** for the remaining practical checks. CNMAT sinusoids~ remains an external prerequisite. Keep only one v21 instrument/editor running because its named buses are shared.
