#!/usr/bin/env python3
"""Audit hover-only edits, tutorial action wiring, dependencies and existing JS suites.
These tests do not launch Max or audition audio. Requires Python 3 and Node.js.
"""
from pathlib import Path
import collections, hashlib, json, re, shutil, subprocess, sys
ROOT=Path(__file__).resolve().parent.parent
D=ROOT/'diagnostics';LOG=D/'tutorial_logs';LOG.mkdir(exist_ok=True)
errors=[];checks=0
stats=collections.Counter();syntax=[];suites=[]
def check(ok,what):
 global checks
 checks+=1
 if not ok:errors.append(what)
def sha(b):return hashlib.sha256(b).hexdigest()
def strip_help(x):
 if isinstance(x,dict):return {k:strip_help(v) for k,v in x.items() if k not in ('hint','annotation')}
 if isinstance(x,list):return [strip_help(v) for v in x]
 return x
def canonical(x):return sha(json.dumps(x,sort_keys=True,ensure_ascii=True,separators=(',',':')).encode())
def walk(p,path=()):
 yield path,p
 for bb in p.get('boxes',[]):
  b=bb['box']
  if 'patcher' in b:yield from walk(b['patcher'],path+(b.get('text',b['id']),))
UI={'number','flonum','toggle','button','textbutton','umenu','slider','multislider','function','live.gain~','meter~','kslider','jsui','bpatcher','scope~','number~','matrixctrl','dial','radiogroup','tab','preset','textedit'}
baseline=json.loads((D/'hover_tutorial_source_manifest_v21.json').read_text())
docs={};dependency_names=set()
for record in baseline['files']:
 f=ROOT/record['path'];check(f.is_file(),'Missing original runtime file: '+record['path'])
 if not f.is_file():continue
 if 'without_help_metadata_sha256' in record:
  doc=json.loads(f.read_text());docs[record['path']]=doc
  check(canonical(strip_help(doc))==record['without_help_metadata_sha256'],'Non-help change in original runtime: '+record['path'])
  stats['original_max_documents']+=1
 else:
  check(sha(f.read_bytes())==record['sha256'],'Changed original JavaScript: '+record['path'])
  stats['unchanged_runtime_js']+=1
for f in (ROOT/'CNMAT_Sinusoids_Synth_TUTORIAL').glob('*.maxpat'):
 docs[f.relative_to(ROOT).as_posix()]=json.loads(f.read_text());stats['tutorial_documents']+=1

def dep_exists(name):
 return any((folder/name).is_file() for folder in [ROOT,ROOT/'javascript',ROOT/'patchers'])
for filename,doc in docs.items():
 tutorial=filename.startswith('CNMAT_Sinusoids_Synth_TUTORIAL/')
 for path,p in walk(doc['patcher']):
  label=filename+'/'+'/'.join(path);by={b['box']['id']:b['box'] for b in p.get('boxes',[])}
  stats['patcher_graphs']+=1;stats['objects']+=len(by)
  check(len(by)==len(p.get('boxes',[])),label+': duplicate object ID')
  for ll in p.get('lines',[]):
   l=ll['patchline'];stats['patch_cords']+=1
   for side,key in [('source','numoutlets'),('destination','numinlets')]:
    ident,port=l[side];check(ident in by,label+': missing endpoint '+ident)
    if ident in by:check(isinstance(port,int) and 0<=port<by[ident].get(key,0),label+': invalid saved port '+str(l[side]))
  for b in by.values():
   mc=b.get('maxclass');t=b.get('text','')
   if mc in UI or mc=='message':
    if not tutorial:
     stats['runtime_controls_and_messages']+=1
     check(bool(b.get('hint')),label+'/'+b['id']+': missing hover hint')
     check(b.get('annotation')==b.get('hint'),label+'/'+b['id']+': missing matching annotation')
   if b.get('hint') and not tutorial:stats['runtime_hinted_objects']+=1
   if 'coll_data' in b and not tutorial:
    cd=b['coll_data'];stats['collections']+=1;stats['collection_records']+=len(cd.get('data',[]))
    check(cd.get('count')==len(cd.get('data',[])),label+': collection header mismatch')
   if not tutorial:
    if t.startswith('js '):dependency_names.add(t.split()[1])
    if mc=='jsui' and b.get('filename'):dependency_names.add(b['filename'])
    if mc=='bpatcher' and b.get('name'):dependency_names.add(b['name'])
    if mc=='newobj' and t and (ROOT/'patchers'/(t.split()[0]+'.maxpat')).is_file():dependency_names.add(t.split()[0]+'.maxpat')
   else:
    # Tutorials have no load-time synth activity, script engine, audio signal path, or file I/O.
    check(not re.match(r'^(loadbang|loadmess|closebang|js|jsui|metro|qmetro|delay|pipe|dac~|ezdac~|send~|receive~|s~|r~)\b',t),label+': disallowed active tutorial object '+t)
    if t.startswith(('send ','s ')):check(t in ('send Synth_Control_v21','s Synth_Control_v21'),label+': unsupported tutorial destination '+t)
    check(mc not in ('bpatcher','jsui','ezdac~'),label+': external tutorial dependency')
  if tutorial:
   vis=[b for b in by.values() if b.get('presentation')]
   for i,a in enumerate(vis):
    x,y,w,h=a['presentation_rect'];check(x>=0 and y>=0 and w>0 and h>0,label+': invalid presentation rectangle')
    for z in vis[i+1:]:
     xx,yy,ww,hh=z['presentation_rect'];overlap=min(x+w,xx+ww)-max(x,xx)>.1 and min(y+h,yy+hh)-max(y,yy)>.1
     check(not overlap,label+': visible overlap '+a['id']+'/'+z['id'])
for name in sorted(dependency_names):check(dep_exists(name),'Unresolved bundled dependency '+name)
stats['resolved_dependency_names']=len(dependency_names)
# Confirm the JS-only folder and all twelve external ADSRs.
check(all(f.suffix=='.js' for f in (ROOT/'javascript').iterdir() if f.is_file()),'Non-JS file in javascript/')
for i in range(1,13):
 f=ROOT/'patchers'/f'ADSR_Lane_{i:02}_v21.maxpat';check(f.is_file(),'Missing lane file '+str(i))
 p=json.loads(f.read_text())['patcher'];by={b['box']['id']:b['box'] for b in p['boxes']}
 for ident in ['count','duration','shape-menu','points','function','trigger-button','memory-index','store-button','recall-button','loop-toggle','shape-smoothing-ms','delay-ms']:
  check(bool(by[ident].get('hint')),f'Lane {i:02} missing help: '+ident)
# Controller contract is read from the current unchanged source, not from a guessed protocol.
script=(ROOT/'javascript/synth_controller_v21.js').read_text()
manifest=json.loads(re.search(r'var EC_MANIFEST\s*=\s*(\{.*\});',script).group(1));controls=set(manifest['controls'])
actions=json.loads((D/'tutorial_actions_v21.json').read_text())
check(len(actions)==16,'Expected 16 tutorial stages')
index=docs['CNMAT_Sinusoids_Synth_TUTORIAL/00_START_TUTORIAL.maxpat']['patcher']
embedded={b['box']['text'][2:]:b['box']['patcher'] for b in index['boxes'] if 'patcher' in b['box']}
selector_limits={'gain':(0,1),'gaindb':(-120,0)}
for stage in actions:
 p=docs['CNMAT_Sinusoids_Synth_TUTORIAL/'+stage['file']]['patcher'];by={b['box']['id']:b['box'] for b in p['boxes']}
 name=Path(stage['file']).stem;check(embedded.get(name)==p,'Embedded/standalone lesson mismatch '+name)
 edges=collections.defaultdict(list)
 for ll in p['lines']:
  l=ll['patchline'];edges[l['source'][0]].append(l['destination'][0])
 for ac in stage['actions']:
  stats['tutorial_action_buttons']+=1
  check(by[ac['command_box']]['text']==', '.join(ac['commands']),'Changed command sequence '+ac['label'])
  # Trace the actual button through the bang-converter to its single message/send.
  route=edges[ac['button']];check(len(route)==1,'Ambiguous action button '+ac['label'])
  if len(route)==1:
   trig=route[0];check(by[trig].get('text')=='t b','Action must explicitly produce bang '+ac['label'])
   check(edges[trig]==[ac['command_box']],'Action trigger wiring '+ac['label'])
  check(edges[ac['command_box']]==[ac['send']],'Action send wiring '+ac['label'])
  check(by[ac['send']]['text']=='send Synth_Control_v21','Action destination '+ac['label'])
  for cmd in ac['commands']:
   stats['tutorial_command_occurrences']+=1;words=cmd.split();selector=words[0]
   check(selector in ('control','gain','gaindb','trigger','stop','note-in','check','sweep','dump'),'Unsupported tutorial selector '+cmd)
   if selector=='control':
    check(len(words)>=3 and words[1] in controls,'Unsupported controller address '+cmd)
    check(words[1]!='Audio_On','Tutorial must not change DSP: '+cmd)
    if words[1]=='Registration':check(len(words)==3 and words[2].isdigit() and 0<=int(words[2])<=9,'Registration uses integer index '+cmd)
    if words[1]=='Partial_Distribution':check(words[2] in ('0','1','2','3'),'Sequence range '+cmd)
    if words[1]=='Render_Distribution':check(words[2] in ('0','1','2','3','4'),'Lane plan range '+cmd)
    if words[1]=='Spatial_Group_Count':check(2<=int(words[2])<=12,'Output group range '+cmd)
    if words[1]=='Automixer':check(words[2] in ('mode','start','stop','bypass','restart','bang','range','waittime','fixedpeak','grain'),'Automixer selector '+cmd)
   if selector in selector_limits:
    lo,hi=selector_limits[selector];check(len(words)==2 and lo<=float(words[1])<=hi,'Gain range '+cmd)
  if ac['label']=='1  Prepare lesson':
   check(ac['commands'][:2]==['gain 0','stop'],'Prepare must first mute and stop')
   check('trigger' not in ac['commands'] and not any(c.startswith('note-in') for c in ac['commands']),'Prepare must not trigger')
   check('control Spatial_Group_Count 2' in ac['commands'],'Stereo teaching baseline')
  if ac['label']=='SILENCE ALL FEEDS':check(ac['commands']==['gain 0','stop'],'Silence must not erase spectrum')
# Syntax and the uploaded behavioural regression suites.
node=shutil.which('node');check(node is not None,'Node.js unavailable')
if node:
 for f in sorted((ROOT/'javascript').glob('*.js')):
  q=subprocess.run([node,'--check',str(f)],capture_output=True,text=True);ok=q.returncode==0
  syntax.append({'file':f.name,'passed':ok});check(ok,'JS syntax '+f.name)
 for f in sorted(D.glob('test*.cjs')):
  try:q=subprocess.run([node,str(f)],capture_output=True,text=True,timeout=180);code=q.returncode;log=q.stdout+q.stderr
  except subprocess.TimeoutExpired:code=-1;log='Timed out after 180 seconds.\n'
  (LOG/(f.stem+'.log')).write_text(log)
  suites.append({'test':f.name,'passed':code==0,'exit_code':code});check(code==0,'Regression suite '+f.name)
  print(('PASS ' if code==0 else 'FAIL ')+f.name,flush=True)
report={'status':'PASS' if not errors else 'FAIL','checks':checks,'statistics':dict(stats),'javascript_syntax':syntax,'suites':suites,'passed_suites':sum(s['passed'] for s in suites),'suite_count':len(suites),'source_archive':baseline['source_archive'],'source_archive_sha256':baseline['source_archive_sha256'],'errors':errors,'limits':['No native Max launch, UI, scheduler, CNMAT DSP execution or listening.','Dependency availability is checked on disk; startup and all original runtime structure are preserved modulo help metadata.','Commands are checked against the current controller contract and their saved connections; this is not native tutorial playback.']}
(D/'HOVER_TUTORIAL_RESULTS_v21.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('javascript_syntax','suites')},ensure_ascii=False,indent=2),flush=True)
sys.exit(0 if not errors else 1)
