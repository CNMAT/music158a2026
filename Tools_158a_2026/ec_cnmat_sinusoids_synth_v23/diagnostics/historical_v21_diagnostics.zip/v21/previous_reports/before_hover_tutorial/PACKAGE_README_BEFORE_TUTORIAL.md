# SINUSOIDS v21 — repaired folder loading

## Start here

**Open `_ec_sinusoids_synth_v21.maxpat` at the top of this folder.**

This file is now a small native-Max starter. It first adds `patchers/` and
`javascript/` to Max's session search path, then opens the full synth automatically.
No JavaScript or external patch is required to run the starter itself.

**The full editable synth is now `patchers/_ec_sinusoids_synth_v21_main.maxpat`.**
Its contents are byte-for-byte identical to the master in the supplied
`ec_cnmat_sinusoids_synth_v21(1).zip`, before the unsuccessful folder reorganization.
The filename/location changed; the synthesis patch did not.

### First use after the failed package

1. Close the failed v21 windows **without saving**. Its Console log reports that
   Max deleted patch cords while dependencies were missing.
2. Restart Max, then extract this entire ZIP into a **new folder**. Do not merge
   the failed folder or a saved damaged patch into this one.
3. Open the top-level `_ec_sinusoids_synth_v21.maxpat`. The full synth opens next.
   Check the Console before enabling audio. The expected CNMAT identification
   text is not an error; missing-file/deleted-cord/missing-function messages are.

Keep only one v21 bundle active. Do not keep old v21 dependency folders in Max's
persistent File Preferences alongside this copy. Restarting clears session-only
paths, not persistent preferences the user has explicitly configured.

## Files

```text
ec_cnmat_sinusoids_synth_v21_folderfix/
    _ec_sinusoids_synth_v21.maxpat       <-- OPEN THIS (starter)
    README.md
    patchers/
        _ec_sinusoids_synth_v21_main.maxpat  <-- full editable instrument
        [18 other original .maxpat files]
        automatic_lines_v5_ed.maxhelp
    javascript/
        [all 21 original runtime .js files, and nothing else]
    diagnostics/
        FOLDER_LOADING_REPAIR_v21.md
        NATIVE_MAX_FOLDER_CHECKLIST_v21.md
        run_diagnostics_v21.py
        audit_layout_v21.py
        [tests, results, documentation, previous reports]
```

Do not open the full synth directly in a fresh Max session: use the starter first.
After the starter has registered the folders, supporting patches can also find
their scripts by their original names. Edit/save the full synth window when
changing the instrument; the starter is not the instrument's editing surface.

The starter's button reopens/brings forward that same full-synth file using
`loadunique`. Closing the starter does not close the independently opened synth.
The starter does not send DSP or synthesis-control messages. Its search-path
additions are session-only and do not write File Preferences. It deliberately
does not issue `filepath revert`, which could undo another patch's temporary paths.

Keep this folder together. Move/rename the enclosing folder only while the synth
is closed; after moving it, restart Max and use the starter at the new location.
No machine-specific absolute path is saved: the current location is derived at
startup, and `sprintf symout` retains paths containing spaces as single symbols.

## Preservation and tests

All **41 original runtime files** (19 `.maxpat`, 1 `.maxhelp`, 21 `.js`) are
byte-for-byte identical to the supplied pre-reorganization source. All 35 embedded
collections, 24,806 records, original UI, sends/receives and audio wiring are retained.
There is one new native-Max starter, plus updated documentation and diagnostics.

All **21 existing regression suites** and all **21 JavaScript syntax checks** passed.
The added audit checks exact source hashes, raw dependency names, saved ports,
registration-before-open ordering in a model, a relocated folder, and rejection
of a deliberately removed copy of the previously failing script.

**Native Max execution and audio auditioning have not been performed here.**
The event model is not Max's filesystem or scheduler. Use the included native
checklist to confirm actual loading on your computer. CNMAT `sinusoids~` remains
an installed external prerequisite; no third-party binary was changed.

For the diagnostic details, read `diagnostics/FOLDER_LOADING_REPAIR_v21.md`.
