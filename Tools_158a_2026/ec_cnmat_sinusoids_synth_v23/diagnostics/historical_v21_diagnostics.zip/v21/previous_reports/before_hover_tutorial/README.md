# Current v21 tests and diagnostics

The synth never loads this directory. Runtime code lives in `javascript/`, and
all original Max documents live in `patchers/`.

Run `python3 -B diagnostics/run_diagnostics_v21.py` from the bundle root. Python 3
and Node.js are testing dependencies only. `audit_layout_v21.py --relocation`
checks raw runtime hashes, original bare dependency names, the native starter
structure, a model of its ordered messages, and an independently relocated copy.

The two `package_layout_v21` helpers map the historic master filename to
`patchers/_ec_sinusoids_synth_v21_main.maxpat`. They do NOT reverse paths or alter
any source content. The starter is checked separately from the full synth.

Current reports: `diagnostic_results_v21.json`, `layout_audit_results_v21.json`,
`FOLDER_LOADING_REPAIR_v21.md`. Previous reports are historical, especially the
failed native-loader assumptions under `previous_reports/failed_relative_path_layout/`.

`SHA256SUMS_v21.txt` covers the current package using root-relative paths. The
full runner refreshes it after writing its reports. No native Max/DSP test is
represented by these source and emulation results.
