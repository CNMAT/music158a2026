#!/usr/bin/env python3
"""Source, saved-patch graph and emulated-message diagnostics. No native Max/DSP.
Run from the bundle root: python3 diagnostics/run_diagnostics_v21.py  (requires Node.js on PATH).
"""
from pathlib import Path
import json, hashlib, re, subprocess, sys, shutil, time
from package_layout_v21 import ROOT, locate, original_paths, MANIFEST
D=ROOT/'diagnostics'; (D/'logs').mkdir(exist_ok=True)
errors=[]; checks=0; stats={'top_level_patches':0,'nested_patchers':0,'objects':0,'patch_cords':0,'collection_datasets':0,'collection_records':0}; dependencies=set(); stores={}
def check(condition,label):
 global checks
 checks+=1
 if not condition:errors.append(label)
def canonical(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True).encode()).hexdigest()
def without_vars(x):
 if isinstance(x,dict):return {k:without_vars(v) for k,v in x.items() if k!='varname'}
 if isinstance(x,list):return [without_vars(a) for a in x]
 return x
def B(p):return {b['box']['id']:b['box'] for b in p['boxes']}
def graph(p,filename,location=''):
 stats['nested_patchers']+=1; boxes=B(p);stats['objects']+=len(boxes)
 check(len(boxes)==len(p['boxes']),filename+location+' unique IDs')
 names=[b['varname'] for b in boxes.values() if b.get('varname')];check(len(names)==len(set(names)),filename+location+' unique scripting names')
 for x in p.get('lines',[]):
  l=x['patchline'];stats['patch_cords']+=1
  for side,prop in [('source','numoutlets'),('destination','numinlets')]:
   id,port=l[side];check(id in boxes,filename+location+' endpoint '+id)
   if id in boxes:check(isinstance(port,int) and 0<=port<boxes[id].get(prop,0),filename+location+' port '+str(l[side]))
 for id,b in boxes.items():
  t=b.get('text','')
  if b.get('maxclass')=='newobj' and t.startswith('js '):dependencies.add(t.split()[1])
  if b.get('filename','').endswith('.js'):dependencies.add(b['filename'])
  if b.get('maxclass')=='bpatcher':dependencies.add(b['name'])
  if b.get('maxclass')=='newobj' and locate(t.split(' ')[0]+'.maxpat').is_file():dependencies.add(t.split(' ')[0]+'.maxpat')
  if b.get('maxclass')=='newobj' and re.match(r'^(s|r|send|receive|send~|receive~|forward) ',t):check(not re.search(r'_v(?:19|20)\b',t),filename+location+' stale bus '+t)
  if 'coll_data' in b:
   cd=b['coll_data'];data=cd.get('data',[]);stats['collection_datasets']+=1;stats['collection_records']+=len(data);check(cd.get('count')==len(data),filename+location+'/'+id+' collection header')
   stores[(filename,location+'/'+id)]=data
  if 'patcher' in b:graph(b['patcher'],filename,location+'/'+id)
patches={}
for entry in MANIFEST['files']:
 if Path(entry['original']).suffix not in ('.maxpat','.maxhelp'):continue
 p=ROOT/entry['packaged']; logical=entry['original']
 try:doc=json.loads(p.read_text());patches[logical]=doc['patcher'];stats['top_level_patches']+=1;graph(doc['patcher'],logical)
 except Exception as e:errors.append(logical+': '+str(e))
for name in dependencies:check(locate(name).is_file(),'missing bundled dependency '+name)
main=patches['_ec_sinusoids_synth_v21.maxpat'];b=B(main);ref=json.loads((D/'source_reference_v21.json').read_text())
check(canonical(without_vars(b['sinusoids-audio-rendering-v21']))==ref['render_object_sha256'],'full rendering patch preserved')
route=B(b['sinusoids-audio-routing-v21']['patcher']);check(canonical(route['am-controller-v21'])==ref['automixer_control_sha256'],'automixer control subpatch preserved')
check(hashlib.sha256(locate('automatic_lines_v5_ed.js').read_bytes()).hexdigest()==ref['v5_sha256'],'unchanged v5 script')
renderer=locate('Partial_Group_Manager_v21_6.js').read_text().split('\nvar EC_NS=')[0].rstrip();check(hashlib.sha256(renderer.encode()).hexdigest()==ref['original_fixed_renderer_core_sha256'],'original fixed renderer core unchanged')
check('var CAPACITY = 1024;' in renderer and 'renderlimit' not in renderer.lower(),'no Render Limit or dynamic allocation imported')
for entry in ref['collections']:
 data=stores.get((entry['file'],entry['path']));check(data is not None and canonical(data)==entry['sha256'],'original collection preserved '+entry['file']+entry['path'])
check(canonical(b['obj-112']['patcher'])==ref['uploaded_embedded_lane_panel_sha256'],'uploaded embedded lane panel preserved')
check(canonical(patches['ADSR_LANE_PANEL_v21.maxpat'])==ref['uploaded_standalone_lane_panel_sha256'],'uploaded standalone lane panel preserved')
check(canonical(b['send-message-space-v21']['patcher'])==ref['uploaded_embedded_message_space_sha256'],'uploaded embedded message space preserved')
check(canonical(patches['Send_Message_Space_v21.maxpat'])==ref['uploaded_standalone_message_space_sha256'],'uploaded standalone message space preserved')
check(sum(x['box'].get('text')=='sinusoids~' for x in b['sinusoids-audio-rendering-v21']['patcher']['boxes'])==12,'all twelve CNMAT oscillators retained')
# New gain multiplies the existing level control, not any audio/lane/routing replacement.
rp=b['sinusoids-audio-routing-v21']['patcher'];rl=[x['patchline'] for x in rp['lines']]
for n in range(1,13):check(any(e['source']==['v21-combined-gain',0] and e['destination']==[f'alc-mult-{n:02d}',1] for e in rl),'all-output gain lane '+str(n))
check(b['ec-gain-pack']['text']=='pack 1. 50' and b['ec-gain-line']['text']=='line~ 1.','unity default and 50 ms gain interpolation')
# Passive v21 help, full command examples, and no duplicate JS engines in the help.
hp=B(b['send-message-space-v21']['patcher'])['v21-new-feature-message-space']['patcher'];hb=B(hp);edges=[x['patchline'] for x in hp['lines']]
controls=set(json.loads((D/'preset_manifest_v21.json').read_text())['controls']);examples=json.loads((D/'v21_message_examples.json').read_text())
for e in examples:
 check(hb[e['id']]['text']==e['message'],'example retained '+e['id']);check(sum(1 for x in edges if x['source']==[e['id'],0] and x['destination']==['v21-send',0])==1,'example single send '+e['id'])
 for part in e['message'].split(','):
  tokens=part.strip().split();check(tokens[0] in ['control','gain','gaindb','note-in','trigger','stop','sweep','dump','check'],'supported selector '+part)
  if tokens[0]=='control':check(tokens[1] in controls,'known control '+tokens[1])
for v in hb.values():check(not re.match(r'^(js|loadbang|loadmess|metro|qmetro)\b',v.get('text','')),'passive v21 help '+v['id'])
def overlap(a,b):return min(a[0]+a[2],b[0]+b[2])-max(a[0],b[0])>.1 and min(a[1]+a[3],b[1]+b[3])-max(a[1],b[1])>.1
visible=[v for v in hb.values() if v.get('presentation')]
for i,a in enumerate(visible):
 for z in visible[i+1:]:check(not overlap(a['presentation_rect'],z['presentation_rect']),'new help overlap '+a['id']+'/'+z['id'])
newids=['opt-distribution','opt-distribution-label','ec-gain-slider','ec-gain-number','ec-note-example','ec-sweep','ec-dump','v21-gain-label','v21-new-controls-note','v21-preset-message','v21-status-message','v21-check-message','v21-preset-note']
visible=[v for v in b.values() if v.get('presentation')]
for id in newids:
 a=b[id]
 for z in visible:
  if id!=z['id']:check(not overlap(a['presentation_rect'],z['presentation_rect']),'new main UI overlap '+id+'/'+z['id'])
audit=subprocess.run([sys.executable,str(D/'audit_layout_v21.py'),'--relocation'],capture_output=True,text=True)
(D/'logs/layout_audit_v21.log').write_text(audit.stdout+audit.stderr)
check(audit.returncode==0,'startup ordering, raw dependency names, relocation and byte-exact runtime preservation')
print(('PASS ' if audit.returncode==0 else 'FAIL ')+'startup/dependency/relocation audit',flush=True)
if audit.returncode:errors.append(audit.stdout+audit.stderr)
node=shutil.which('node');check(bool(node),'Node.js available');syntax=[];suites=[]
if node:
 for p in sorted((ROOT/'javascript').glob('*.js')):
  q=subprocess.run([node,'--check',str(p)],capture_output=True,text=True);syntax.append({'file':p.name,'passed':q.returncode==0});check(q.returncode==0,'JS syntax '+p.name)
  if q.returncode:errors.append(q.stderr)
 for p in sorted(D.glob('test*.cjs')):
  # The keyboard test requires the preset and lane test modules; repeated runs are harmless.
  try:q=subprocess.run([node,str(p)],capture_output=True,text=True,timeout=90);log=q.stdout+q.stderr;code=q.returncode
  except subprocess.TimeoutExpired:code=-1;log='Timed out after 90 seconds.'
  (D/'logs'/p.with_suffix('.log').name).write_text(log);suites.append({'test':p.name,'passed':code==0,'exit_code':code});check(code==0,'suite '+p.name)
  print(('PASS ' if code==0 else 'FAIL ')+p.name,flush=True)
report={'status':'PASS' if not errors else 'FAIL','structural_contract_checks':checks,'statistics':stats,'bundled_references':len(dependencies),'javascript_files':len(syntax),'javascript_syntax':syntax,'suites':suites,'suite_count':len(suites),'passed_suites':sum(x['passed'] for x in suites),'errors':errors,'path_layout_audit':json.loads((D/'layout_audit_results_v21.json').read_text()),'baseline_notes':['The supplied v21(1) differs from its prior snapshots. Earlier whole-object hashes and whole-gallery equality checks were rebased to this exact upload; no runtime content was synchronized.','Behavior models map the original main name to the byte-identical full synth in patchers. All source reads are raw. A separate audit checks the native-only starter, registration-before-load event order, exact runtime hashes and folder relocation. These are not native Max execution tests.'],'limits':['Static JSON/graph/dependency checks and real JS under modeled Task/Dict/Max-message behavior.','No native Max launch, Max GUI/scheduler/serializer validation, CNMAT DSP execution, listening or CPU profiling.']}
(D/'diagnostic_results_v21.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k not in ['javascript_syntax','suites','path_layout_audit']},indent=2))
# Refresh the delivered checksums after reports have been written.
checksum_path=D/'SHA256SUMS_v21.txt'
checksum_path.write_text(''.join(hashlib.sha256(f.read_bytes()).hexdigest()+'  '+f.relative_to(ROOT).as_posix()+'\n' for f in sorted(ROOT.rglob('*')) if f.is_file() and f!=checksum_path and '__pycache__' not in f.parts))
sys.exit(0 if not errors else 1)
