#!/usr/bin/env python3
"""Audit the v21 folder-loader repair. NOT a native Max host.

Checks exact pre-reorganization runtime bytes, bare dependency names, native-only
starter graph, registration-before-open message order, and a relocated copy.
The event simulation implements only the small set of native objects used in the
starter. It does NOT execute Max, its filesystem index, native GUI or CNMAT DSP.
"""
from pathlib import Path
from collections import defaultdict, deque
import argparse, hashlib, json, os, re, shutil, tempfile

ENTRY='_ec_sinusoids_synth_v21.maxpat'
CORE='patchers/_ec_sinusoids_synth_v21_main.maxpat'

def digest(data):return hashlib.sha256(data).hexdigest()

def simulate_launcher(patch, base, repeat=False):
    """Trace actual saved edges, using right-to-left trigger and deferred queues."""
    boxes={x['box']['id']:x['box'] for x in patch['boxes']}
    links=defaultdict(list)
    for wrap in patch.get('lines',[]):
        l=wrap['patchline']; links[tuple(l['source'])].append(l['destination'])
    deferred=deque();events=[];registered=[];active=set();opened=[]
    def emit(id,port,value):
        for dest,inlet in links[(id,port)]:deliver(dest,value)
    def deliver(id,value):
        b=boxes[id];typ=b['maxclass'];text=b.get('text','')
        if typ=='comment':return
        if typ=='message':emit(id,0,[text]);return
        if typ=='textbutton':emit(id,0,['bang']);return
        if typ!='newobj':raise AssertionError('Unsupported starter object '+typ)
        head=text.split()[0]
        if head=='loadbang':emit(id,0,['bang'])
        elif head=='deferlow':deferred.append((id,0,value))
        elif head=='thispatcher':
            assert value==['path'];emit(id,1,[base])
        elif head=='t':
            args=text.split()[1:];assert args==['s','s','s']
            assert len(value)==1 and isinstance(value[0],str)
            for port in reversed(range(len(args))):emit(id,port,value[:])
        elif head=='sprintf':
            assert text.startswith('sprintf symout ')
            assert len(value)==1 and isinstance(value[0],str)
            fmt=text[len('sprintf symout '):];assert fmt.count('%s')==1
            emit(id,0,[fmt.replace('%s',value[0])])
        elif head=='append':
            assert text=='append 0';emit(id,0,value+[0])
        elif head=='prepend':emit(id,0,[text.split(' ',1)[1]]+value)
        elif head=='filepath':
            assert text=='filepath search 0'
            assert len(value)==3 and value[0]=='append' and value[2]==0
            registered.append(value[1]);events.append({'action':'append','folder':value[1],'recursive':0})
        elif head=='pcontrol':
            assert len(value)==2 and value[0]=='loadunique'
            assert base+'patchers/' in registered and base+'javascript/' in registered, 'Core opened before both paths were registered'
            expected=base+CORE;assert value[1]==expected
            new=value[1] not in active
            active.add(value[1]);opened.append(value[1]);events.append({'action':'open' if new else 'front','file':value[1]})
        else:raise AssertionError('Unsupported native object '+head)
    def drain():
        steps=0
        while deferred:
            id,port,value=deferred.popleft();emit(id,port,value);steps+=1
            assert steps<100,'Unbounded starter event loop'
    deliver('launch-loadbang',['bang']);drain()
    if repeat:deliver('launch-button',['bang']);drain()
    return {'events':events,'distinct_synth_instances':len(active),'load_requests':len(opened)}

def audit(root,include_negative=False):
    root=Path(root).resolve();manifest=json.loads((root/'diagnostics/reorganization_manifest_v21.json').read_text())
    errors=[];checks=0;refs=[];docs={};scripts=[];datasets=0;records=0;objects=0;cords=0
    def check(ok,label):
        nonlocal checks
        checks+=1
        if not ok:errors.append(label)
    check({p.name for p in root.iterdir() if p.is_dir()}=={'patchers','javascript','diagnostics'},'exactly three top-level folders')
    check([p.name for p in root.glob('*.maxpat')]==[ENTRY],'only the native starter at root')
    check(not list(root.glob('*.js')),'no JS at root')
    check(all(p.is_file() and p.suffix=='.js' for p in (root/'javascript').iterdir()),'javascript contains only JS')
    check(len(list((root/'javascript').glob('*.js')))==21,'21 runtime JS files')
    check(len(list((root/'patchers').glob('*.maxpat')))==19,'19 original Max patches including the full synth')
    check(len(list((root/'patchers').glob('*.maxhelp')))==1,'one original help file')
    check(manifest['path_edits']=={},'no reference rewriting is hidden in model tests')
    for item in manifest['files']:
        p=root/item['packaged']
        if p.suffix not in ('.maxpat','.maxhelp','.js'):continue
        check(p.is_file(),'runtime exists '+item['packaged'])
        if not p.is_file():continue
        check(digest(p.read_bytes())==item['original_sha256'],'exact pre-layout source bytes '+item['packaged'])
        if p.suffix=='.js':scripts.append(p);continue
        try:docs[item['packaged']]=json.loads(p.read_text())
        except Exception as e:check(False,'Max JSON '+str(p)+': '+str(e))
    names={Path(key).name:key for key in docs}
    searchdirs=[root/'patchers',root/'javascript']
    def reference(owner,loc,kind,name,ext):
        check(isinstance(name,str) and '/' not in name and '\\' not in name and ':' not in name,owner+loc+' bare name '+str(name))
        if not isinstance(name,str):return
        if ext=='.maxpat' and not name.endswith('.maxpat'):name+='.maxpat'
        matches=[folder/name for folder in searchdirs if (folder/name).is_file()]
        check(len(matches)==1,owner+loc+' exactly one local match '+name)
        if len(matches)!=1:return
        target=matches[0]
        check(target.suffix==ext,owner+loc+' correct dependency type')
        check(name in os.listdir(target.parent),owner+loc+' exact case')
        refs.append({'owner':owner,'object_path':loc,'kind':kind,'reference':name,'resolved':target.relative_to(root).as_posix()})
    def walk(p,owner,loc=''):
        nonlocal datasets,records,objects,cords
        boxes={x['box']['id']:x['box'] for x in p.get('boxes',[])};objects+=len(boxes)
        check(len(boxes)==len(p.get('boxes',[])),owner+loc+' unique IDs')
        for wrap in p.get('lines',[]):
            l=wrap['patchline'];cords+=1
            for side,prop in [('source','numoutlets'),('destination','numinlets')]:
                id,port=l[side]
                check(id in boxes,owner+loc+' endpoint '+id)
                if id in boxes:check(isinstance(port,int) and 0<=port<boxes[id].get(prop,0),owner+loc+' saved port range '+str(l[side]))
        for id,b in boxes.items():
            pos=loc+'/'+id;text=b.get('text','');typ=b.get('maxclass')
            if typ=='newobj':
                m=re.match(r'^(?:js|jsui|v8|v8ui|node\.script)\s+(\S+)',text)
                if m:reference(owner,pos,'script',m.group(1),'.js')
                else:
                    token=text.split(' ')[0]
                    if token+'.maxpat' in names or token in names:reference(owner,pos,'abstraction',token,'.maxpat')
                check('Patcher:/' not in text,owner+pos+' no virtual-relative runtime path')
            if typ=='bpatcher' and not b.get('embed'):reference(owner,pos,'bpatcher',b.get('name'),'.maxpat')
            for key in ['filename','jsfilename','jspainterfile']:
                for container,label in [(b,key),(b.get('saved_object_attributes',{}),'saved_'+key)]:
                    v=container.get(key)
                    if isinstance(v,str) and v.endswith('.js'):reference(owner,pos,label,v,'.js')
            if 'coll_data' in b:
                datasets+=1;records+=len(b['coll_data'].get('data',[]))
            if 'patcher' in b:walk(b['patcher'],owner,pos)
    for owner,doc in docs.items():walk(doc['patcher'],owner)
    # These scripts do not open further runtime files by code.
    internal_io=[]
    for s in scripts:
        if re.search(r'\b(?:include|require)\s*\(|\bnew\s+(?:File|Folder)\s*\(',s.read_text()):internal_io.append(s.name)
    check(not internal_io,'no extra script include/File/Folder runtime dependencies')
    reached=set();graph=defaultdict(set)
    for x in refs:graph[x['owner']].add(x['resolved'])
    todo=[CORE]
    while todo:
        n=todo.pop()
        if n in reached:continue
        reached.add(n);todo.extend(graph[n]-reached)
    check(all((root/n).is_file() for n in reached),'full synth dependency closure exists')
    entry=json.loads((root/ENTRY).read_text())['patcher'];walk(entry,ENTRY)
    allowed={'loadbang','deferlow','thispatcher','t','sprintf','append','prepend','filepath','pcontrol'}
    for wrap in entry['boxes']:
        b=wrap['box']
        check(b['maxclass'] in {'newobj','message','textbutton','comment'},'starter native-only class '+b['id'])
        if b['maxclass']=='newobj':check(b['text'].split()[0] in allowed,'starter native-only object '+b['id'])
    test_paths=[root.as_posix()+'/', 'Macintosh HD:/Users/Test User/Synth Ω #1/', 'C:/Users/Test User/Synth Ω #1/']
    cases=[]
    for base in test_paths:
        try:
            trace=simulate_launcher(entry,base,repeat=True)
            check(trace['distinct_synth_instances']==1,'single instance '+base)
            check([e['action'] for e in trace['events']]==['append','append','open','append','append','front'],'register-before-open ordering '+base)
            cases.append({'base':base,'status':'PASS','trace':trace})
        except Exception as e:check(False,'starter simulation '+base+': '+str(e))
    if include_negative:
        # Intentional ordering corruption must not be accepted by the simulator.
        broken=json.loads(json.dumps(entry))
        for w in broken['lines']:
            l=w['patchline']
            if l['source']==['launch-core-path',0]:l['destination']=['launch-pcontrol',0]
        try:simulate_launcher(broken,test_paths[0]);check(False,'negative test: corrupt launch connection was accepted')
        except AssertionError:check(True,'negative test rejects corrupted loader message')
    return {'status':'PASS' if not errors else 'FAIL','checks':checks,'entry':ENTRY,'full_synth':CORE,
      'original_runtime_files_byte_identical':len(docs)+len(scripts),'max_documents_byte_identical':len(docs),
      'javascript_files_byte_identical':len(scripts),'new_native_starter_files':1,
      'restored_path_fields':manifest['loader_repair']['restored_path_fields'],
      'raw_reference_fields_checked':len(refs),'unique_runtime_dependency_files':len({x['resolved'] for x in refs}),
      'main_dependency_closure_files_including_main':len(reached),'main_dependency_closure':sorted(reached),
      'embedded_collection_datasets_preserved':datasets,'embedded_collection_records_preserved':records,
      'objects_including_starter':objects,'cords_including_starter':cords,
      'startup_event_models':cases,'references':refs,'errors':errors,
      'limits':['No native Max execution. Event ordering is checked in a small model of the saved starter graph, not Max itself.',
                'The filesystem audit checks the two registered local directories. It cannot inspect conflicting files in the users Max search preferences.',
                'CNMAT sinusoids~ must remain installed. Restart Max and keep one v21 bundle active when switching versions.']}

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--root',type=Path,default=Path(__file__).resolve().parent.parent)
    ap.add_argument('--relocation',action='store_true');args=ap.parse_args();root=args.root.resolve()
    report=audit(root,include_negative=True)
    if args.relocation:
        with tempfile.TemporaryDirectory(prefix='v21 repaired relocation ') as tmp:
            moved=Path(tmp)/'Renamed synth Ω #1';shutil.copytree(root,moved,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
            unrelated=Path(tmp)/'Unrelated';unrelated.mkdir();cwd=os.getcwd()
            try:os.chdir(unrelated);other=audit(moved)
            finally:os.chdir(cwd)
            good=other['status']=='PASS' and report['references']==other['references']
            report['relocation']={'status':'PASS' if good else 'FAIL','references_identical':report['references']==other['references'],'errors':other['errors']}
            if not good:report['status']='FAIL';report['errors'].append('relocated audit failed')
            # Removing the problem script from a copy must make the audit FAIL.
            (moved/'javascript/multislider_interpolation_engine_v21.js').unlink()
            bad=audit(moved);detected=bad['status']=='FAIL' and any('multislider_interpolation_engine_v21.js' in e for e in bad['errors'])
            report['missing_script_negative_test']={'status':'PASS' if detected else 'FAIL','missing_script_detected':detected}
            if not detected:report['status']='FAIL';report['errors'].append('audit missed deliberately deleted script')
    (root/'diagnostics/layout_audit_results_v21.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in {'references','main_dependency_closure','startup_event_models'}},indent=2))
    return 0 if report['status']=='PASS' else 1
if __name__=='__main__':raise SystemExit(main())
