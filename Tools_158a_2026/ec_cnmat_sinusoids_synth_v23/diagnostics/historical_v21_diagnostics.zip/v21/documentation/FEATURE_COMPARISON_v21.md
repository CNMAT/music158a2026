# Feature comparison: supplied full v20 → full v21

The comparison basis is the two ZIPs supplied with this request. The source master is `_ec_sinusoids_synth_v20-6.maxpat`; the low-CPU reference is build 2.4. This is a selective feature port, not replacement with the low-CPU instrument.

| Feature in supplied low-CPU source | Status in supplied full v20 | v21 decision |
|---|---|---|
| One-to-one/even/odd/prime partial sequences | Missing | Added menu, multiplier-aware rulers and detune shapes; preserve full output generation |
| Whole-window Partial Offset, including slider 1 | Already present | Retained and generalized to sequence positions |
| 150 ms partial add/remove fades | Already present | Retained |
| 150 ms Offset two-bank crossfade | Already present | Retained; sequence identity now uses it too |
| Count changes do not regenerate shapes | Missing at patch level | Cold count update + silent detune count change |
| Same-count no-op preserves running morph | Missing in active memory engine | Added guard without changing true resize fades |
| Timed micro-drift OFF return | Already present | Retained |
| Retuning glide and Auto Level smoothing | Already present | Retained |
| Per-lane DEL 0–3600000 ms | Missing | Added to all twelve full lane abstractions |
| Note-on launches all lanes after pitch target | Missing | Added to existing full keyboard path |
| Shared 50 ms global linear gain | Missing as an all-feed controller | Added; unity default preserves full balance |
| Full sweep/dump/recall engine/UI/store capture | Missing | Adapted to full v21, expanded to automixer/faders |
| Ordered ADSR startup / immediate curve cache | Full startup was not equivalently ordered | Added while retaining embedded tables |
| Immutable shared JS ADSR factory replacement | Different storage architecture | NOT imported; preserve all 33 full-package datasets |
| Render Limit and count ceiling from budget | CPU optimization | NOT imported |
| Dynamic live-slot oscillator allocation/clearing | CPU optimization | NOT imported |
| Optimized generator suppressing extra output work | CPU optimization | NOT imported |
| Suppression of unchanged render messages | CPU optimization | NOT imported |
| Instance-local abstraction, no DAC/MIDI/automixer | Different instrument form | NOT imported |

## Principal edited source locations

The master contains the new controls, note-ordering path, controller, all-output gain integration and new message page. The twelve `ADSR_Lane_*_v21.maxpat` files add DEL and ordered startup. `ADSR_LANE_PANEL_v21.maxpat` and `Send_Message_Space_v21.maxpat` mirror their embedded versions. The standalone `Envelope-Shaper_01_v21.maxpat` retains its own distinct library instead of being replaced by an embedded copy.

`cnmat_sinusoid_model_generator_v21.js` adds spectral sequence mapping, multiplier reporting and layout notification but retains the full generator. `partial_offset_crossfade_v21_6.js` gains the combined sequence/offset layout selector. `multislider_interpolation_engine_v21_6.js` gains the same-count guard. `detune_shape_library_v21.js` and `component_index_ruler_v21.js` use actual selected multipliers. `synth_controller_v21.js` is new. Thirteen active script types gain the low-CPU source's preset transport/state helpers, adapted to the full namespace and schema.

Fifteen of the twenty original JavaScript cores remain text-equivalent after version-name normalization (preset helper additions excluded). The active full renderer core is one of those unchanged cores. The generic automixer v5 script is byte-identical. These counts describe source preservation, not a native runtime performance measurement.

## Compatibility and deliberate adaptations

The new full preset schema rejects low-CPU preset strings. It does not promise phase-exact automixer recall. Global gain starts at 1.0 rather than importing the low-CPU 0.1 default. Full count remains 2–256 with no Render Limit. Existing full control buses are migrated from `_v20` to `_v21`; external patches must address the new names to operate v21. The older full v20 ZIP has not been changed.
