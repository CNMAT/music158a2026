# Native Max verification still required

These checks have not been performed in native Max here. Start at low monitoring levels. The DAC faders remain at -70 dB on load, but named sends/mono feed are pre-DAC-fader. `gain 0` through `Synth_Control_v21` attenuates all feeds.

1. Open only `_ec_sinusoids_synth_v21.maxpat`, with the full folder on the Max search path. Verify no missing JS, abstraction, `sinusoids~` or odot objects in the Max console. Inspect default curve displays before enabling DSP.
2. Verify all twelve lanes initialize to their intended shapes, with DEL 0 and normal smoothing. The Master retains its 45-point default; each lane starts with 48 points. Verify the separate standalone Envelope-Shaper's original stored library remains available.
3. Enable DSP at safe level. Confirm v20-equivalent behavior in default sequence 0, offset disabled, automixer Bypass and new gain 1. Raise appropriate DAC or receive-side gain carefully.
4. Compare all four sequences and offsets 1 and 5. Confirm ruler labels, exact anchors, detune protection only at multiplier 1, original frequency rejection, and smooth transitions on rapid sequence/offset changes.
5. Edit custom spectra, lower count, then return to 256. Confirm hidden slots return and shape presets are not silently reapplied. Resize during a morph and repeat the same count. Listen for discontinuities under scheduler load.
6. Set lane DELs to 0, 250 and 1000 ms. Trigger, retrigger during the wait, edit DEL during a wait, stop before it expires, and use looping. Verify pending starts cannot fire after Stop. Test All Off and automixer Stop behavior together.
7. Test virtual keyboard and actual MIDI note input. Verify pitch target precedes one common trigger, repeated note-ons retrigger, velocity-zero note-offs do not trigger, and direct base-frequency control remains pitch-only.
8. Exercise global gain and Auto Level independently. Confirm gain 0 attenuates named, DAC and mono feeds, unity restores the earlier balance, and the 50 ms gain ramp is smooth.
9. Use check, dump, edit every category, and recall: three 256-slot spectra, hidden slots, signed detune, partial sequence/offset, lane delays/durations/loops, custom function points, user stores, retuning, drift, Auto Level, organ stops, automixer range/mode, separate DAC faders and new gain. Verify recall itself does not play envelopes. Trigger afterward.
10. Save a copied full preset message, close Max, reopen and recall it. Verify no truncation or changed native function/pattr values. Test an intentionally damaged preset and confirm a clear error with no partial recall.
11. Exercise every example in V21_ADDITIONS-message_space and the retained automixer page. Opening either page must not reset settings. Verify message-space preset capture fills the message silently and a click recalls it.
12. Monitor clipping, actual channel assignments and performance at 256 slots. This is deliberately the full CPU-cost architecture; this release has not been CPU-profiled or optimized.
