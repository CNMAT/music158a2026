# Full sinusoids v21 — diagnostics and preservation report

## Release and scope

Open **`_ec_sinusoids_synth_v21.maxpat`** from the complete `ec_cnmat_sinusoids_synth_v21` folder. This release was built from the newly uploaded **`ec_cnmat_sinusoids_synth_v20.zip`**, master `_ec_sinusoids_synth_v20-6.maxpat`. The supplied **`ec_cnmat_sinusiods_abs_lowcpu.zip`**, build 2.4, was used as a functional-feature reference, not as the replacement synthesis engine.

**Automated result: PASS. Native Max and audio result: not tested.**

The tests parse the saved Max graphs, examine their connections and dependencies, run the actual JavaScript under Node.js with modeled Max interfaces, and compare selected content against the original source. They do not load Max, run CNMAT DSP, measure CPU usage, listen to sound, or validate native UI serialization and scheduling.

## Automated results

| Check | Result |
|---|---:|
| Structural / control-contract checks | 46,054 passed |
| Max documents | 19 `.maxpat` + 1 `.maxhelp` |
| Patcher graphs, including top-level graphs | 330 |
| Saved objects | 12,287 |
| Saved patch cords | 9,751 |
| JavaScript files passing syntax checks | 21 / 21 |
| Referenced bundled dependencies resolving locally | 31 / 31 |
| Automated regression suites | 21 / 21 |
| Original embedded collection datasets retained | 33 / 33 |
| Records in those datasets | 24,804 |

Dependency resolution covers the bundled files. A compatible installed CNMAT `sinusoids~` and the other external objects used by the original full synth are still required. Third-party native binaries are not included.

### New-feature test coverage

The sequence/memory/engine suite passed **49,018 assertions**, including **23,970 detune-shape/count combinations** and the public state helpers for 13 engine types. It covers all four sequences, protected actual fundamental identities, sequence/offset transitions, full-bank state, count preservation, and the retained crossfade.

The preset suite passed **133 checks** against the actual controller and generated manifest. It exercised **227 UI controls, 25 engine instances, and 14 user stores**, with 441 engine requests and 10,808 modeled Dict operations. Covered cases include complete capture/recall, validation failures, busy-state behavior, separate DAC-fader restoration, atomic automixer range restoration, and no envelope triggering on recall. The test emulates the native UI and is not a certification of Max's native save/load process.

The DEL suite passed **469 assertions across all twelve lanes**: zero bypass, positive delays, manual/addressed triggering, retrigger replacement, pending-time edits, Stop cancellation, independent instances, and delayed loop restarts. The keyboard suite passed **92 assertions**, including pitch-target dispatch before a common trigger, repeated notes, velocity-zero suppression, recall guards, and no duplicate trigger path.

Ordered-startup tests passed **2,702 assertions**, including cold starts, fresh JSON loads, alternate loadbang order, visible/function-cache initialization, preserved Master/lane point counts, and Full On synchronization. Fresh JSON loading is an emulated test, not native Max reopening.

The inherited tests also cover the existing detune, retuning, drift, octave-family, add/remove, score, copy, renderer and automixer paths. Inherited assertions and filenames were adapted where they described older source versions or earlier timing assumptions. The supplied final suite results report the current v21 contracts; they do not assert that old, incompatible tests passed unchanged.

### Suite results

| Suite | Result |
|---|---|
| `test_engines_v21.cjs` | PASS |
| `test_keyboard_v21.cjs` | PASS |
| `test_lane_delay_v21.cjs` | PASS |
| `test_preset_v21.cjs` | PASS |
| `test_startup_v21.cjs` | PASS |
| `tests_automatic_lines_v5_ed_v21.cjs` | PASS |
| `tests_automixer_integration_v21.cjs` | PASS |
| `tests_automixer_message_space_v21.cjs` | PASS |
| `tests_copy_amplitudes_v21.cjs` | PASS |
| `tests_current_core_v21.cjs` | PASS |
| `tests_detune_v21.cjs` | PASS |
| `tests_envelope_shaper01_v21.cjs` | PASS |
| `tests_micro_drift_v21.cjs` | PASS |
| `tests_octave_families_stage_v21.cjs` | PASS |
| `tests_partial_group_manager_v21.cjs` | PASS |
| `tests_retuning_accuracy_v21.cjs` | PASS |
| `tests_score_execution_v21.cjs` | PASS |
| `tests_seeded_micro_drift_v21.cjs` | PASS |
| `tests_stage_v21.cjs` | PASS |
| `tests_v21_changes_and_stops_v21.cjs` | PASS |
| `tests_workspace_stage_v21.cjs` | PASS |

Full outputs are under `diagnostics/logs/`; the machine-readable summary is `diagnostics/diagnostic_results_v21.json`.

## Preservation audit

The independent source comparison passed. All **33 original collection datasets and their 24,804 records** were retained exactly. The standalone Envelope-Shaper's distinct library was preserved rather than overwritten with the embedded library.

The full rendering subpatch remains structurally equivalent after v20-to-v21 namespace normalization and preset scripting-name additions. Its fixed **1024-ID renderer core** is unchanged after namespace normalization, excluding appended preset-state helpers. All **twelve `sinusoids~` objects** remain. No low-CPU Render Limit, dynamic bank allocation, inactive-bank clearing, unchanged-model suppression, or tagged-only optimized generator was imported.

The existing automixer control subpatch is preserved after namespace normalization. Its main controls are preserved apart from scripting names required by preset capture. **`automatic_lines_v5_ed.js` is byte-for-byte identical to the latest uploaded full source.**

Fifteen of the twenty original JavaScript cores remain text-equivalent after namespace normalization, excluding appended preset helpers. The five intentional core edits are the model generator, offset crossfade, active partial-memory engine, detune shape library, and component ruler. The new full controller is `synth_controller_v21.js`. Many runtime files therefore change: this is **not** a master-only update.

The audit is recorded in `diagnostics/preservation_results_v21.json`. Baseline hashes used by the portable validator are in `diagnostics/source_reference_v21.json`.

## Smoothing: retained versus added

The newly uploaded full v20 already had the 150 ms count fades, 150 ms offset crossfade, shape morphing, retuning glide, timed micro-drift OFF return, Auto Level smoothing, and automixer signal interpolation. These were preserved.

v21 adds a **50 ms all-output gain ramp** and applies the retained **150 ms two-bank crossfade to partial-sequence changes**. Same-count guards avoid cancelling an active morph; ordered envelope initialization avoids starting a curve-initialization morph before its initial data are ready. These are functional changes, not a replacement with the CPU-optimized renderer.

## Preset and operating boundaries

v21 presets use the full-synth schema `ec_cnmat_sinusoids_full_v21`; low-CPU preset payloads are deliberately rejected. A dump captures state but does not automatically write a disk file. Automixer mode and settings are restored, not its instantaneous random-cycle phase. Envelope playback requires a subsequent explicit trigger or note-on.

The new all-output gain starts at unity to preserve the full version's balance. Existing DAC faders retain their -70 dB startup. Named feeds remain pre-DAC-fader, but now also pass through the new all-output gain. Use appropriate gain control on receiving patches.

All synth-owned versioned buses and dependencies use v21. Open one v21 master/editor at a time; this remains a full globally addressed patch, not a multi-instance abstraction.

## Repeat the diagnostics

With Python 3 and Node.js installed, run from the extracted folder:

```sh
python3 run_diagnostics_v21.py
```

The runner resolves its own package directory and includes the executable tests. It updates JSON reports and logs. Re-running tests may change report/log hashes; `SHA256SUMS_v21.txt` describes the initially distributed files, not later generated reports.

## Native verification still required

Before performance use, follow `NATIVE_MAX_CHECKLIST_v21.md`: check external loading, live sequence/offset transitions, retained spectra on count changes, delayed triggers and Stop, note articulation, global gain on every feed, preset round trips, automixer operation, and session reopen behavior. Begin at a safe listening level.

No native Max execution, Max GUI/scheduler/serializer validation, audio auditioning, or CPU profiling has been performed here. The original two uploaded ZIPs remain unchanged.

## Source archive SHA-256

```
5fbf0b4b28f059ead695430cc450f4fa8ba892f707e40233f0f83138ac85b02e  ec_cnmat_sinusoids_synth_v20.zip
a006a84f9fcf84d7d4e2c25055e12f43e8d94aa0a5b84b5ebdd51f6ebf4c0466  ec_cnmat_sinusiods_abs_lowcpu.zip
```
