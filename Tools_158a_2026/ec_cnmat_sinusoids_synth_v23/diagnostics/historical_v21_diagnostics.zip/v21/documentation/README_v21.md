> **Folder-loading repair:** Start with the ROOT `_ec_sinusoids_synth_v21.maxpat` (native starter). The full editable synth is now `patchers/_ec_sinusoids_synth_v21_main.maxpat`. The synthesis behavior described below is unchanged. See `../FOLDER_LOADING_REPAIR_v21.md`.

# ec_cnmat sinusoids — full synth v21

## Open this file

**`_ec_sinusoids_synth_v21.maxpat`**

Extract this complete folder and keep its JavaScript and Max dependencies together. This is a complete release, not a master-patch-only update. Use the same compatible CNMAT `sinusoids~` external and other installed Max externals required by your full v20 instrument. Third-party binary externals are not bundled here.

The baseline is the **newly uploaded `ec_cnmat_sinusoids_synth_v20.zip`**, whose actual master is `_ec_sinusoids_synth_v20-6.maxpat`. Functional additions were compared with the supplied `ec_cnmat_sinusiods_abs_lowcpu.zip` (build 2.4). Earlier conversation builds were not substituted for either upload.

## What v21 adds

### 1. Selectable partial sequences

The **PARTIAL SEQUENCE** menu is in a new strip below the existing main-page controls; scroll down. It is different from the existing spatial/render-lane distribution plan.

| Selection / command value | Multipliers beginning at position 1 |
|---|---|
| One-to-one / 0 (default) | 1, 2, 3, 4, 5, 6... |
| Even / 1 | 1, 2, 4, 6, 8, 10... |
| Odd / 2 | 1, 3, 5, 7, 9, 11... |
| Prime / 3 | 1, 2, 3, 5, 7, 11... |

Leading 1 is intentional, matching the low-CPU implementation. The selected sequence determines the actual multiplier for every displayed slot and harmonic-anchor partner. The three index rulers show those actual multipliers. The detune shape library uses them for frequency-dependent shapes.

Partial Offset selects a **position in the chosen sequence**, without changing BASE FREQ. At N=5, slider 1 begins at 5x F0 (one-to-one), 8x F0 (even), 9x F0 (odd), or 7x F0 (prime). Enable Offset before setting N: the existing enable action resets N to 1. Only an actual multiplier of 1 is protected from detune and micro-drift.

The full v20 already shifted the entire sequence with Offset. That behavior was preserved, not newly invented here. The new sequence changes use the existing 150 ms two-bank crossfade. Rapid changes retain the latest queued target. The original sample-rate/frequency rejection still applies; selecting 256 slots does not promise all high-frequency partials will be audible.

### 2. Count changes preserve the sound you edited

The three shape-resize helpers now update their count without reapplying the selected preset. Detune count updates likewise no longer regenerate a shape. The three 256-slot memories and hidden values survive resizing. Repeating the current count does not interrupt a running shape morph.

To redraw a selected shape over the new count, choose that shape again. The existing 150 ms addition/removal fades remain in place. This change preserves spectral editing behavior; it does not limit rendering or remove any oscillators for CPU savings.

### 3. DEL for each of the twelve envelope lanes

Each lane has an integer **DEL** control, 0–3600000 ms; default 0. DEL postpones the start of that lane after its trigger. It does not change its envelope duration (DUR).

Zero starts immediately. A new trigger replaces a pending start. Changing DEL affects the next trigger, not a start already waiting. Stop cancels pending starts. Loop restarts also observe DEL. The independent values are included in the new full preset format.

### 4. Keyboard and addressed note articulation

An actual virtual-keyboard or MIDI note-on now sends the new pitch target before launching all twelve ADSRs once. A repeated pitch retriggers. Addressed `note-in <pitch> <velocity>` follows that same path. Velocity 0 is ignored for triggering; velocity is not a new amplitude-scaling feature.

The trigger follows pitch-target dispatch; it does not wait for the end of an existing pitch glide. Direct `Source_Base_Hz_v21` edits remain pitch-only. Neither note-in nor trigger enables DSP. The existing physical MIDI input and keyboard were retained.

### 5. Smoothed global gain across all feeds

The new **SMOOTH GLOBAL GAIN** is linear 0–1, with a 50 ms signal ramp. It multiplies the existing Auto Level signal and reaches the twelve named feeds, DAC-fader feeds, and mono output. It is independent of the existing DAC master/channel faders and Auto Level compensation.

**Startup is unity (1.0)** to preserve the full v20 balance. The low-CPU abstraction's 0.1 default was not imported. `gain 0.1` and `gaindb -20` are equivalent; positive dB values clamp to unity. Use `gain 0` to attenuate all feeds. The DAC faders still initialize at their preserved -70 dB settings; they do not attenuate the pre-fader named feeds.

### 6. Full-state sweep / dump / recall

The new preset controller captures **227 UI controls, 25 engine instances, and 14 user stores**, including all three 256-slot memories, hidden slots, envelope functions and delays, Auto Level state, automixer settings, and thirteen DAC/master faders.

`check` tests the public preset endpoints. `sweep` captures internally without emitting a preset. `dump` captures and silently fills the main-page preset message. Clicking that stored message recalls it. Copy the complete `preset ...` message into a message box or a text file to retain it; this release does not add a preset-file dialog or automatically write presets to disk.

Recall validates the complete data, fades the global gain down, stops pending envelopes, restores state, and fades up. All ADSR playback waits for an explicit note-on or trigger. Individual DAC faders are restored after the master so their separate values survive. Automixer range endpoints are restored atomically, and its mode is restored after its settings. Auto mode begins fresh random cycles; the automixer's instantaneous random phase is not captured.

These are **full-synth v21 presets**, not low-CPU abstraction presets. The schemas differ, and low-CPU presets are intentionally rejected rather than partially or incorrectly recalled. A failed import attempts rollback to the captured pre-recall state. Native Max save/load and host callback behavior must still be verified in Max.

### 7. Ordered envelope initialization

Lane initialization establishes duration/count/shape with morphing temporarily disabled, then restores normal smoothing. The Master shaper follows the same ordering and retains its original 45-point default. The twelve lanes retain their 48-point startup. Startup initializes the function and playback cache without triggering sound.

The original embedded collections remain embedded. The separate standalone Envelope-Shaper has a different stored library from the embedded reference shaper; both datasets were preserved rather than forcing them to match.

## Message-space location

Open:

```
p Send_Message_Space_v21
    -> p V21_ADDITIONS-message_space
```

The launcher is below the existing automixer, Auto Level and harmonic-anchor help. The new page has 20 wired examples, descriptions, and passive preset/status readbacks. It opens silently. The existing complete `AUTOMIXER_CONTROL_v21-message space` remains available.

All new controller messages go to **`send Synth_Control_v21`**:

```max
control Partial_Distribution 3
control Partial_Offset_On 1
control Partial_Offset_Number 5
control Partial_Count 256
control ADSR_Lane_01_Delay_ms 500
note-in 60 100
trigger
stop
gain 0.1
gaindb -20
sweep
dump
check
```

The `control` prefix targets existing approved control addresses by their base name; the controller appends `_v21`. Those addresses may also be used directly, for example `send Partial_Distribution_v21` with integer 0–3, or `send ADSR_Lane_01_Delay_ms_v21` with a delay number. Do not append `_v21` to the name after the `control` prefix.

Readbacks: `Synth_Preset_v21` (a `set preset ...` list for the LEFT inlet of a message box), `Synth_Status_v21`, `Synth_Gain_state_v21`, and `Partial_Distribution_state_v21`. Existing per-lane and automixer state buses remain.

## Smoothing that was already in the uploaded full v20

The supplied full version already contains the principal smoothing features: 150 ms partial-count fades, the 150 ms offset crossfade, shape morphing, retuning glide, timed micro-drift OFF return, Auto Level dB smoothing (300 ms default), and automixer signal interpolation. v21 retains these instead of substituting the optimized renderer. The new all-output gain adds a 50 ms ramp; new sequence edits reuse the existing crossfade. The same-count and ordered-startup changes avoid unintended cancellations or empty startup curves.

## What was deliberately NOT imported

No Render Limit selector or 64/128/256 oscillator budget. No dynamic A/B slot allocation, inactive-bank clearing, unchanged-model suppression, tagged-only optimized generator, reduced signal path, or conversion of the full synth into the low-CPU abstraction. The full twelve-`sinusoids~` rendering patch, permanent 1024-ID capacity, spatial matrix, automixer, hardware/DAC controls, and original model/debug outputs remain.

All synth-owned versioned filenames and buses use v21. `automatic_lines_v5_ed.js` keeps its generic original name and exact supplied bytes. Open one v21 master/editor at a time; v21 global buses are isolated from v20, but v21 is not a multi-instance abstraction.

## Verification

See `DIAGNOSTICS_v21.md`, `diagnostics/diagnostic_results_v21.json`, `diagnostics/preservation_results_v21.json`, and `NATIVE_MAX_CHECKLIST_v21.md`.

Run `python3 run_diagnostics_v21.py` with Node.js available to repeat the source and emulation tests. These tests do not run native Max, its GUI/scheduler/serializer, `sinusoids~` DSP, or audio auditioning. No CPU profiling or native-audio certification is claimed.
