# Full v21 release notes

See README_v21.md for operation and FEATURE_COMPARISON_v21.md for source-by-source decisions.

This release modifies more than the master. Install the entire extracted folder. All versioned synth patches, scripts and message buses use v21; the reusable automatic_lines_v5_ed.js retains its original filename and exact bytes.

The full renderer is preserved. New functional controls are partial sequences, memory-preserving count edits, per-lane trigger delays, keyboard/addressed articulation, a smoothed all-output gain, and full preset capture/recall. Startup ordering and preset authority were adapted to the full instrument. Existing smoothing is not misrepresented as new.

All original embedded collection records were retained, including the standalone Envelope-Shaper's distinct data. Existing automixer control logic, original v5 generator, spatial layout and DAC controls remain. New settings use versioned control/readback buses and a passive help page inside Send_Message_Space_v21.

Diagnostics execute actual JavaScript with modeled host messages and inspect saved Max graphs. They are not native Max/DSP or listening tests. Older upload diagnostics referenced an absent master filename and several preexisting old behavior assumptions. The shipped v21 runner uses the actual master and current contracts; legacy assertions tied to old whole-release hashes or pre-timed micro-OFF behavior were updated, not used to certify nonexistent files.
