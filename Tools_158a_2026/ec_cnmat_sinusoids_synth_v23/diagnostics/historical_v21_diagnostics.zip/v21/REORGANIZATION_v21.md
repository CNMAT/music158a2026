# Current folder layout

The previous Patcher:/ path scheme failed in native Max and has been replaced.
See [FOLDER_LOADING_REPAIR_v21.md](FOLDER_LOADING_REPAIR_v21.md) for the current mechanism and evidence.

Open the root `_ec_sinusoids_synth_v21.maxpat` starter. The full instrument is `patchers/_ec_sinusoids_synth_v21_main.maxpat`.
