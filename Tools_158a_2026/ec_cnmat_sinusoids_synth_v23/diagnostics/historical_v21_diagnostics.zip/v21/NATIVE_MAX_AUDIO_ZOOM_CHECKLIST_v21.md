# Native Max: linked views and audio zoom

1. Close other v21 copies and open through the usual starter. Confirm no
   missing scripts, out-of-range cords or missing functions in the Max Console.
2. With output low, start a held/looping spectrum. Set count 32 and choose 4 / 16.
   Amplitudes, Detune and Anchors must all show thirteen slots.
3. Enable Hear displayed only. Only that selected section and its anchors should
   remain after the 100 ms fade. Move either endpoint and listen for continuity.
4. Edit one amplitude and one signed detune. Turn Mirror OFF and edit one anchor.
   Turn audition OFF: full sound returns, crop stays. Click display all: all
   three full views return, showing those edits in their original slots.
5. Try first 0 or last above Partial Count; limits must clamp. Lower Partial Count
   below the displayed range and verify all three views stay synchronized.
6. Change partial sequence/offset while soloed; verify the section remains
   selected across the crossfade. Restore all; no partial should remain muted.
7. Capture/recall a full preset while cropped: complete model is retained and
   recall exits solo. Check normal ADSRs, automixer and independent anchor edits.

**Native Max execution, real audio auditioning and CPU profiling were NOT
performed here.** Passing tests cover sources, saved graphs and emulated
message/scheduler behavior, not native certification. The layout preview is a
schematic rendering, not a Max screenshot.

