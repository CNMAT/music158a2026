#!/usr/bin/env python3
"""Saved-graph, preservation, actual-JS and emulated-message diagnostics, not native Max."""
from pathlib import Path
import copy,hashlib,json,shutil,subprocess,sys
R=Path(__file__).resolve().parent.parent;D=R/'diagnostics'
M=json.loads((D/'PARTIAL_RANGE_UPDATE_MANIFEST_v21.json').read_text())
errors=[];checks=0
stats={'max_documents':0,'patcher_graphs':0,'objects':0,'patch_cords':0,'collections':0,'collection_records':0,'preserved_support_files':0}
def check(v,msg):
 global checks
 checks+=1
 if not v:errors.append(msg)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def canon(obj):return hashlib.sha256(json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
def walk(p):
 yield p
 for e in p.get('boxes',[]):
  if 'patcher' in e['box']:yield from walk(e['box']['patcher'])
main=json.loads((R/M['main_path']).read_text());restored=copy.deepcopy(main);p=restored['patcher']
p['boxes']=[e for e in p['boxes'] if e['box']['id'] not in M['new_box_ids']]
for e in p['boxes']:
 id=e['box']['id']
 if id in M['changed_original_boxes']:e['box']=M['changed_original_boxes'][id]
p['lines']=p['lines'][:M['original_line_count']]
check(canon(restored)==M['original_document_sha256_canonical'],'Unrelated modification to uploaded master')
check(len(p['boxes'])==M['original_box_count'],'Original object count changed')
check(len(p['lines'])==M['original_line_count'],'Original patch-cord count changed')
for f in M['support_files']:
 if f['path'] in [M['main_path'],'javascript/partial_amplitude_display_v21.js']:continue
 if f['path'] in M.get('documentation_updates',{}):
  check(sha(R/f['path'])==M['documentation_updates'][f['path']]['sha256'],'Unexpected guide change '+f['path']);continue
 target=R/f['path'];check(target.is_file() and sha(target)==f['sha256'],'Changed support file '+f['path']);stats['preserved_support_files']+=1
files=[R/'_ec_sinusoids_synth_v21.maxpat']+sorted((R/'patchers').glob('*.maxpat'))+sorted((R/'patchers').glob('*.maxhelp'))+sorted((R/'sinusoids_synth_TUTORIAL').glob('*.maxpat'))
deps=set()
for f in files:
 stats['max_documents']+=1
 for p in walk(json.loads(f.read_text())['patcher']):
  stats['patcher_graphs']+=1;b={e['box']['id']:e['box'] for e in p.get('boxes',[])}
  stats['objects']+=len(b);stats['patch_cords']+=len(p.get('lines',[]))
  check(len(b)==len(p.get('boxes',[])),str(f)+' duplicate IDs')
  for e in p.get('lines',[]):
   l=e['patchline']
   for key,port in [('source','numoutlets'),('destination','numinlets')]:
    id,i=l[key];check(id in b,str(f)+' missing '+id)
    if id in b:check(0<=i<b[id].get(port,0),str(f)+' out-of-range '+id+' '+port)
  for o in b.values():
   text=o.get('text','')
   if text.startswith(('js ','jsui ')):deps.add(text.split()[1])
   if o.get('maxclass')=='jsui' and o.get('filename'):deps.add(o['filename'])
   if o.get('saved_object_attributes',{}).get('filename'):deps.add(o['saved_object_attributes']['filename'])
   if o.get('maxclass')=='bpatcher' and o.get('name'):deps.add(o['name'])
   if 'coll_data' in o:
    stats['collections']+=1;stats['collection_records']+=len(o['coll_data'].get('data',[]))
   if text and (R/'patchers'/(text.split()[0]+'.maxpat')).exists():deps.add(text.split()[0]+'.maxpat')
for n in deps:check(any((x/n).is_file() for x in [R,R/'patchers',R/'javascript']), 'Missing dependency '+n)
stats['dependencies_found']=len(deps)
b={e['box']['id']:e['box'] for e in main['patcher']['boxes']}
check(b['amp-display-range']['text']=='display partials','Range label still hard-codes endpoints')
check(b['amp-viewport-js']['numinlets']==3 and b['amp-viewport-js']['numoutlets']==6,'Helper port declaration mismatch')
lines=main['patcher']['lines']
for s,so,t,ti in M['added_edges']:
 check(any(l['patchline']['source']==[s,so] and l['patchline']['destination']==[t,ti] for l in lines),'Missing added edge '+s+' -> '+t)
for id in ['amp-display-first','amp-display-last']:
 x,y,w,h=b[id]['presentation_rect']
 for o in b.values():
  if o['id']==id or not o.get('presentation') or o.get('hidden') or o.get('background'):continue
  if 'presentation_rect' not in o:continue
  a,c,d,e=o['presentation_rect'];overlap=min(x+w,a+d)>max(x,a)+.1 and min(y+h,c+e)>max(y,c)+.1
  check(not overlap,'New number box overlaps '+o['id'])
node=shutil.which('node');check(node is not None,'Node.js missing');syntax=[];suites=[]
logs=D/'partial_range_regression_logs';logs.mkdir(exist_ok=True)
if node:
 for f in sorted((R/'javascript').glob('*.js')):
  q=subprocess.run([node,'--check',str(f)],capture_output=True,text=True)
  syntax.append({'file':f.name,'passed':q.returncode==0});check(q.returncode==0,'Syntax failed: '+f.name)
 for f in sorted(D.glob('test*.cjs')):
  try:q=subprocess.run([node,str(f)],cwd=R,capture_output=True,text=True,timeout=120);code=q.returncode;log=q.stdout+q.stderr
  except subprocess.TimeoutExpired:code=-1;log='Timed out at 120 seconds.'
  (logs/(f.stem+'.log')).write_text(log)
  suites.append({'test':f.name,'passed':code==0,'exit_code':code});check(code==0,'Regression: '+f.name)
  print(('PASS ' if code==0 else 'FAIL ')+f.name,flush=True)
report={'status':'PASS' if not errors else 'FAIL','checks':checks,'source_patch':M['source_patch'],'source_sha256':M['source_sha256'],'statistics':stats,'syntax':syntax,'regression_suites':suites,'errors':errors,'limitations':['No native Max UI, loader, window behavior, scheduler or audio execution.','Historical snapshot audits use older input hashes; use this runner for the current uploaded master.']}
(D/'PARTIAL_RANGE_DIAGNOSTICS_v21.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('syntax','regression_suites')},indent=2),flush=True)
sys.exit(bool(errors))
