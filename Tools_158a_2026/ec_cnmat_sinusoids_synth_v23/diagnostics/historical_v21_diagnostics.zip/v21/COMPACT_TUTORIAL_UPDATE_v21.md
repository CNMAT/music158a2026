# v21 compact tutorial and amplitude display update

## Baseline

Built from **ec_cnmat_sinusoids_synth_v21(3).zip**, SHA-256:
`81d00d34dc67d7355e72526d78ba775012d252aa2bc7b483d450221ae47c2af9`.

The uploaded folder name **sinusoids_synth_TUTORIAL** is retained. Open the root `_ec_sinusoids_synth_v21.maxpat` as usual. It remains the existing auto-closing starter. The actual instrument is `patchers/_ec_sinusoids_synth_v21_main.maxpat`.

## Tutorial changes

All sixteen lesson windows are **560 × 402** instead of 1060 × 810: 52.8% of the previous width and 49.6% of the previous height, about 26.2% of the previous area. The overview is **560 × 443**, compared with 1120 × 850.

The layouts were reflowed, not merely zoomed out. Visible action messages fit their labels with modest padding. Notes use concise wording; original descriptions remain available in hover hints and the longer reading guide. Long recipes and sends are inside `p LESSON_ACTIONS` and `p PREPARE_RECIPE`, so the main patching canvas no longer extends to remote command boxes.

All 15 standalone Listen messages and their 15 embedded counterparts are **green with black text**. Other action buttons use light backgrounds and black text. The overview contains a three-sentence explanation of additive synthesis using twelve CNMAT sinusoids~ banks, up to 256 primary/anchor slots, and the instrument's major controls.

Each lesson has upper-right **← / →** buttons. Left/right arrow-key releases also navigate while that lesson is frontmost. Navigation opens the adjacent standalone lesson with `loadunique`, then defers closing the current lesson window. At either end, the outward arrow returns to the overview. Tutorial folder paths are obtained at click time from the current containing file, including the embedded overview case; no machine-specific paths or Patcher:/ prefixes are saved.

Navigation sends no sound-setting, trigger, DSP or stop command. Closing or navigating away does not silence a held sound. Existing Prepare, Listen and Silence behavior is unchanged. All **121 original action sequences** remain exact, with only their implementation wiring encapsulated.

## Partial-display controls

The actual synth now has `display partials 1 16` and `display all` beside **HARMONIC PARTIAL AMPLITUDES 0.0–1.0**.

`display partials FIRST LAST` selects an inclusive, 1-based range of active slot positions. Unlock and edit the two numbers, then lock and click. For example, `display partials 5 12` shows eight slots. Bounds are clamped to the current active/rendered count; reversed bounds are sorted. `display all` shows all active slots, not necessarily all 256 capacity slots.

These commands change only the primary-amplitude editing view. They do not set Partial Count, change gain, erase amplitudes or remove sounding partials. Editing a cropped bar updates that bar's original full-spectrum slot. Multipliers follow the sequence and offset. The original full-size multislider and its original preset scripting name remain in place internally; full-synth presets still capture the complete spectrum rather than a cropped list.

The new `javascript/partial_amplitude_display_v21.js` mirrors canonical lists, suppresses display feedback, merges actual manual edits and feeds a range-correct ruler. No synthesis or audio-rendering JavaScript was edited. Detune and anchor editors remain unchanged.

## Exact preservation

**41 of 42 original runtime files are byte-for-byte unchanged**, including all **21 existing JavaScript files**, the root starter, all supporting patches and the help file. The one changed original runtime file is the full main patch.

Within that full main, the only edited original object is the amplitude multislider's visibility. Its original wiring and scripting name remain. The original engine-to-slider cord is assigned an explicit order before the new view listener. Six new UI/helper objects and their connections were added. Reconstructing the original main by removing these declared additions exactly matches its source-document hash, including every embedded subpatch.

All **35 original embedded collection datasets (24,806 records)** are preserved. The twelve original sinusoids~ instances and their audio path are unchanged. The original tutorial action commands are preserved in both the standalone and embedded copies.

The runtime update consists of the full main, one new JavaScript helper, and all seventeen tutorial documents. Guides and diagnostics were updated. The test-only file map was extended to find a newly added script in the existing organized JavaScript directory; the existing 21 regression suites themselves were not rewritten.

## Automated results

| Check | Result |
|---|---:|
| Original regression suites | 21 / 21 passed |
| New display-adapter suite | Passed; 5,383 assertions |
| Total JavaScript suites | 22 / 22 passed |
| Runtime JavaScript syntax | 22 / 22 passed |
| Source / graph / control / layout checks | 63,263 passed |
| Max documents parsed | 38 |
| Standalone / embedded lesson equality | 16 / 16 passed |
| Original lesson action sequences | 121 / 121 preserved |
| Navigation message/focus models | 240 passed |
| Measured text fit and visible tutorial overlaps | Passed |
| On-disk relocation, spaces and Unicode | Passed |
| Deliberately removed view helper detected | Passed |

The new display tests run the actual new helper together with the unchanged interpolation engine in a message-emulation harness. Coverage includes all active counts from 2 to 256, clipping and reversed bounds, single-slot editing, multiplier labels, size-message echo rejection, hidden memory, count fades and shape morphs. Navigation tests follow the delivered patch cords and check open-before-close ordering, active-window gating, adjacent targets, endpoints and path strings with spaces/Unicode.

The complete package and ZIP receive a final checksum and archive-integrity check after this report is written. See `DELIVERY_VERIFICATION_v21.json` for that separate result.

## Verification limits

**No native Max execution, native UI/keyboard/window testing or audio auditioning was performed.** Passing source and modeled-message tests does not certify native loading or playback. Schematic previews use Liberation Sans as an Arial substitute; they are not screenshots from Max. Actual font metrics and window chrome may vary by machine.

Use `NATIVE_MAX_COMPACT_CHECKLIST_v21.md` for the remaining native checks, especially arrow navigation from embedded and standalone lessons, display edits during morphs, and preset capture while cropped.

## Re-run

From the package root, with Python 3 and Node.js:

```sh
python3 -B diagnostics/run_diagnostics_v21.py
python3 -B diagnostics/audit_layout_v21.py --relocation
```

Optional Pillow plus Liberation Sans provides measured text-fit checks. Neither Python nor Node.js is required to run the instrument in Max. Earlier hover-only results and runners are archived under `previous_reports/before_compact_tutorial/`.
