# v21 dependency-loading repair

## What failed

The user's native Max log establishes that the previous organized package failed
to resolve `Patcher:/../javascript/multislider_interpolation_engine_v21.js` and
`Patcher:/../javascript/ec_sinusoid_synth_stops_v21.js`, and failed to instantiate
`Patcher:/ec_sinusoid_synth_stops_research_v21.maxpat`. It then reported deleted
out-of-range patch cords and missing `list`, `tail`, and `beathz` functions.

The prior diagnostic modeled relative paths from the physical file's directory.
It proved that files existed under that assumption, not that Max resolved those
paths in an instantiated bpatcher/abstraction. The native log invalidates the
previous package's claimed loading arrangement. The exact internal cause of Max's
relative-prefix resolution was not independently reproduced in native Max here.

The missing functions and port failures are consistent with the scripts not
being loaded. This repair does not delete cords to silence those errors: it
restores the intact original files and makes the dependency directories available
before the full synth is constructed.

## Delivered structure and changed entry point

Open **`_ec_sinusoids_synth_v21.maxpat` at the root**. This is now a small native-Max
starter, not the full instrument. The full instrument is located at:

`patchers/_ec_sinusoids_synth_v21_main.maxpat`

The starter preserves a one-file entry point while moving every original Max
patch into `patchers/`. The starter itself contains no JS, bpatcher, external
abstraction, audio object, or synthesis send/receive.

1. `loadbang` is deferred, and `path` is sent to a top-level `thispatcher`.
2. Its folder symbol is dispatched using the explicit right-to-left order of
   `trigger s s s`.
3. `sprintf symout` constructs an absolute `patchers/` path and an absolute
   `javascript/` path. Each is sent as `append <folder> 0` to `filepath search 0`.
   Only those two folders are added; `diagnostics/` is not recursively added.
4. Only after both registration messages return is the full-synth absolute
   filename sent through `prepend loadunique`, `deferlow`, and `pcontrol`.
5. The full synth opens as an independent top-level patcher, preserving the
   controller's existing patch-tree relationships. It is not wrapped inside a
   new bpatcher or dynamically rewired.

All original dependency names are restored, including the organ-stop research
abstraction's normal object name. No executable `Patcher:/` dependency references
remain. No loadbang is inserted into the full synth to repair failed JS objects
after their cords have already been connected/deleted.

Max's documented lifecycle initializes objects and connects cords before it
fires loadbang. That is why a separate dependency-free starter is used rather
than a late folder-setting subpatch inside the already-loading instrument.

## Exact preservation

Baseline: **`ec_cnmat_sinusoids_synth_v21(1).zip`**, the user's supplied archive before
folder reorganization.

Source ZIP SHA-256:
`6ce627a8d62831ec6dfeb7a148000cc63f16430e641b80c462198f87b7151062`

| Item | Verified result |
|---|---:|
| Original runtime JavaScript byte-identical | 21 / 21 |
| Original Max patch files byte-identical | 19 / 19 |
| Original help file byte-identical | 1 / 1 |
| Total preserved runtime files | 41 / 41 |
| Reorganization path fields reverted | 95 |
| Original embedded collections | 35 / 35 |
| Original collection records | 24,806 |
| Original saved objects / patch cords | 12,289 / 9,751 |
| Added native starter | 1 file, 24 objects, 17 cords |

The full synth's file bytes are unchanged, including all UI positions, defaults,
smoothing, ADSR lanes, automatic-lines implementation, preset controller,
spatial routing, sends and receives. Its filename gained `_main` to distinguish
it from the root starter. No synthesis algorithm or CPU optimization was changed.

Tests and documentation changed for the new startup arrangement. Historical
relative-path reports are labeled obsolete and retained under
`diagnostics/previous_reports/failed_relative_path_layout/`.

## Automated results

| Check | Result |
|---|---:|
| Existing source/graph/control-contract checks | 46,061 passed |
| Existing behavioral regression suites | 21 / 21 passed |
| Runtime JavaScript syntax checks | 21 / 21 passed |
| Bundled dependency files referenced | 31 / 31 found |
| Full synth dependency closure | 32 files including the full master |
| Exact runtime preservation and starter audit | PASS |
| Starter event model with Unix, Max/macOS and Windows-style paths | PASS |
| Renamed copy containing spaces, Unicode and `#` | PASS |
| Deliberately deleted interpolation script detected | PASS |

The model traces the starter's actual saved patch cords and verifies that both
folders are registered before an open request, and that the repeat-button path
uses `loadunique`. It checks registration and message construction; it does not
execute Max's native loader, path indexing, GUI, scheduler, or DSP.

The source/graph suites read the raw delivered runtime files. A test-only map
redirects the historic logical master name to the full `_main.maxpat` file rather
than to the starter. Unlike the previous diagnostics, no dependency references
are normalized or reversed in memory. The starter is audited separately.

## Operating instructions and limits

Close the failed version without saving, restart Max, and extract the complete
replacement into a fresh folder. Open the root starter. Do not merge a potentially
damaged saved patch into the repaired folder. Do not start the internal `_main`
file directly in a fresh session; its script directory must be registered first.

`filepath append` with preference slot zero is session-only. The starter does
not write persistent File Preferences and does not reset other paths on close.
Restart Max before switching between old and repaired v21 folders. An old v21
folder explicitly stored in persistent File Preferences should not compete with
this copy. The audit cannot inspect a user's local search preferences or cache.

The starter does not enable DSP or alter synth controls. Closing it leaves the
independently opened full synth running; close the full synth window to stop that
instance. Use only one v21 instrument/editor at a time because v21 buses remain
shared. Your installed compatible CNMAT `sinusoids~` external is still required.

**No native Max execution, real audio auditioning, or CPU profiling was performed.**
This package removes the observed failed prefix scheme and supplies the ordered
startup mechanism; confirmation of actual native loading remains the next check.
See `NATIVE_MAX_FOLDER_CHECKLIST_v21.md`.

## Re-run

From the bundle root, with Python 3 and Node.js installed:

```sh
python3 -B diagnostics/run_diagnostics_v21.py
python3 -B diagnostics/audit_layout_v21.py --relocation
```

The synth itself requires neither Python nor Node.js.

## Implementation references

These sources support the Max startup mechanism; all source-preservation findings
above come from comparing the actual supplied files.

- Cycling '74, Patcher Lifecycle: object initialization and patch-cord connection
  precede loadbang. https://docs.cycling74.com/userguide/patcher_lifecycle/
- Cycling '74, filepath: `append` adds a folder; preference 0 does not save it in
  File Preferences. https://docs.cycling74.com/reference/filepath/
- Cycling '74, thispatcher: `path` reports the containing top-level patcher's folder.
  https://docs.cycling74.com/reference/thispatcher/
- Cycling '74, sprintf: `symout` outputs the generated string as one symbol.
  https://docs.cycling74.com/reference/sprintf/
- Cycling '74, pcontrol: `loadunique` opens or activates a single file instance.
  https://docs.cycling74.com/reference/pcontrol/
