#!/usr/bin/env python3
"""Current linked-view/audio-zoom diagnostic entry; older snapshot runners are historical."""
from pathlib import Path
import runpy
runpy.run_path(str(Path(__file__).with_name('run_audio_zoom_diagnostics_v21.py')),run_name='__main__')
