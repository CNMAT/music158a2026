# Native Max checks still to perform

1. Close older v21 copies. Open the current top-level starter in a fresh Max session. Confirm that the full instrument opens, the starter closes, and no missing-file or deleted-cord errors appear. The startup behavior was preserved, not independently re-executed here.
2. Keep the synth locked. Pause over a partial slider, shape menu, gain, drift control, routing control and automixer control. Confirm that a short hint appears. Check its matching annotation in Max’s Clue tab.
3. Open the twelve-lane panel. Test PTS, DUR, DEL, shape, smoothing, TRIG, LOOP, memory number, STO and RCL on several lanes, including lane 12. Avoid overwriting an occupied user-function slot.
4. Open the tutorial index and several lessons. Opening, navigation and closing must not change sound, DSP state or controls.
5. Preserve any current sound before Prepare. Run stage 1 Prepare. Confirm two output groups, −24 dB DAC gains, global gain zero and no automatically triggered envelope. Check your audio device, then enable DSP manually at low hardware volume. Listen should play a four-second note.
6. Test Silence while a held note or a loop is running. It should mute all feeds and stop the lanes. The spectral bars should remain.
7. Stage 3: compare a 3-second spectral morph and reducing/restoring the visible count. Stage 7: confirm the sequence rulers follow normal/even/odd/prime and offset.
8. Stage 9: trigger lane 1 and delayed lane 2 separately. Check that cancelling lane 2 clears a pending delayed start. Test storing/recalling points in an unused slot, not a production slot.
9. Stage 13: compare Automixer Bypass, Auto mix and Stop/mute. The ADSRs must be sounding first; automixer start does not trigger them.
10. Stage 16: use dump, copy its populated preset message to a separate patch and save it. Change the sound, recall the saved message and trigger. Verify the restored settings at a safe gain.

A tutorial lesson is not a separate synth instance. It addresses the running v21 instrument’s named controls. Keep only one v21 instrument/editor active. Closing a tutorial does not stop audio: click Silence.
