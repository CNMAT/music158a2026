# Current diagnostics: linked views and audio zoom

Run `python3 -B diagnostics/run_diagnostics_v21.py` from the package root.
Read `AUDIO_ZOOM_DIAGNOSTICS_v21.json`, `AUDIO_ZOOM_UPDATE_v21.md`, and
`NATIVE_MAX_AUDIO_ZOOM_CHECKLIST_v21.md`. Older snapshot reports and runners
remain for provenance and use their historical input hashes.

# Current compact tutorial / partial-display diagnostics

Source: **ec_cnmat_sinusoids_synth_v21(3).zip**.

Run from the package root with Python 3 and Node.js:

```sh
python3 -B diagnostics/run_diagnostics_v21.py
```

The runner compares 41 byte-identical original runtime files, reconstructs the original main patch after removing only declared view additions, checks all original tutorial action commands, patch ports, navigation graphs, passive opening, bounds and overlaps, and executes the original 21 JavaScript suites plus the new partial-display suite. Optional Pillow/font availability adds measured text-fit checks. Python and Node.js are not needed to use the synth.

Current report: **COMPACT_TUTORIAL_UPDATE_v21.md**. Machine-readable results: **COMPACT_TUTORIAL_RESULTS_v21.json** and **PARTIAL_DISPLAY_RESULTS_v21.json**. Logs: **compact_regression_logs/**. Source hashes and permitted edits: **COMPACT_SOURCE_MANIFEST_v21.json**. Window sizes and neighbors: **COMPACT_LAYOUTS_v21.json**. Delivery checksums: **SHA256SUMS_v21.txt**.

**NATIVE_MAX_COMPACT_CHECKLIST_v21.md** lists checks that still require Max. **layout_previews/** contains schematic renders, not native screenshots.

Earlier reports and hover-only runners are historical, including **previous_reports/before_compact_tutorial/**. Other old manifests exist to support legacy regression test file mapping; they are not the current build's source baseline.

No native Max, keyboard, window manager, external binary, DSP or acoustic test is represented by automated results.
