EC 4X Filter Bank v6 — filter gain range update

Unzip this folder. Keep the two companion .js files beside the .maxpat.
Open _ec_4X_filterbank_v6.maxpat from this folder.
Replace the matching files in your current package with these three files.
The original filenames and internal script references are restored.

All four Filter gain / dB controls, signal clamps, graph values, preset recall,
and state import/export now support -36 to +36 dB.
Hover over Motion depth / ±Hz or Gain depth / ±dB, or their number boxes,
for the curve formula, an example, playback instructions, and the limits.

OUTPUT faders remain -24 to +12 dB. Global Gain Out remains -36 to +12 dB.
Existing presets, saved working values, layout, and smoothing are preserved.
To replace a preset, choose its slot, click Store, and save the main patch.

Validated with JSON/patchcord checks and simulated Max JavaScript execution.
Native Max audio and UI testing was not available in this environment.

Global Gain Out now opens at -12 dB. Stored presets retain their own gain values.
