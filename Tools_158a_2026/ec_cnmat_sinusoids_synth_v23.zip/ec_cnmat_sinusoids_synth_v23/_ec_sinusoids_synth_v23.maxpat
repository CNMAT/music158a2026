{
  "patcher": {
    "fileversion": 1,
    "appversion": {
      "major": 9,
      "minor": 1,
      "revision": 5,
      "architecture": "x64",
      "modernui": 1
    },
    "classnamespace": "box",
    "rect": [
      80.0,
      80.0,
      760.0,
      350.0
    ],
    "openinpresentation": 1,
    "default_fontsize": 13.0,
    "default_fontname": "Arial",
    "gridsize": [
      15.0,
      15.0
    ],
    "title": "SINUSOIDS v23 - START HERE",
    "description": "Registers dependency folders, opens the full synth via a correctly formed loadunique message, then closes only this starter.",
    "boxes": [
      {
        "box": {
          "id": "launch-title",
          "maxclass": "comment",
          "numinlets": 1,
          "numoutlets": 0,
          "patching_rect": [
            24.0,
            18.0,
            680.0,
            32.0
          ],
          "text": "SINUSOIDS v23 | FOLDER-AWARE STARTUP",
          "fontsize": 21,
          "fontface": 1,
          "presentation": 1,
          "presentation_rect": [
            24.0,
            18.0,
            700.0,
            32.0
          ]
        }
      },
      {
        "box": {
          "id": "launch-explain",
          "maxclass": "comment",
          "numinlets": 1,
          "numoutlets": 0,
          "patching_rect": [
            24.0,
            61.0,
            700.0,
            38.0
          ],
          "text": "Automatically opens the full synth, then closes this starter window.\nThe synth remains open; no sound settings are changed.",
          "fontsize": 14,
          "presentation": 1,
          "presentation_rect": [
            24.0,
            61.0,
            700.0,
            38.0
          ]
        }
      },
      {
        "box": {
          "id": "launch-button",
          "maxclass": "textbutton",
          "numinlets": 1,
          "numoutlets": 3,
          "patching_rect": [
            24.0,
            109.0,
            290.0,
            34.0
          ],
          "text": "Open / bring synth to front",
          "outlettype": [
            "",
            "int",
            "int"
          ],
          "texton": "Open / bring synth to front",
          "mode": 0,
          "parameter_enable": 0,
          "fontsize": 14,
          "presentation": 1,
          "presentation_rect": [
            24.0,
            109.0,
            290.0,
            34.0
          ],
          "hint": "Register the dependency folders, open or bring forward the full synth, then close this starter.",
          "annotation": "Register the dependency folders, open or bring forward the full synth, then close this starter."
        }
      },
      {
        "box": {
          "id": "launch-core-note",
          "maxclass": "comment",
          "numinlets": 1,
          "numoutlets": 0,
          "patching_rect": [
            24.0,
            157.0,
            700.0,
            46.0
          ],
          "text": "Full editable synth: patchers/_ec_sinusoids_synth_v23_main.maxpat\nEdit and save the full synth window, not this starter.",
          "fontsize": 13,
          "presentation": 1,
          "presentation_rect": [
            24.0,
            157.0,
            700.0,
            46.0
          ]
        }
      },
      {
        "box": {
          "id": "launch-session-note",
          "maxclass": "comment",
          "numinlets": 1,
          "numoutlets": 0,
          "patching_rect": [
            24.0,
            212.0,
            700.0,
            55.0
          ],
          "text": "Search folders remain registered for this Max session. Reopen this starter to open or bring forward the same synth; the starter closes again after handoff.",
          "fontsize": 13,
          "presentation": 1,
          "presentation_rect": [
            24.0,
            212.0,
            700.0,
            55.0
          ]
        }
      },
      {
        "box": {
          "id": "launch-warning",
          "maxclass": "comment",
          "numinlets": 1,
          "numoutlets": 0,
          "patching_rect": [
            24.0,
            280.0,
            700.0,
            45.0
          ],
          "text": "Keep patchers/, javascript/, and diagnostics/ beside this file. Use only one v23 synth folder per Max session.",
          "fontsize": 12,
          "presentation": 1,
          "presentation_rect": [
            24.0,
            280.0,
            700.0,
            45.0
          ]
        }
      },
      {
        "box": {
          "id": "launch-loadbang",
          "maxclass": "newobj",
          "numinlets": 1,
          "numoutlets": 1,
          "patching_rect": [
            24.0,
            370.0,
            72.0,
            22.0
          ],
          "text": "loadbang",
          "outlettype": [
            ""
          ]
        }
      },
      {
        "box": {
          "id": "launch-defer-start",
          "maxclass": "newobj",
          "numinlets": 1,
          "numoutlets": 1,
          "patching_rect": [
            24.0,
            411.0,
            68.0,
            22.0
          ],
          "text": "deferlow",
          "outlettype": [
            ""
          ]
        }
      },
      {
        "box": {
          "id": "launch-path",
          "maxclass": "message",
          "numinlets": 2,
          "numoutlets": 1,
          "patching_rect": [
            24.0,
            453.0,
            45.0,
            22.0
          ],
          "text": "path",
          "outlettype": [
            ""
          ],
          "hint": "Click to send: path.",
          "annotation": "Click to send: path."
        }
      },
      {
        "box": {
          "id": "launch-thispatcher",
          "maxclass": "newobj",
          "numinlets": 1,
          "numoutlets": 2,
          "patching_rect": [
            24.0,
            497.0,
            90.0,
            22.0
          ],
          "text": "thispatcher",
          "outlettype": [
            "",
            "symbol"
          ]
        }
      },
      {
        "box": {
          "id": "launch-order",
          "maxclass": "newobj",
          "numinlets": 1,
          "numoutlets": 3,
          "patching_rect": [
            24.0,
            539.0,
            70.0,
            22.0
          ],
          "text": "t s s s",
          "outlettype": [
            "symbol",
            "symbol",
            "symbol"
          ]
        }
      },
      {
        "box": {
          "id": "launch-patchers-path",
          "maxclass": "newobj",
          "numinlets": 1,
          "numoutlets": 1,
          "patching_rect": [
            420.0,
            580.0,
            195.0,
            22.0
          ],
          "text": "sprintf symout %spatchers/",
          "outlettype": [
            ""
          ]
        }
      },
      {
        "box": {
          "id": "launch-patchers-flag",
          "maxclass": "newobj",
          "numinlets": 1,
          "numoutlets": 1,
          "patching_rect": [
            420.0,
            620.0,
            70.0,
            22.0
          ],
          "text": "append 0",
          "outlettype": [
            ""
          ]
        }
      },
      {
        "box": {
          "id": "launch-patchers-append",
          "maxclass": "newobj",
          "numinlets": 1,
          "numoutlets": 1,
          "patching_rect": [
            420.0,
            660.0,
            120.0,
            22.0
          ],
          "text": "prepend append",
          "outlettype": [
            ""
          ]
        }
      },
      {
        "box": {
          "id": "launch-javascript-path",
          "maxclass": "newobj",
          "numinlets": 1,
          "numoutlets": 1,
          "patching_rect": [
            215.0,
            580.0,
            200.0,
            22.0
          ],
          "text": "sprintf symout %sjavascript/",
          "outlettype": [
            ""
          ]
        }
      },
      {
        "box": {
          "id": "launch-javascript-flag",
          "maxclass": "newobj",
          "numinlets": 1,
          "numoutlets": 1,
          "patching_rect": [
            215.0,
            620.0,
            70.0,
            22.0
          ],
          "text": "append 0",
          "outlettype": [
            ""
          ]
        }
      },
      {
        "box": {
          "id": "launch-javascript-append",
          "maxclass": "newobj",
          "numinlets": 1,
          "numoutlets": 1,
          "patching_rect": [
            215.0,
            660.0,
            120.0,
            22.0
          ],
          "text": "prepend append",
          "outlettype": [
            ""
          ]
        }
      },
      {
        "box": {
          "id": "launch-filepath",
          "maxclass": "newobj",
          "numinlets": 1,
          "numoutlets": 1,
          "patching_rect": [
            325.0,
            710.0,
            120.0,
            22.0
          ],
          "text": "filepath search 0",
          "outlettype": [
            ""
          ]
        }
      },
      {
        "box": {
          "id": "launch-core-path",
          "maxclass": "newobj",
          "numinlets": 1,
          "numoutlets": 1,
          "patching_rect": [
            155.0,
            780.0,
            515.0,
            22.0
          ],
          "text": "sprintf symout %spatchers/_ec_sinusoids_synth_v23_main.maxpat",
          "outlettype": [
            ""
          ]
        }
      },
      {
        "box": {
          "id": "launch-load-message",
          "maxclass": "newobj",
          "numinlets": 1,
          "numoutlets": 1,
          "patching_rect": [
            205.0,
            905.0,
            135.0,
            22.0
          ],
          "text": "prepend loadunique",
          "outlettype": [
            ""
          ]
        }
      },
      {
        "box": {
          "id": "launch-defer-open",
          "maxclass": "newobj",
          "numinlets": 1,
          "numoutlets": 1,
          "patching_rect": [
            155.0,
            820.0,
            62.0,
            22.0
          ],
          "text": "deferlow",
          "outlettype": [
            ""
          ]
        }
      },
      {
        "box": {
          "id": "launch-pcontrol",
          "maxclass": "newobj",
          "numinlets": 1,
          "numoutlets": 1,
          "patching_rect": [
            205.0,
            945.0,
            66.0,
            22.0
          ],
          "text": "pcontrol",
          "outlettype": [
            ""
          ]
        }
      },
      {
        "box": {
          "id": "launch-order-doc",
          "maxclass": "comment",
          "numinlets": 1,
          "numoutlets": 0,
          "patching_rect": [
            580.0,
            380.0,
            420.0,
            85.0
          ],
          "text": "Startup ordering is deliberate: register BOTH folders before creating any synth JS or bpatcher. Do not put filepath/loadbang inside the full synth instead: that runs after object construction and cannot prevent deleted cords.",
          "fontsize": 13
        }
      },
      {
        "box": {
          "id": "launch-no-revert-doc",
          "maxclass": "comment",
          "numinlets": 1,
          "numoutlets": 0,
          "patching_rect": [
            580.0,
            485.0,
            420.0,
            85.0
          ],
          "text": "No filepath revert/clear, persistent preference write, or audio control messages. Closing this starter leaves the independently opened synth running. Quit/restart Max before switching between v23 bundles.",
          "fontsize": 13
        }
      },
      {
        "box": {
          "id": "launch-open-then-close",
          "maxclass": "newobj",
          "numinlets": 1,
          "numoutlets": 2,
          "patching_rect": [
            155.0,
            860.0,
            54.0,
            22.0
          ],
          "text": "t b s",
          "outlettype": [
            "bang",
            "symbol"
          ]
        }
      },
      {
        "box": {
          "id": "launch-close-delay",
          "maxclass": "newobj",
          "numinlets": 2,
          "numoutlets": 1,
          "patching_rect": [
            40.0,
            905.0,
            74.0,
            22.0
          ],
          "text": "delay 250",
          "outlettype": [
            "bang"
          ]
        }
      },
      {
        "box": {
          "id": "launch-defer-close",
          "maxclass": "newobj",
          "numinlets": 1,
          "numoutlets": 1,
          "patching_rect": [
            40.0,
            945.0,
            62.0,
            22.0
          ],
          "text": "deferlow",
          "outlettype": [
            ""
          ]
        }
      },
      {
        "box": {
          "id": "launch-close-message",
          "maxclass": "message",
          "numinlets": 2,
          "numoutlets": 1,
          "patching_rect": [
            40.0,
            985.0,
            55.0,
            22.0
          ],
          "text": "wclose",
          "outlettype": [
            ""
          ],
          "hint": "Click to send: wclose.",
          "annotation": "Click to send: wclose."
        }
      },
      {
        "box": {
          "id": "launch-autoclose-doc",
          "maxclass": "comment",
          "numinlets": 1,
          "numoutlets": 0,
          "patching_rect": [
            370.0,
            865.0,
            470.0,
            165.0
          ],
          "fontsize": 13.0,
          "text": "AUTO-CLOSE / CONNECTION FIX: the full filename arrives as one symbol at t b s. The RIGHT symbol outlet goes through prepend loadunique to pcontrol FIRST. After that call returns, the LEFT bang outlet starts delay 250. A final deferlow sends wclose only to THIS starter. There is no direct trigger-to-pcontrol connection and no t b a (a is not a Max pass-through format). This is ordered handoff, not confirmation of successful dependency loading. Check the Max Console."
        }
      }
    ],
    "lines": [
      {
        "patchline": {
          "source": [
            "launch-loadbang",
            0
          ],
          "destination": [
            "launch-defer-start",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "launch-button",
            0
          ],
          "destination": [
            "launch-defer-start",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "launch-defer-start",
            0
          ],
          "destination": [
            "launch-path",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "launch-path",
            0
          ],
          "destination": [
            "launch-thispatcher",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "launch-thispatcher",
            1
          ],
          "destination": [
            "launch-order",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "launch-order",
            2
          ],
          "destination": [
            "launch-patchers-path",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "launch-patchers-path",
            0
          ],
          "destination": [
            "launch-patchers-flag",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "launch-patchers-flag",
            0
          ],
          "destination": [
            "launch-patchers-append",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "launch-patchers-append",
            0
          ],
          "destination": [
            "launch-filepath",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "launch-order",
            1
          ],
          "destination": [
            "launch-javascript-path",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "launch-javascript-path",
            0
          ],
          "destination": [
            "launch-javascript-flag",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "launch-javascript-flag",
            0
          ],
          "destination": [
            "launch-javascript-append",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "launch-javascript-append",
            0
          ],
          "destination": [
            "launch-filepath",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "launch-order",
            0
          ],
          "destination": [
            "launch-core-path",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "launch-core-path",
            0
          ],
          "destination": [
            "launch-defer-open",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "launch-load-message",
            0
          ],
          "destination": [
            "launch-pcontrol",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "launch-defer-open",
            0
          ],
          "destination": [
            "launch-open-then-close",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "launch-open-then-close",
            1
          ],
          "destination": [
            "launch-load-message",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "launch-open-then-close",
            0
          ],
          "destination": [
            "launch-close-delay",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "launch-close-delay",
            0
          ],
          "destination": [
            "launch-defer-close",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "launch-defer-close",
            0
          ],
          "destination": [
            "launch-close-message",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "launch-close-message",
            0
          ],
          "destination": [
            "launch-thispatcher",
            0
          ]
        }
      }
    ],
    "autosave": 0
  }
}
