/* v23: independent linear shape morphs with 256-slot per-partial memory.
 * 0..2 target lists; 3..5 manual/current slider feedback; 6..8 morph ms; 9 count.
 * 0..2 outputs to the three multisliders (size messages plus value lists).
 * Outlet 3 brackets indexed edits with beginupdate/endupdate; inlet 10 accepts
 * zeroindices and restoreindices INDEX DETUNE AMPLITUDE ANCHOR records.
 * Only active slots are changed by edits/shapes/random lists; hidden slots survive.
 * v23-6: count births/deaths use the SAME 150 ms amplitudes for UI and synthesis.
 * Outlet 5 owns the actual displayed/rendered count. A requested decrease keeps
 * departing bars/oscillators alive until their amplitudes reach exactly zero.
 * Outlets 6/7 are authoritative anchor/primary amplitude lists for synthesis and
 * remove/add snapshots. UI amplitude outlets now feed back ONLY to inlets 5/4.
 * Inlet 10: anchormirror 0|1; anchorscale 0..1 (absolute, noncompounding).
 * Anchor patterns are retained unscaled internally; shown/audio values reflect
 * the scale. Mirror uses the primary's current level, including count fades.
 */
autowatch=1;
inlets=11;
outlets=8;
var capacity=256, componentCount=32;
var displayCount=32, PARTIAL_FADE_MS=150;
// memory/current hold nominal levels; lifecycle ramps never erase saved levels.
// mode: 0 hidden, 1 active, 2 entering, 3 departing.
var lifeMode=[],lifeEnd=[],lifeStart=[[],[],[]],lifeTime=[[],[],[]],lifeTarget=[[],[],[]];
var lifeTask=new Task(lifeTick,this),lifeRunning=false;
lifeTask.interval=5;
var durations=[1000,1000,1000], activeDuration=[1000,1000,1000];
var memory=[[],[],[]], current=[[],[],[]], starts=[[],[],[]], targets=[[],[],[]];
var lastDrawn=[[],[],[]];
var anchorMirror=false,anchorScale=1.0,updateDepth=0;
var initialized=[false,false,false], running=[false,false,false], outputGuard=[false,false,false];
var startTimes=[0,0,0];
var tasks=[new Task(tick,this,0),new Task(tick,this,1),new Task(tick,this,2)];
var c,i;
for(c=0;c<3;c++){
    tasks[c].interval=20;
    for(i=0;i<capacity;i++)memory[c][i]=0.0;
}
// The library applies the startup amplitude profile only to the active slots.
for(c=0;c<3;c++)current[c]=memory[c].slice(0,componentCount);
for(i=0;i<capacity;i++){
    lifeMode[i]=i<componentCount?1:0;lifeEnd[i]=0;
    for(c=0;c<3;c++){lifeStart[c][i]=0;lifeTime[c][i]=0;lifeTarget[c][i]=0;}
}
function nowMs(){return (new Date()).getTime();}
function beginModel(){if(updateDepth++===0)outlet(3,"beginupdate");}
function endModel(){if(updateDepth>0&&--updateDepth===0)outlet(3,"endupdate");}
function clipped(x,channel){x=Number(x);return isFinite(x)?Math.round(Math.max(channel===0?-1:0,Math.min(1,x))*1000000)/1000000:0;}
function clean(values,channel){var r=[],i;for(i=0;i<values.length;i++)r[i]=clipped(values[i],channel);return r;}
function store(channel,values){
    // Never update hidden components from a short active list.
    var limit=Math.min(componentCount,values.length),i;
    for(i=0;i<limit;i++)memory[channel][i]=clipped(values[i],channel);
    current[channel]=memory[channel].slice(0,componentCount);
}
function lifeValue(channel,index,time){
    var mode=lifeMode[index];
    if(mode===0)return 0;
    if(channel===0)return mode===3?lifeStart[0][index]:memory[0][index];
    if(mode===1)return memory[channel][index];
    var fraction=Math.max(0,Math.min(1,(time-lifeTime[channel][index])/
        Math.max(1,lifeEnd[index]-lifeTime[channel][index])));
    var target=mode===3?0:lifeTarget[channel][index];
    return clipped(lifeStart[channel][index]+(target-lifeStart[channel][index])*fraction,channel);
}
function synchronizeEntryTargets(channel,time){
    if(channel===0)return;
    for(var i=0;i<componentCount;i++)if(lifeMode[i]===2&&lifeTarget[channel][i]!==memory[channel][i]){
        lifeStart[channel][i]=lifeValue(channel,i,time);
        lifeTime[channel][i]=time;
        lifeTarget[channel][i]=memory[channel][i];
    }
}
function visibleValues(channel,time){
    var values=[];
    for(var i=0;i<displayCount;i++){
        var value=lifeValue(channel===2&&anchorMirror?1:channel,i,time);
        if(channel>0&&fullMorphMask)value*=fullMorphMask[i];
        values.push(channel===2?clipped(value*anchorScale,2):value);
    }
    return values;
}
function draw(channel,resize,time){
    if(channel===2&&anchorMirror){
        memory[2]=memory[1].slice(0);current[2]=memory[2].slice(0,componentCount);
    }
    synchronizeEntryTargets(channel,time);
    outputGuard[channel]=true;
    if(resize)outlet(channel,"size",displayCount);
    lastDrawn[channel]=visibleValues(channel,time);
    outlet(channel,lastDrawn[channel].slice(0));
    // Size-generated UI echoes and edits cannot bypass these canonical lists.
    if(channel===2)outlet(6,lastDrawn[2].slice(0));
    else if(channel===1)outlet(7,lastDrawn[1].slice(0));
    outputGuard[channel]=false;
}
function emit(channel,values,resize){
    store(channel,values);
    var time=nowMs();beginModel();
    draw(channel,resize,time);
    if(channel===1&&anchorMirror)draw(2,resize,time);
    endModel();
}
function frame(resize,time){
    // Generator holds the entire resize transaction, including size-generated
    // UI echoes, so no intermediate cached amplitude can reach the audio model.
    beginModel();
    if(resize)outlet(5,displayCount);
    for(var c=0;c<3;c++)draw(c,resize,time);
    endModel();
}
function updateLifeTask(){
    var active=false;
    for(var i=0;i<capacity;i++)if(lifeMode[i]===2||lifeMode[i]===3){active=true;break;}
    if(active&&!lifeRunning){lifeRunning=true;lifeTask.repeat();}
    else if(!active&&lifeRunning){lifeTask.cancel();lifeRunning=false;}
}
function lifeTick(){
    var time=nowMs(),i,c,oldCount=displayCount;
    for(c=0;c<3;c++)materialize(c);
    // Emit departing amplitudes at zero BEFORE deleting their UI/oscillator IDs.
    frame(false,time);
    for(i=0;i<capacity;i++)if(time>=lifeEnd[i]){
        if(lifeMode[i]===2)lifeMode[i]=1;
        else if(lifeMode[i]===3)lifeMode[i]=0;
    }
    displayCount=componentCount;
    for(i=componentCount;i<capacity;i++)if(lifeMode[i]===3)displayCount=i+1;
    if(displayCount!==oldCount)frame(true,time);
    updateLifeTask();
}
function notifydeleted(){lifeTask.cancel();for(var c=0;c<3;c++)tasks[c].cancel();}
function materialize(channel){
    if(!running[channel])return;
    var t=Math.max(0,Math.min(1,(nowMs()-startTimes[channel])/activeDuration[channel]));
    var values=[],i;
    for(i=0;i<componentCount;i++)values[i]=clipped(starts[channel][i]+(targets[channel][i]-starts[channel][i])*t,channel);
    store(channel,values);
    if(t>=1){running[channel]=false;tasks[channel].cancel();}
}
function setCount(value){
    value=Math.max(2,Math.min(capacity,Math.round(Number(value))));
    if(!isFinite(value))return;
    // Repeated count messages must not interrupt ongoing morphs or lifecycle fades.
    if(value===componentCount){frame(true,nowMs());return;}
    var time=nowMs(),oldCount=componentCount,i,c;
    for(c=0;c<3;c++){
        materialize(c);synchronizeEntryTargets(c,time);tasks[c].cancel();running[c]=false;
    }
    for(i=Math.min(oldCount,value);i<Math.max(oldCount,value);i++){
        for(c=0;c<3;c++){
            lifeStart[c][i]=lifeValue(c,i,time);
            lifeTime[c][i]=time;
            lifeTarget[c][i]=memory[c][i];
        }
        lifeMode[i]=i<value?2:3;
        lifeEnd[i]=time+PARTIAL_FADE_MS;
    }
    componentCount=value;
    displayCount=value;
    for(i=value;i<capacity;i++)if(lifeMode[i]===3)displayCount=i+1;
    for(c=0;c<3;c++)current[c]=memory[c].slice(0,componentCount);
    frame(true,time);
    updateLifeTask();
}
function target(channel,values){
    if(channel===2&&anchorMirror)return;
    if(values.length!==componentCount)return;
    materialize(channel);tasks[channel].cancel();
    targets[channel]=clean(values,channel);
    starts[channel]=memory[channel].slice(0,componentCount);
    // A resized preset supplies the destination for new bars immediately.
    // Its ordinary shape-morph duration still governs already-active bars.
    // Pin both shape endpoints for entering bars: no second ramp or snap-back
    // after their independent 150 ms lifecycle finishes.
    if(channel>0)for(var i=0;i<componentCount;i++)if(lifeMode[i]===2){
        starts[channel][i]=targets[channel][i];memory[channel][i]=targets[channel][i];
    }
    if(!initialized[channel]||durations[channel]<=0){
        initialized[channel]=true;running[channel]=false;emit(channel,targets[channel],false);return;
    }
    initialized[channel]=true;startTimes[channel]=nowMs();activeDuration[channel]=durations[channel];
    running[channel]=true;emit(channel,starts[channel],false);tasks[channel].repeat();
}
// A random edit is merged into canonical unscaled memory, never the cropped or
// anchor-scaled display. The ordinary morph duration and mirror policy still apply.
function randomrange(first, last) {
    if (inlet < 0 || inlet > 2 || (inlet === 2 && anchorMirror)) return;
    var a = arrayfromargs(arguments); a.splice(0, 2);
    first = Number(first); last = Number(last);
    if (!isFinite(first) || !isFinite(last) || a.length < componentCount || a.length > capacity) return;
    first = Math.max(1, Math.round(first)); last = Math.min(componentCount, Math.round(last));
    if (last < first) return;
    materialize(inlet);
    var merged = memory[inlet].slice(0, componentCount);
    for (var i = first - 1; i < last; i++) merged[i] = clipped(a[i], inlet);
    target(inlet, merged);
}
function tick(channel){
    if(!running[channel]){tasks[channel].cancel();return;}
    materialize(channel);emit(channel,current[channel],false);
}
function list(){
    var values=arrayfromargs(arguments);
    if(inlet>=0&&inlet<=2)target(inlet,values);
    else if(inlet>=3&&inlet<=5){
        var channel=inlet-3;
        // Ignore echoed output and size-generated lists while restoring memory.
        if(outputGuard[channel]||values.length!==displayCount)return;
        if(channel===2&&anchorMirror){
            beginModel();draw(2,false,nowMs());endModel();return;
        }
        // Feedback contains audible/displayed levels. Preserve untouched entry
        // targets instead of feeding their temporary faded values into memory.
        var time=nowMs(),shown=lastDrawn[channel],i;
        materialize(channel);tasks[channel].cancel();running[channel]=false;
        for(i=0;i<componentCount;i++){
            var changed=i>=shown.length||Math.abs(Number(values[i])-shown[i])>0.000001;
            if(channel===2){
                // A manual bar is an already-scaled value. Preserve untouched
                // nominal levels, especially when the scale is temporarily 0.
                if(changed)memory[2][i]=anchorUnscale(values[i]);
            }else if(lifeMode[i]!==2||changed)memory[channel][i]=clipped(values[i],channel);
        }
        current[channel]=memory[channel].slice(0,componentCount);
        synchronizeEntryTargets(channel,time);initialized[channel]=true;
        if(channel>0){
            beginModel();draw(channel,false,time);
            if(channel===1&&anchorMirror)draw(2,false,time);
            endModel();
        }
    }
}
function scalar(x){
    x=Number(x);if(!isFinite(x))return;
    if(inlet===9)setCount(x);
    else if(inlet>=6&&inlet<=8)durations[inlet-6]=Math.max(0,Math.min(600000,x));
}
function msg_int(x){scalar(x);}
function msg_float(x){scalar(x);}
function bang(){}
function clear(){}
function append(){}
function set(){}
function anything(){}

function anchorUnscale(value){
    return clipped(anchorScale>0?Number(value)/anchorScale:Number(value),2);
}
function anchormirror(value){
    if(inlet!==10||!isFinite(Number(value)))return;
    var on=Number(value)!==0;
    messnamed("Anchor_Mirror_state_v23",on?1:0);
    if(on===anchorMirror)return;
    var time=nowMs();materialize(1);synchronizeEntryTargets(1,time);
    materialize(2);tasks[2].cancel();running[2]=false;initialized[2]=true;
    // Switching OFF holds the mirrored pattern and its in-flight entry/exit
    // ramps. It can then be edited independently without a level discontinuity.
    memory[2]=memory[1].slice(0);current[2]=memory[2].slice(0,componentCount);
    for(var i=0;i<capacity;i++){
        lifeStart[2][i]=lifeStart[1][i];lifeTime[2][i]=lifeTime[1][i];lifeTarget[2][i]=lifeTarget[1][i];
    }
    anchorMirror=on;
    beginModel();draw(1,false,time);draw(2,false,time);endModel();
}
function anchorscale(value){
    if(inlet!==10||!isFinite(Number(value)))return;
    value=Math.max(0,Math.min(1,Number(value)));
    messnamed("Anchor_Scale_state_v23",value);
    if(value===anchorScale)return;
    materialize(anchorMirror?1:2);
    var time=nowMs();
    if(anchorMirror)synchronizeEntryTargets(1,time);
    anchorScale=value;
    beginModel();
    if(anchorMirror)draw(1,false,time);
    draw(2,false,time);endModel();
}
function loadbang(){
    messnamed("Anchor_Mirror_state_v23",anchorMirror?1:0);
    messnamed("Anchor_Scale_state_v23",anchorScale);
}

// External removal applies to indexed memory, not a temporary post-model mask.
function zeroindices(){
    if(inlet!==10)return;
    var args=arrayfromargs(arguments),indices=[],seen={},i,c;
    for(i=0;i<args.length;i++){var n=Number(args[i]);if(isFinite(n)&&Math.floor(n)===n&&n>=1&&n<=componentCount&&!seen[n]){seen[n]=true;indices.push(n-1);}}
    if(!indices.length)return;
    for(c=0;c<3;c++){materialize(c);tasks[c].cancel();running[c]=false;initialized[c]=true;}
    // Update all layer banks before exposing a single final model to the synthesizer.
    beginModel();
    for(c=0;c<3;c++)for(i=0;i<indices.length;i++)memory[c][indices[i]]=0.0;
    emit(1,memory[1].slice(0,componentCount),false);
    emit(2,memory[2].slice(0,componentCount),false);
    emit(0,memory[0].slice(0,componentCount),false);
    endModel();
}

// Restore exact three-layer snapshots captured by the weighted remove/add engine.
// Records are: index, signed detune, primary amplitude, harmonic-anchor amplitude.
function restoreindices(){
    if(inlet!==10)return;
    var args=arrayfromargs(arguments),records=[],seen={},i,c;
    if(!args.length||args.length%4!==0)return;
    for(i=0;i<args.length;i+=4){
        var index=Number(args[i]),detune=Number(args[i+1]),amplitude=Number(args[i+2]),anchor=Number(args[i+3]);
        if(!isFinite(index)||index!==Math.floor(index)||index<1||index>componentCount||seen[index]||
           !isFinite(detune)||!isFinite(amplitude)||!isFinite(anchor))return;
        seen[index]=true;records.push([index-1,clipped(detune,0),clipped(amplitude,1),clipped(anchor,2)]);
    }
    for(c=0;c<3;c++){materialize(c);tasks[c].cancel();running[c]=false;initialized[c]=true;}
    beginModel();
    for(i=0;i<records.length;i++){
        memory[0][records[i][0]]=records[i][1];
        memory[1][records[i][0]]=records[i][2];
        // Remove/add snapshots contain visible (scaled) anchor amplitudes.
        memory[2][records[i][0]]=anchorUnscale(records[i][3]);
    }
    emit(1,memory[1].slice(0,componentCount),false);
    emit(2,memory[2].slice(0,componentCount),false);
    emit(0,memory[0].slice(0,componentCount),false);
    endModel();
}

// Design workspaces send octavefamily BASE on|off to inlet 10.
// Visible primary amplitudes are replaced; anchor amplitudes are cleared.
function octavefamily(base,state){
    if(inlet!==10)return;
    base=Number(base);state=String(state);
    if(!isFinite(base)||base!==Math.floor(base)||base<2||base>capacity||
       (base!==2&&base%2===0)||(state!=="on"&&state!=="off")||base>componentCount)return;
    var c,n,ordinal=1;
    for(c=1;c<=2;c++){materialize(c);tasks[c].cancel();running[c]=false;initialized[c]=true;}
    beginModel();
    for(n=base;n<=componentCount;n*=2){
        memory[1][n-1]=state==="on"?clipped(1/ordinal):0.0;
        memory[2][n-1]=0.0;ordinal++;
    }
    emit(1,memory[1].slice(0,componentCount),false);
    emit(2,memory[2].slice(0,componentCount),false);
    endModel();
}

// Global flat zero clears the full 256-slot bank, including partial 1.
// The current visible component count is preserved.
function alloff(){
    if(inlet!==10)return;
    // Stop through the lane authority even when alloff arrives from a workspace.
    messnamed("ADSR_12_Lanes_Stop_v23","bang");
    messnamed("Envelope_Loop_v23",0);
    var c,i;
    for(c=0;c<3;c++){materialize(c);tasks[c].cancel();running[c]=false;initialized[c]=true;}
    for(i=0;i<capacity;i++)lifeMode[i]=i<componentCount?1:0;
    displayCount=componentCount;updateLifeTask();
    beginModel();
    for(c=0;c<3;c++)for(i=0;i<capacity;i++)memory[c][i]=0.0;
    outlet(5,displayCount);
    emit(1,memory[1].slice(0,componentCount),true);
    emit(2,memory[2].slice(0,componentCount),true);
    emit(0,memory[0].slice(0,componentCount),true);
    endModel();
    outlet(4,"flatmenus");
}

// Copy the current primary amplitude bank to harmonic anchors, including hidden slots.

function copyAmplitudeLayer(destination){
    if(inlet!==10)return;
    materialize(1);
    tasks[1].cancel();running[1]=false;initialized[1]=true;
    tasks[destination].cancel();running[destination]=false;initialized[destination]=true;
    memory[destination]=memory[1].slice(0);
    beginModel();
    emit(1,memory[1].slice(0,componentCount),false);
    emit(destination,memory[destination].slice(0,componentCount),false);
    endModel();
}
function PartialAmplitudes_to_HarmonicAnchor(){copyAmplitudeLayer(2);}
function PartialAmplitudes_to_Inharmonicity(){copyAmplitudeLayer(0);}
// Workspace applies complete 256-slot inharmonicity, primary and anchor banks.
function stoplayers(){
    if(inlet!==10)return;
    var v=arrayfromargs(arguments),c,i;
    if(v.length!==capacity*3)return;
    for(i=0;i<v.length;i++)if(!isFinite(Number(v[i])))return;
    for(c=0;c<3;c++){materialize(c);tasks[c].cancel();running[c]=false;initialized[c]=true;}
    for(c=0;c<3;c++)memory[c]=clean(v.slice(c*capacity,(c+1)*capacity),c);
    beginModel();
    emit(1,memory[1].slice(0,componentCount),false);
    emit(2,memory[2].slice(0,componentCount),false);
    emit(0,memory[0].slice(0,componentCount),false);
    endModel();
}

// v23 student-message controls. Indices are one-based, including hidden slots.
function partialvalue(channel,index,value){
    channel=Number(channel);index=Number(index);value=Number(value);
    if(inlet!==10||!isFinite(channel)||channel!==Math.floor(channel)||channel<0||channel>2||
       !isFinite(index)||index!==Math.floor(index)||index<1||index>capacity||!isFinite(value))return;
    if(channel===2&&anchorMirror)return;
    materialize(channel);tasks[channel].cancel();running[channel]=false;initialized[channel]=true;
    memory[channel][index-1]=clipped(value,channel);
    beginModel();emit(channel,memory[channel].slice(0,componentCount),false);endModel();
}
function partialget(channel,index){
    channel=Number(channel);index=Number(index);
    if(inlet!==10||!isFinite(channel)||channel!==Math.floor(channel)||channel<0||channel>2||
       !isFinite(index)||index!==Math.floor(index)||index<1||index>capacity)return;
    materialize(channel===2&&anchorMirror?1:channel);
    var names=["Partial_Drift_current_v23","Partial_Amplitude_current_v23","Partial_Anchor_current_v23"];
    var value=memory[channel===2&&anchorMirror?1:channel][index-1];
    messnamed(names[channel],channel===2?clipped(value*anchorScale,2):value);
}
function familyvalue(root,state){
    root=Number(root);state=Number(state);
    if(state!==0&&state!==1)return;
    octavefamily(root,state===1?"on":"off");
}

var EC_NS="ec-cnmat-sinusoids-v23_";
// Private preset state helpers. Called locally by the public ecpreset message.
function ec_array(x){return Object.prototype.toString.call(x)==="[object Array]";}
function ec_copy(x){return ec_dataCopy(x);}
function ec_shift(x,n){if(ec_array(x)){for(var i=0;i<x.length;i++)x[i]=ec_shift(x[i],n);return x;}return typeof x==="number"?x+n:x;}
function ec_validTree(x,depth){
 if(depth>12)return false;
 if(x===null||typeof x==="boolean"||typeof x==="string")return true;
 if(typeof x==="number")return isFinite(x)&&Math.abs(x)<=1e16;
 if(ec_array(x)){if(x.length>4096)return false;for(var i=0;i<x.length;i++)if(!ec_validTree(x[i],depth+1))return false;return true;}
 return false;
}
var ec_fields = ["componentCount", "durations", "activeDuration", "memory", "current", "starts", "targets", "initialized", "running", "outputGuard", "startTimes", "displayCount", "lifeMode", "lifeEnd", "lifeStart", "lifeTime", "lifeTarget", "lastDrawn", "anchorMirror", "anchorScale", "lifeRunning"];
var ec_clocks = ["startTimes", "lifeEnd", "lifeTime"];
function ec_export(){for(var c=0;c<3;c++)materialize(c);var d=ec_copy({"componentCount":componentCount,"durations":durations,"activeDuration":activeDuration,"memory":memory,"current":current,"starts":starts,"targets":targets,"initialized":initialized,"running":running,"outputGuard":outputGuard,"startTimes":startTimes,"displayCount":displayCount,"lifeMode":lifeMode,"lifeEnd":lifeEnd,"lifeStart":lifeStart,"lifeTime":lifeTime,"lifeTarget":lifeTarget,"lastDrawn":lastDrawn,"anchorMirror":anchorMirror,"anchorScale":anchorScale,"lifeRunning":lifeRunning});var n=(new Date()).getTime();for(var i=0;i<ec_clocks.length;i++)d[ec_clocks[i]]=ec_shift(d[ec_clocks[i]],-n);return ec_morph_export(d);}
function ec_validate(d){if(!d||ec_array(d)||Object.keys(d).length!==ec_fields.length)return false;var initial={"componentCount":componentCount,"durations":durations,"activeDuration":activeDuration,"memory":memory,"current":current,"starts":starts,"targets":targets,"initialized":initialized,"running":running,"outputGuard":outputGuard,"startTimes":startTimes,"displayCount":displayCount,"lifeMode":lifeMode,"lifeEnd":lifeEnd,"lifeStart":lifeStart,"lifeTime":lifeTime,"lifeTarget":lifeTarget,"lastDrawn":lastDrawn,"anchorMirror":anchorMirror,"anchorScale":anchorScale,"lifeRunning":lifeRunning};for(var i=0;i<ec_fields.length;i++){var k=ec_fields[i];if(!d.hasOwnProperty(k)||!ec_validTree(d[k],0))return false;if(ec_array(initial[k])){if(!(ec_array(d[k])))return false;}else if(initial[k]!==null && typeof d[k]!==typeof initial[k])return false;}if(d.componentCount<2||d.componentCount>256)return false;if(d.displayCount<2||d.displayCount>256)return false;if(d.anchorScale<0||d.anchorScale>1)return false;if(d.memory.length!==3)return false;for(var c=0;c<3;c++){if(d.memory[c].length!==256)return false;for(var j=0;j<256;j++)if(typeof d.memory[c][j]!=="number"||d.memory[c][j]<(c===0?-1:0)||d.memory[c][j]>1)return false;}return true;}
function ec_import(d){if(!ec_validate(d))throw new Error("Invalid partial_memory preset state");for(var c=0;c<3;c++)tasks[c].cancel();lifeTask.cancel();d=ec_copy(d);var n=(new Date()).getTime();for(var i=0;i<ec_clocks.length;i++)d[ec_clocks[i]]=ec_shift(d[ec_clocks[i]],n);fullMorphMask=null;componentCount=d.componentCount;durations=d.durations;activeDuration=d.activeDuration;memory=d.memory;current=d.current;starts=d.starts;targets=d.targets;initialized=d.initialized;running=d.running;outputGuard=d.outputGuard;startTimes=d.startTimes;displayCount=d.displayCount;lifeMode=d.lifeMode;lifeEnd=d.lifeEnd;lifeStart=d.lifeStart;lifeTime=d.lifeTime;lifeTarget=d.lifeTarget;lastDrawn=d.lastDrawn;anchorMirror=d.anchorMirror;anchorScale=d.anchorScale;lifeRunning=d.lifeRunning;outputGuard=[false,false,false];updateDepth=0;}
function ec_emit(){frame(true,nowMs());for(var c=0;c<3;c++)if(running[c])tasks[c].repeat();if(lifeRunning)lifeTask.repeat();}
ec_export.local=1;ec_validate.local=1;ec_import.local=1;ec_emit.local=1;ec_copy.local=1;ec_shift.local=1;ec_validTree.local=1;

var EC_PRESET_KIND = "partial_memory";

// Public Max message endpoint for this engine's private preset helpers.
function ecpreset(dictionaryName){
 var name=String(dictionaryName),prefix=EC_NS+"preset-transfer-";
 // A foreign instance receives a negative acknowledgement, never preset data.
 if(!/^ec-cnmat-sinusoids-v23_preset-transfer-[0-9]+$/.test(name))return;
 var transfer=new Dict(name),request=null;
 try{
  request=ec_wireRead(transfer,"request");
  if(request.protocol!==1||request.kind!==EC_PRESET_KIND||typeof request.sequence!=="number")throw new Error("Invalid preset request");
  if(name.indexOf(prefix)!==0)throw new Error("Preset namespace mismatch: engine="+EC_NS+" request="+name);
  var result;
  if(request.action==="ping")result=true;
  else if(request.action==="export")result=ec_export();
  else if(request.action==="validate")result=ec_validate(request.data);
  else if(request.action==="import"){ec_import(request.data);result=true;}
  else if(request.action==="emit"){ec_emit();result=true;}
  else if(request.action==="morph_prepare"){ec_morph_prepare(request.data);result=true;}
  else throw new Error("Unknown preset action");
  ec_wireWrite(transfer,"response",{protocol:1,sequence:request.sequence,kind:EC_PRESET_KIND,ok:true,data:result});
 }catch(e){
  ec_wireWrite(transfer,"response",{protocol:1,sequence:request?request.sequence:0,kind:EC_PRESET_KIND,ok:false,error:(request?request.action:"request")+" "+EC_PRESET_KIND+": "+String(e.message||e)});
 }finally{transfer.freepeer();}
}

// Private preset transport. Short ASCII-only atoms avoid quote/token conversion
// and unbounded strings at the Max Dict boundary. No runtime include is needed.
function ec_dataCopy(x,depth){
 depth=depth||0;if(depth>32)throw new Error("Preset copy nesting limit");
 if(x===null)return null;
 var t=typeof x,i,k,r;
 if(t==="string"||t==="boolean")return x;
 if(t==="number"){if(!isFinite(x))throw new Error("Non-finite preset value");return x;}
 if(Object.prototype.toString.call(x)==="[object Array]"){
  r=[];for(i=0;i<x.length;i++)r[i]=x[i]===undefined?null:ec_dataCopy(x[i],depth+1);return r;
 }
 if(t==="object"){
  r={};for(k in x)if(Object.prototype.hasOwnProperty.call(x,k)&&x[k]!==undefined){
   if(k==="__proto__"||k==="constructor"||k==="prototype")throw new Error("Unsafe preset key");
   r[k]=ec_dataCopy(x[k],depth+1);
  }return r;
 }
 throw new Error("Unsupported preset value type "+t);
}
function ec_wireEncode(s){
 var alphabet="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",r="",i,a,b,c;
 for(i=0;i<s.length;i+=3){a=s.charCodeAt(i);b=s.charCodeAt(i+1);c=s.charCodeAt(i+2);r+=alphabet.charAt(a>>2)+alphabet.charAt(((a&3)<<4)|(isNaN(b)?0:b>>4))+(isNaN(b)?"=":alphabet.charAt(((b&15)<<2)|(isNaN(c)?0:c>>6)))+(isNaN(c)?"=":alphabet.charAt(c&63));}return r;
}
function ec_wireDecode(s){
 if(!/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(s))throw new Error("Invalid Base64 chunk");
 var alphabet="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",r="",i,a,b,c,d;
 for(i=0;i<s.length;i+=4){a=alphabet.indexOf(s.charAt(i));b=alphabet.indexOf(s.charAt(i+1));c=alphabet.indexOf(s.charAt(i+2));d=alphabet.indexOf(s.charAt(i+3));r+=String.fromCharCode((a<<2)|(b>>4));if(c>=0)r+=String.fromCharCode(((b&15)<<4)|(c>>2));if(d>=0)r+=String.fromCharCode(((c&3)<<6)|d);}return r;
}
function ec_wireChecksum(s){var a=1,b=0;for(var i=0;i<s.length;i++){a=(a+s.charCodeAt(i))%65521;b=(b+a)%65521;}return "h"+(((b<<16)|a)>>>0).toString(16);}
function ec_wireAtom(dict,key){
 var x=dict.get(key);
 if(Object.prototype.toString.call(x)==="[object Array]"&&x.length===1)x=x[0];
 return x;
}
function ec_wireWrite(dict,key,value){
 dict.set(key+"_ready",0);
 var raw=JSON.stringify(value);
 if(typeof raw!=="string")throw new Error(key+": JSON serialization returned no string");
 raw=raw.replace(/[\u007f-\uffff]/g,function(c){return "\\u"+("0000"+c.charCodeAt(0).toString(16)).slice(-4);});
 var coded=ec_wireEncode(raw),count=Math.ceil(coded.length/480);
 if(count<1||count>8192)throw new Error(key+": preset transfer too large");
 dict.set(key+"_format","ecb64v1");dict.set(key+"_chars",raw.length);
 dict.set(key+"_encoded",coded.length);dict.set(key+"_sum",ec_wireChecksum(raw));
 dict.set(key+"_count",count);
 for(var i=0;i<count;i++)dict.set(key+"_"+i,"p"+coded.substr(i*480,480));
 dict.set(key+"_ready",1);
}
function ec_wireRead(dict,key){
 if(Number(ec_wireAtom(dict,key+"_ready"))!==1)throw new Error(key+": transfer not complete");
 if(ec_wireAtom(dict,key+"_format")!=="ecb64v1")throw new Error(key+": unsupported transfer format");
 var count=Number(ec_wireAtom(dict,key+"_count")),length=Number(ec_wireAtom(dict,key+"_encoded"));
 var chars=Number(ec_wireAtom(dict,key+"_chars")),sum=ec_wireAtom(dict,key+"_sum");
 if(!isFinite(count)||count!==Math.floor(count)||count<1||count>8192||
    !isFinite(length)||length!==Math.floor(length)||length<4||length%4||Math.ceil(length/480)!==count||
    !isFinite(chars)||chars!==Math.floor(chars)||chars<1||chars>count*360)throw new Error(key+": invalid transfer dimensions");
 var raw="",part,i;
 for(i=0;i<count;i++){
  part=ec_wireAtom(dict,key+"_"+i);
  if(typeof part!=="string"||part.charAt(0)!=="p"||part.length!==1+Math.min(480,length-i*480))throw new Error(key+": missing or truncated chunk "+i);
  try{raw+=ec_wireDecode(part.substr(1));}catch(e){throw new Error(key+": corrupt chunk "+i+": "+String(e.message||e));}
 }
 if(raw.length!==chars||ec_wireChecksum(raw)!==sum)throw new Error(key+": transfer checksum mismatch");
 try{return JSON.parse(raw);}catch(e){throw new Error(key+": JSON decode failed after verified transfer ("+raw.length+" chars): "+String(e.message||e));}
}
ec_dataCopy.local=1;ec_wireEncode.local=1;ec_wireDecode.local=1;ec_wireChecksum.local=1;
ec_wireAtom.local=1;ec_wireWrite.local=1;ec_wireRead.local=1;

// v23 full-state interpolation. The controller stages validated endpoints once,
// then sends only a normalized frame fraction. No per-frame Dict serialization.
var ecM = null;
function ec_morph_prepare(d) {
    if (!d || !ec_validate(d.from) || !ec_validate(d.to)) throw new Error("Invalid morph endpoints for " + EC_PRESET_KIND);
    ecM = {a:ec_copy(d.from), b:ec_copy(d.to), extra:d.extra || {}, started:false};
    ec_morph_setup();
}
function ec_mix(a,b,t){return t<=0?a:t>=1?b:a+(b-a)*t;}
function ec_geo(a,b,t){return a>0&&b>0?(t<=0?a:t>=1?b:a*Math.pow(b/a,t)):ec_mix(a,b,t);}
function ec_sample(a,x){if(!a.length)return 0;if(a.length===1)return Number(a[0])||0;var p=Math.max(0,Math.min(1,x))*(a.length-1),i=Math.floor(p);return ec_mix(Number(a[i])||0,Number(a[Math.min(a.length-1,i+1)])||0,p-i);}
function ecmorphbegin(){if(!ecM)return;try{ec_morph_begin();ecM.started=true;}catch(e){messnamed("Synth_Control_v23","_morphfault",EC_PRESET_KIND,String(e.message||e));}}
function ecmorphframe(t){if(!ecM||!ecM.started)return;t=Number(t);if(!isFinite(t))return;t=Math.max(0,Math.min(1,t));try{ec_morph_frame(t);}catch(e){messnamed("Synth_Control_v23","_morphfault",EC_PRESET_KIND,String(e.message||e));}}
function ecmorphrelease(done){if(!ecM)return;try{ec_morph_release(Number(done)!==0);}finally{ecM=null;}}
ec_morph_prepare.local=1;ec_mix.local=1;ec_geo.local=1;ec_sample.local=1;

var fullMorphMask=null;
function ec_morph_setup(){
    ecM.n=Math.max(ecM.a.componentCount,ecM.b.componentCount);
    if(ecM.a.anchorMirror)ecM.a.memory[2]=ecM.a.memory[1].slice(0);
    if(ecM.b.anchorMirror)ecM.b.memory[2]=ecM.b.memory[1].slice(0);
}
function ec_morph_begin(){for(var c=0;c<3;c++){materialize(c);tasks[c].cancel();running[c]=false;}lifeTask.cancel();lifeRunning=false;}
function ec_morph_frame(t){
    var a=ecM.a,b=ecM.b,old=displayCount,i,c,n=t>=1?b.componentCount:ecM.n;
    componentCount=displayCount=n;anchorMirror=t>=1?b.anchorMirror:false;anchorScale=ec_mix(a.anchorScale,b.anchorScale,t);
    fullMorphMask=t>=1?null:[];
    for(i=0;i<256;i++){
        lifeMode[i]=i<n?1:0;lifeEnd[i]=0;
        if(fullMorphMask)fullMorphMask[i]=ec_mix(i<a.componentCount?1:0,i<b.componentCount?1:0,t);
        for(c=0;c<3;c++)memory[c][i]=clipped(ec_mix(a.memory[c][i],b.memory[c][i],t),c);
    }
    for(c=0;c<3;c++){
        durations[c]=ec_mix(a.durations[c],b.durations[c],t);activeDuration[c]=durations[c];
        current[c]=memory[c].slice(0,n);starts[c]=current[c].slice(0);targets[c]=current[c].slice(0);
        running[c]=false;initialized[c]=true;tasks[c].cancel();
    }
    lifeTask.cancel();lifeRunning=false;frame(old!==n||t===0||t===1,nowMs());
}
function ec_morph_release(done){
    if(fullMorphMask){for(var c=1;c<3;c++)for(var i=0;i<componentCount;i++)memory[c][i]=clipped(memory[c][i]*fullMorphMask[i],c);fullMorphMask=null;}
    for(c=0;c<3;c++)current[c]=memory[c].slice(0,componentCount);
    frame(false,nowMs());
}
// A dump made during a morph records the audible intermediate amplitudes, not
// hidden activity-mask factors. Hidden slots beyond the working count survive.
function ec_morph_export(d){
    if(fullMorphMask){for(var c=1;c<3;c++){
        for(var i=0;i<d.componentCount;i++)d.memory[c][i]=clipped(d.memory[c][i]*fullMorphMask[i],c);
        d.current[c]=d.memory[c].slice(0,d.componentCount);d.starts[c]=d.current[c].slice(0);d.targets[c]=d.current[c].slice(0);
    }}
    return d;
}
ec_morph_setup.local=1;ec_morph_begin.local=1;ec_morph_frame.local=1;ec_morph_release.local=1;ec_morph_export.local=1;
