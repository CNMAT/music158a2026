/*
    random_multislider_values_v23.js
    Creates independent uniform 0.0-1.0 random lists for three multisliders.

    inlet 0: component count (2-256)
    inlet 1: bang randomizes inharmonicity values
    inlet 2: bang randomizes primary amplitudes
    inlet 3: bang randomizes harmonic-anchor amplitudes

    outlets 0-2 correspond to inlets 1-3.
*/

autowatch = 1;
inlets = 4;
outlets = 3;

var componentCount = 32;
// Runtime viewport only: sound captures keep their existing schema.
var viewFirst = 1, viewLast = 256, viewAll = true;
function view(first, last, all, count) {
    if (inlet !== 0 || !isFinite(Number(first)) || !isFinite(Number(last))) return;
    viewFirst = clipInteger(first, 1, 256);
    viewLast = Math.max(viewFirst, clipInteger(last, 1, 256));
    viewAll = Number(all) !== 0;
}
function randomOutput(channel, signed) {
    var values = randomList(signed);
    // Main amplitude random remains unchanged; Detune and Anchor obey the view.
    if (!viewAll && (channel === 0 || channel === 2))
        outlet(channel, ["randomrange", viewFirst, viewLast].concat(values));
    else outlet(channel, values);
}
randomOutput.local = 1;

function clipInteger(value, low, high) {
    return Math.max(low, Math.min(high, Math.round(Number(value))));
}

function randomList(signed) {
    var result = [];
    var i;
    for (i = 0; i < componentCount; i++) {
        result[i] = Math.round((signed ? Math.random()*2-1 : Math.random()) * 1000000.0) / 1000000.0;
    }
    return result;
}

function msg_int(value) {
    if (inlet === 0) {
        componentCount = clipInteger(value, 2, 256);
    }
}

function msg_float(value) {
    msg_int(value);
}

function bang() {
    if (inlet === 1) {
        randomOutput(0, true);
    } else if (inlet === 2) {
        randomOutput(1, false);
    } else if (inlet === 3) {
        randomOutput(2, false);
    }
}

// Ignore non-data selectors used by Max UI objects during restoration.
function clear() {
}

function append() {
}

function set() {
}

function anything() {
}

var EC_NS="ec-cnmat-sinusoids-v23_";
// Private preset state helpers. Called locally by the public ecpreset message.
function ec_array(x){return Object.prototype.toString.call(x)==="[object Array]";}
function ec_copy(x){return ec_dataCopy(x);}
function ec_shift(x,n){if(ec_array(x)){for(var i=0;i<x.length;i++)x[i]=ec_shift(x[i],n);return x;}return typeof x==="number"?x+n:x;}
function ec_validTree(x,depth){
 if(depth>12)return false;
 if(x===null||typeof x==="boolean"||typeof x==="string")return true;
 if(typeof x==="number")return isFinite(x)&&Math.abs(x)<=1e16;
 if(ec_array(x)){if(x.length>4096)return false;for(var i=0;i<x.length;i++)if(!ec_validTree(x[i],depth+1))return false;return true;}
 return false;
}
var ec_fields = ["componentCount"];
var ec_clocks = [];
function ec_export(){var d=ec_copy({"componentCount":componentCount});var n=(new Date()).getTime();for(var i=0;i<ec_clocks.length;i++)d[ec_clocks[i]]=ec_shift(d[ec_clocks[i]],-n);return d;}
function ec_validate(d){if(!d||ec_array(d)||Object.keys(d).length!==ec_fields.length)return false;var initial={"componentCount":componentCount};for(var i=0;i<ec_fields.length;i++){var k=ec_fields[i];if(!d.hasOwnProperty(k)||!ec_validTree(d[k],0))return false;if(ec_array(initial[k])){if(!(ec_array(d[k])))return false;}else if(initial[k]!==null && typeof d[k]!==typeof initial[k])return false;}if(d.componentCount<2||d.componentCount>256)return false;return true;}
function ec_import(d){if(!ec_validate(d))throw new Error("Invalid random preset state");d=ec_copy(d);var n=(new Date()).getTime();for(var i=0;i<ec_clocks.length;i++)d[ec_clocks[i]]=ec_shift(d[ec_clocks[i]],n);componentCount=d.componentCount;}
function ec_emit(){}
ec_export.local=1;ec_validate.local=1;ec_import.local=1;ec_emit.local=1;ec_copy.local=1;ec_shift.local=1;ec_validTree.local=1;

var EC_PRESET_KIND = "random";

// Public Max message endpoint for this engine's private preset helpers.
function ecpreset(dictionaryName){
 var name=String(dictionaryName),prefix=EC_NS+"preset-transfer-";
 // A foreign instance receives a negative acknowledgement, never preset data.
 if(!/^ec-cnmat-sinusoids-v23_preset-transfer-[0-9]+$/.test(name))return;
 var transfer=new Dict(name),request=null;
 try{
  request=ec_wireRead(transfer,"request");
  if(request.protocol!==1||request.kind!==EC_PRESET_KIND||typeof request.sequence!=="number")throw new Error("Invalid preset request");
  if(name.indexOf(prefix)!==0)throw new Error("Preset namespace mismatch: engine="+EC_NS+" request="+name);
  var result;
  if(request.action==="ping")result=true;
  else if(request.action==="export")result=ec_export();
  else if(request.action==="validate")result=ec_validate(request.data);
  else if(request.action==="import"){ec_import(request.data);result=true;}
  else if(request.action==="emit"){ec_emit();result=true;}
  else if(request.action==="morph_prepare"){ec_morph_prepare(request.data);result=true;}
  else throw new Error("Unknown preset action");
  ec_wireWrite(transfer,"response",{protocol:1,sequence:request.sequence,kind:EC_PRESET_KIND,ok:true,data:result});
 }catch(e){
  ec_wireWrite(transfer,"response",{protocol:1,sequence:request?request.sequence:0,kind:EC_PRESET_KIND,ok:false,error:(request?request.action:"request")+" "+EC_PRESET_KIND+": "+String(e.message||e)});
 }finally{transfer.freepeer();}
}

// Private preset transport. Short ASCII-only atoms avoid quote/token conversion
// and unbounded strings at the Max Dict boundary. No runtime include is needed.
function ec_dataCopy(x,depth){
 depth=depth||0;if(depth>32)throw new Error("Preset copy nesting limit");
 if(x===null)return null;
 var t=typeof x,i,k,r;
 if(t==="string"||t==="boolean")return x;
 if(t==="number"){if(!isFinite(x))throw new Error("Non-finite preset value");return x;}
 if(Object.prototype.toString.call(x)==="[object Array]"){
  r=[];for(i=0;i<x.length;i++)r[i]=x[i]===undefined?null:ec_dataCopy(x[i],depth+1);return r;
 }
 if(t==="object"){
  r={};for(k in x)if(Object.prototype.hasOwnProperty.call(x,k)&&x[k]!==undefined){
   if(k==="__proto__"||k==="constructor"||k==="prototype")throw new Error("Unsafe preset key");
   r[k]=ec_dataCopy(x[k],depth+1);
  }return r;
 }
 throw new Error("Unsupported preset value type "+t);
}
function ec_wireEncode(s){
 var alphabet="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",r="",i,a,b,c;
 for(i=0;i<s.length;i+=3){a=s.charCodeAt(i);b=s.charCodeAt(i+1);c=s.charCodeAt(i+2);r+=alphabet.charAt(a>>2)+alphabet.charAt(((a&3)<<4)|(isNaN(b)?0:b>>4))+(isNaN(b)?"=":alphabet.charAt(((b&15)<<2)|(isNaN(c)?0:c>>6)))+(isNaN(c)?"=":alphabet.charAt(c&63));}return r;
}
function ec_wireDecode(s){
 if(!/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(s))throw new Error("Invalid Base64 chunk");
 var alphabet="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",r="",i,a,b,c,d;
 for(i=0;i<s.length;i+=4){a=alphabet.indexOf(s.charAt(i));b=alphabet.indexOf(s.charAt(i+1));c=alphabet.indexOf(s.charAt(i+2));d=alphabet.indexOf(s.charAt(i+3));r+=String.fromCharCode((a<<2)|(b>>4));if(c>=0)r+=String.fromCharCode(((b&15)<<4)|(c>>2));if(d>=0)r+=String.fromCharCode(((c&3)<<6)|d);}return r;
}
function ec_wireChecksum(s){var a=1,b=0;for(var i=0;i<s.length;i++){a=(a+s.charCodeAt(i))%65521;b=(b+a)%65521;}return "h"+(((b<<16)|a)>>>0).toString(16);}
function ec_wireAtom(dict,key){
 var x=dict.get(key);
 if(Object.prototype.toString.call(x)==="[object Array]"&&x.length===1)x=x[0];
 return x;
}
function ec_wireWrite(dict,key,value){
 dict.set(key+"_ready",0);
 var raw=JSON.stringify(value);
 if(typeof raw!=="string")throw new Error(key+": JSON serialization returned no string");
 raw=raw.replace(/[\u007f-\uffff]/g,function(c){return "\\u"+("0000"+c.charCodeAt(0).toString(16)).slice(-4);});
 var coded=ec_wireEncode(raw),count=Math.ceil(coded.length/480);
 if(count<1||count>8192)throw new Error(key+": preset transfer too large");
 dict.set(key+"_format","ecb64v1");dict.set(key+"_chars",raw.length);
 dict.set(key+"_encoded",coded.length);dict.set(key+"_sum",ec_wireChecksum(raw));
 dict.set(key+"_count",count);
 for(var i=0;i<count;i++)dict.set(key+"_"+i,"p"+coded.substr(i*480,480));
 dict.set(key+"_ready",1);
}
function ec_wireRead(dict,key){
 if(Number(ec_wireAtom(dict,key+"_ready"))!==1)throw new Error(key+": transfer not complete");
 if(ec_wireAtom(dict,key+"_format")!=="ecb64v1")throw new Error(key+": unsupported transfer format");
 var count=Number(ec_wireAtom(dict,key+"_count")),length=Number(ec_wireAtom(dict,key+"_encoded"));
 var chars=Number(ec_wireAtom(dict,key+"_chars")),sum=ec_wireAtom(dict,key+"_sum");
 if(!isFinite(count)||count!==Math.floor(count)||count<1||count>8192||
    !isFinite(length)||length!==Math.floor(length)||length<4||length%4||Math.ceil(length/480)!==count||
    !isFinite(chars)||chars!==Math.floor(chars)||chars<1||chars>count*360)throw new Error(key+": invalid transfer dimensions");
 var raw="",part,i;
 for(i=0;i<count;i++){
  part=ec_wireAtom(dict,key+"_"+i);
  if(typeof part!=="string"||part.charAt(0)!=="p"||part.length!==1+Math.min(480,length-i*480))throw new Error(key+": missing or truncated chunk "+i);
  try{raw+=ec_wireDecode(part.substr(1));}catch(e){throw new Error(key+": corrupt chunk "+i+": "+String(e.message||e));}
 }
 if(raw.length!==chars||ec_wireChecksum(raw)!==sum)throw new Error(key+": transfer checksum mismatch");
 try{return JSON.parse(raw);}catch(e){throw new Error(key+": JSON decode failed after verified transfer ("+raw.length+" chars): "+String(e.message||e));}
}
ec_dataCopy.local=1;ec_wireEncode.local=1;ec_wireDecode.local=1;ec_wireChecksum.local=1;
ec_wireAtom.local=1;ec_wireWrite.local=1;ec_wireRead.local=1;

// v23 full-state interpolation. The controller stages validated endpoints once,
// then sends only a normalized frame fraction. No per-frame Dict serialization.
var ecM = null;
function ec_morph_prepare(d) {
    if (!d || !ec_validate(d.from) || !ec_validate(d.to)) throw new Error("Invalid morph endpoints for " + EC_PRESET_KIND);
    ecM = {a:ec_copy(d.from), b:ec_copy(d.to), extra:d.extra || {}, started:false};
    ec_morph_setup();
}
function ec_mix(a,b,t){return t<=0?a:t>=1?b:a+(b-a)*t;}
function ec_geo(a,b,t){return a>0&&b>0?(t<=0?a:t>=1?b:a*Math.pow(b/a,t)):ec_mix(a,b,t);}
function ec_sample(a,x){if(!a.length)return 0;if(a.length===1)return Number(a[0])||0;var p=Math.max(0,Math.min(1,x))*(a.length-1),i=Math.floor(p);return ec_mix(Number(a[i])||0,Number(a[Math.min(a.length-1,i+1)])||0,p-i);}
function ecmorphbegin(){if(!ecM)return;try{ec_morph_begin();ecM.started=true;}catch(e){messnamed("Synth_Control_v23","_morphfault",EC_PRESET_KIND,String(e.message||e));}}
function ecmorphframe(t){if(!ecM||!ecM.started)return;t=Number(t);if(!isFinite(t))return;t=Math.max(0,Math.min(1,t));try{ec_morph_frame(t);}catch(e){messnamed("Synth_Control_v23","_morphfault",EC_PRESET_KIND,String(e.message||e));}}
function ecmorphrelease(done){if(!ecM)return;try{ec_morph_release(Number(done)!==0);}finally{ecM=null;}}
ec_morph_prepare.local=1;ec_mix.local=1;ec_geo.local=1;ec_sample.local=1;

// Silent auxiliary controls: changing a shape label never regenerates the spectrum.
function ec_morph_setup(){}
function ec_morph_begin(){}
function ec_morph_frame(t){var a=ecM.a,b=ecM.b;if(t===1){ec_import(b);return;}componentCount=t>=1?b.componentCount:Math.max(a.componentCount,b.componentCount);}
function ec_morph_release(done){}
ec_morph_setup.local=1;ec_morph_begin.local=1;ec_morph_frame.local=1;ec_morph_release.local=1;
