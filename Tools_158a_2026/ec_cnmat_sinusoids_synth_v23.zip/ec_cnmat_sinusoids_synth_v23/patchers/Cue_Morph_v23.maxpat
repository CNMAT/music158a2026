{
  "patcher": {
    "fileversion": 1,
    "appversion": {
      "major": 9,
      "minor": 2,
      "revision": 1,
      "architecture": "x64",
      "modernui": 1
    },
    "classnamespace": "box",
    "rect": [
      100.0,
      100.0,
      620.0,
      350.0
    ],
    "openinpresentation": 1,
    "default_fontsize": 12.0,
    "default_fontface": 0,
    "default_fontname": "Arial",
    "title": "v23 Morph CUE — seconds",
    "bglocked": 0,
    "autosave": 0,
    "boxes": [
      {
        "box": {
          "id": "title",
          "maxclass": "comment",
          "numinlets": 1,
          "numoutlets": 0,
          "patching_rect": [
            20.0,
            15.0,
            570.0,
            26.0
          ],
          "text": "MORPH CUE  |  SLOT [SECONDS]",
          "fontname": "Arial",
          "fontsize": 18.0,
          "textcolor": [
            0.0,
            0.0,
            0.0,
            1.0
          ],
          "presentation": 1,
          "presentation_rect": [
            20.0,
            15.0,
            570.0,
            26.0
          ],
          "fontface": 1
        }
      },
      {
        "box": {
          "id": "note",
          "maxclass": "comment",
          "numinlets": 1,
          "numoutlets": 0,
          "patching_rect": [
            20.0,
            50.0,
            575.0,
            65.0
          ],
          "text": "Send G 10 for an explicit ten-second morph, or G to use G’s stored seconds.\nFor a repeating list, use morphcue A B A D C F. Stop holds the current sound.\nAll referenced slots must be captured before the cue starts.",
          "fontname": "Arial",
          "fontsize": 12.0,
          "textcolor": [
            0.0,
            0.0,
            0.0,
            1.0
          ],
          "presentation": 1,
          "presentation_rect": [
            20.0,
            50.0,
            575.0,
            65.0
          ]
        }
      },
      {
        "box": {
          "id": "in",
          "maxclass": "inlet",
          "numinlets": 0,
          "numoutlets": 1,
          "patching_rect": [
            20.0,
            145.0,
            25.0,
            25.0
          ]
        }
      },
      {
        "box": {
          "id": "route",
          "maxclass": "newobj",
          "numinlets": 1,
          "numoutlets": 2,
          "patching_rect": [
            20.0,
            185.0,
            85.0,
            22.0
          ],
          "text": "route stop"
        }
      },
      {
        "box": {
          "id": "hold",
          "maxclass": "message",
          "numinlets": 2,
          "numoutlets": 1,
          "patching_rect": [
            140.0,
            185.0,
            85.0,
            22.0
          ],
          "text": "morphstop",
          "fontname": "Arial",
          "fontsize": 12.0,
          "textcolor": [
            0.0,
            0.0,
            0.0,
            1.0
          ],
          "bgcolor": [
            0.81,
            0.9,
            0.93,
            1.0
          ],
          "bgcolor2": [
            0.81,
            0.9,
            0.93,
            1.0
          ],
          "gradient": 0
        }
      },
      {
        "box": {
          "id": "prefix",
          "maxclass": "newobj",
          "numinlets": 1,
          "numoutlets": 1,
          "patching_rect": [
            20.0,
            225.0,
            120.0,
            22.0
          ],
          "text": "prepend morphto"
        }
      },
      {
        "box": {
          "id": "send",
          "maxclass": "newobj",
          "numinlets": 1,
          "numoutlets": 0,
          "patching_rect": [
            20.0,
            265.0,
            180.0,
            22.0
          ],
          "text": "send Synth_Control_v23"
        }
      },
      {
        "box": {
          "id": "out",
          "maxclass": "outlet",
          "numinlets": 1,
          "numoutlets": 0,
          "patching_rect": [
            250.0,
            265.0,
            25.0,
            25.0
          ]
        }
      },
      {
        "box": {
          "id": "ex0",
          "maxclass": "message",
          "numinlets": 2,
          "numoutlets": 1,
          "patching_rect": [
            20.0,
            125.0,
            80.0,
            22.0
          ],
          "text": "G 10",
          "fontname": "Arial",
          "fontsize": 12.0,
          "textcolor": [
            0.0,
            0.0,
            0.0,
            1.0
          ],
          "bgcolor": [
            0.81,
            0.9,
            0.93,
            1.0
          ],
          "bgcolor2": [
            0.81,
            0.9,
            0.93,
            1.0
          ],
          "gradient": 0,
          "presentation": 1,
          "presentation_rect": [
            20.0,
            125.0,
            80.0,
            22.0
          ],
          "hint": "Execute this CUE. It does not enable DSP or trigger an envelope.",
          "annotation": "Execute this CUE. It does not enable DSP or trigger an envelope."
        }
      },
      {
        "box": {
          "id": "ex1",
          "maxclass": "message",
          "numinlets": 2,
          "numoutlets": 1,
          "patching_rect": [
            110.0,
            125.0,
            80.0,
            22.0
          ],
          "text": "X 0.5",
          "fontname": "Arial",
          "fontsize": 12.0,
          "textcolor": [
            0.0,
            0.0,
            0.0,
            1.0
          ],
          "bgcolor": [
            0.81,
            0.9,
            0.93,
            1.0
          ],
          "bgcolor2": [
            0.81,
            0.9,
            0.93,
            1.0
          ],
          "gradient": 0,
          "presentation": 1,
          "presentation_rect": [
            110.0,
            125.0,
            80.0,
            22.0
          ],
          "hint": "Execute this CUE. It does not enable DSP or trigger an envelope.",
          "annotation": "Execute this CUE. It does not enable DSP or trigger an envelope."
        }
      },
      {
        "box": {
          "id": "ex2",
          "maxclass": "message",
          "numinlets": 2,
          "numoutlets": 1,
          "patching_rect": [
            200.0,
            125.0,
            80.0,
            22.0
          ],
          "text": "stop",
          "fontname": "Arial",
          "fontsize": 12.0,
          "textcolor": [
            0.0,
            0.0,
            0.0,
            1.0
          ],
          "bgcolor": [
            0.81,
            0.9,
            0.93,
            1.0
          ],
          "bgcolor2": [
            0.81,
            0.9,
            0.93,
            1.0
          ],
          "gradient": 0,
          "presentation": 1,
          "presentation_rect": [
            200.0,
            125.0,
            80.0,
            22.0
          ],
          "hint": "Execute this CUE. It does not enable DSP or trigger an envelope.",
          "annotation": "Execute this CUE. It does not enable DSP or trigger an envelope."
        }
      },
      {
        "box": {
          "id": "monitor-note",
          "maxclass": "comment",
          "numinlets": 1,
          "numoutlets": 0,
          "patching_rect": [
            20.0,
            215.0,
            575.0,
            50.0
          ],
          "text": "The outlet reports the sent command; it is a monitor, not a second send.\nFor arbitrary synth commands, use send Synth_Control_v23 or Synth_Command_v23.",
          "fontname": "Arial",
          "fontsize": 12.0,
          "textcolor": [
            0.0,
            0.0,
            0.0,
            1.0
          ],
          "presentation": 1,
          "presentation_rect": [
            20.0,
            215.0,
            575.0,
            50.0
          ]
        }
      },
      {
        "box": {
          "id": "mb2-loop-example",
          "maxclass": "message",
          "numinlets": 2,
          "numoutlets": 1,
          "patching_rect": [
            20.0,
            165.0,
            280.0,
            22.0
          ],
          "text": "morphcue A B A D C F",
          "outlettype": [
            ""
          ],
          "presentation": 1,
          "presentation_rect": [
            20.0,
            165.0,
            280.0,
            22.0
          ],
          "fontsize": 12.0,
          "textcolor": [
            0.06,
            0.07,
            0.09,
            1
          ],
          "bgcolor": [
            0.81,
            0.9,
            0.93,
            1
          ],
          "bgfillcolor_type": "color",
          "bgfillcolor_color": [
            0.81,
            0.9,
            0.93,
            1
          ]
        }
      },
      {
        "box": {
          "id": "mb2-command-route",
          "maxclass": "newobj",
          "numinlets": 1,
          "numoutlets": 3,
          "patching_rect": [
            330.0,
            390.0,
            215.0,
            22.0
          ],
          "text": "route morphcue morphjump",
          "outlettype": [
            "",
            "",
            ""
          ]
        }
      },
      {
        "box": {
          "id": "mb2-cue-prefix",
          "maxclass": "newobj",
          "numinlets": 1,
          "numoutlets": 1,
          "patching_rect": [
            330.0,
            425.0,
            145.0,
            22.0
          ],
          "text": "prepend morphcue",
          "outlettype": [
            ""
          ]
        }
      },
      {
        "box": {
          "id": "mb2-jump-prefix",
          "maxclass": "newobj",
          "numinlets": 1,
          "numoutlets": 1,
          "patching_rect": [
            330.0,
            460.0,
            145.0,
            22.0
          ],
          "text": "prepend morphjump",
          "outlettype": [
            ""
          ]
        }
      }
    ],
    "lines": [
      {
        "patchline": {
          "source": [
            "ex0",
            0
          ],
          "destination": [
            "route",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "ex1",
            0
          ],
          "destination": [
            "route",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "ex2",
            0
          ],
          "destination": [
            "route",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "in",
            0
          ],
          "destination": [
            "mb2-command-route",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "route",
            0
          ],
          "destination": [
            "hold",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "route",
            1
          ],
          "destination": [
            "prefix",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "hold",
            0
          ],
          "destination": [
            "send",
            0
          ],
          "order": 0
        }
      },
      {
        "patchline": {
          "source": [
            "hold",
            0
          ],
          "destination": [
            "out",
            0
          ],
          "order": 1
        }
      },
      {
        "patchline": {
          "source": [
            "prefix",
            0
          ],
          "destination": [
            "send",
            0
          ],
          "order": 0
        }
      },
      {
        "patchline": {
          "source": [
            "prefix",
            0
          ],
          "destination": [
            "out",
            0
          ],
          "order": 1
        }
      },
      {
        "patchline": {
          "source": [
            "mb2-loop-example",
            0
          ],
          "destination": [
            "send",
            0
          ],
          "order": 0
        }
      },
      {
        "patchline": {
          "source": [
            "mb2-loop-example",
            0
          ],
          "destination": [
            "out",
            0
          ],
          "order": 1
        }
      },
      {
        "patchline": {
          "source": [
            "mb2-command-route",
            0
          ],
          "destination": [
            "mb2-cue-prefix",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "mb2-command-route",
            1
          ],
          "destination": [
            "mb2-jump-prefix",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "mb2-command-route",
            2
          ],
          "destination": [
            "route",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "mb2-cue-prefix",
            0
          ],
          "destination": [
            "send",
            0
          ],
          "order": 0
        }
      },
      {
        "patchline": {
          "source": [
            "mb2-cue-prefix",
            0
          ],
          "destination": [
            "out",
            0
          ],
          "order": 1
        }
      },
      {
        "patchline": {
          "source": [
            "mb2-jump-prefix",
            0
          ],
          "destination": [
            "send",
            0
          ],
          "order": 0
        }
      },
      {
        "patchline": {
          "source": [
            "mb2-jump-prefix",
            0
          ],
          "destination": [
            "out",
            0
          ],
          "order": 1
        }
      }
    ]
  }
}
